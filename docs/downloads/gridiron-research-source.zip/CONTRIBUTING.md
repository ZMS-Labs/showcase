# Contributing

Contributions should preserve the unofficial research scope and clearly separate synthetic evidence from live-game observations.

## Rules

1. Do not add process injection, memory reading, anti-cheat bypasses, or FMT.
2. Do not commit Franchise saves, Madden screenshots, captures, keys, or model weights.
3. Keep Pydantic contracts authoritative; regenerate with `uv run python scripts/export_contracts.py`.
4. Tests first for behavior changes.
5. License remains GPL-3.0 for public releases under the operator's ownership.

## Layout

See `docs/ARCHITECTURE.md` and `docs/SYNTHETIC_DEMO.md`.
