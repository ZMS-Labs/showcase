# Calibration

Version 0.1 supports user-calibrated 16:9 presentations at 1920×1080, 2560×1440, or 3840×2160 in borderless-windowed or ordinary windowed SDR.

## Capture Lab

The dashboard Capture Lab can:

- preview the selected window;
- freeze and zoom;
- draw normalized rectangular ROIs (`0.0`–`1.0` relative to captured content);
- assign semantic ROI types;
- test OCR and preprocessing variants;
- show per-frame OCR and temporal consensus;
- record a lab session with explicit consent;
- annotate UI state, play boundaries, and outcomes;
- export a replay fixture;
- run profile health and drift checks.

Do not ship guessed Madden coordinates. Commit only schemas and synthetic profiles. Real Madden profiles stay in the user data directory.

## ROI types

home/away abbreviation and score, quarter, game clock, play clock, down, distance, ball spot, possession, timeouts, post-play player name and stat, scoring banner, penalty, review, play-call name, formation, personnel, drive summary, final-score state.

## Profile revision

A revision stores game, build hint, capture dimensions, aspect ratio, ROI definitions, preprocessing, temporal thresholds, visual anchors, and validation results.

## Session start

If anchors or expected fields fail, the session enters `PROFILE_STALE` and factual speech is suppressed. Recalibration is guided; thresholds are not silently relaxed.

## Color

HDR capture is detected and refused for live commentary in 0.1.
