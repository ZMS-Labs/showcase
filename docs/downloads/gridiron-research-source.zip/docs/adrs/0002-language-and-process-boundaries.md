# ADR 0002: Language and process boundaries

**Status:** Accepted  
**Date:** 2026-08-16

## Context

`madden-franchise` is a Node.js ESM library. Capture, OCR, audio, and orchestration are a better fit for Python on Windows. The dashboard should not require Electron.

## Decision

- Python 3.12 owns the backend, capture, perception, ledger, producer, models, TTS, and FastAPI dashboard host.
- Node.js 20+ owns a short-lived CLI subprocess that only reads a snapshot copy.
- React/Vite owns the dashboard, served by the Python backend in production.
- The franchise bridge is not a network service.

## Consequences

Contracts are authored in Pydantic and exported to JSON Schema and TypeScript. The bridge validates output against those schemas. Process isolation makes it possible to scan and test that the bridge never calls save APIs.
