# ADR 0004: OCR backend

**Status:** Accepted  
**Date:** 2026-08-16

## Context

Scorebug text must be read from crops. RapidOCR is simpler to install than PaddleOCR. Private Madden crops are not available during initial implementation.

## Decision

- `OcrProvider` interface with mock, RapidOCR, and optional PaddleOCR implementations.
- Field-specific preprocessing and alphabets.
- Temporal consensus is mandatory; a single frame never becomes canonical state.
- Default CI path uses the mock provider plus synthetic glyphs, proving the consensus and parser pipeline.
- RapidOCR is the first live candidate. PaddleOCR is benchmark-only.
- Private Madden OCR accuracy remains `UNVERIFIED` until labeled crops exist.

## Consequences

Synthetic fixtures can require 100% scoreboard oracle match. Live Madden accuracy is reported honestly and does not gate replay validation.
