# ADR 0006: Franchise read-only boundary

**Status:** Accepted  
**Date:** 2026-08-16

## Context

`madden-franchise` can write saves via `save()` and `packFile()`. The product may only read offline Franchise files.

## Decision

1. User selects the original save in the dashboard.
2. Python waits for size/mtime stability, copies to a unique snapshot directory, re-checks source metadata, hashes the copy, and marks the copy read-only.
3. Node receives only the snapshot path.
4. Bridge commands: `capabilities`, `export`, `inspect-table`, `validate`. No write command.
5. `saveOnChange` is never enabled. Tests fail if bridge source contains `.save(`, `packFile(`, or writes to the source path.
6. Original path is not logged and is not sent to models.

## Consequences

Missing tables degrade features via the capability report. Madden 27 live save parsing is `UNVERIFIED` until the operator selects a real save. Synthetic franchise JSON fixtures cover the Python normalization path in CI.
