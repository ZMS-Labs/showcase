# ADR 0001: External companion boundary

**Status:** Accepted  
**Date:** 2026-08-16

## Context

Madden NFL 27 on PC uses anti-tamper and anti-cheat components. The product must watch a user-selected window and read a user-selected offline Franchise save without becoming a trainer, overlay injector, or online-play aid.

## Decision

Version 0.1 is an unofficial external companion only. It may:

- capture a user-selected window through documented Windows APIs;
- OCR and analyze captured frames;
- copy a Franchise save to a private snapshot and parse the copy;
- call configured model endpoints;
- play audio through a normal output device.

It must not inject, debug, read or write Madden process memory, patch the executable, bypass anti-cheat, automate input, inspect hidden CPU play calls, modify saves, or run as an online/MUT companion.

## Consequences

Live game state is reconstructed from visible presentation plus read-only Franchise context. Hidden information is `NEVER_SPEAK` or `PRIVATE_UNTIL_POSTPLAY`. Deeper integration requires a separately approved project.
