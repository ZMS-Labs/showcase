# ADR 0005: Model provider boundary

**Status:** Accepted  
**Date:** 2026-08-16

## Context

Operators may run vision on an RTX 4090-class box, commentary on a DGX Spark / GX10-class box, or everything on one RTX 5090. Models must not be the source of truth.

## Decision

Provider location is configuration. Interfaces:

- `VisionObserver` — mock, OpenAI-compatible, Ollama, disabled.
- `CommentaryProvider` — mock, deterministic templates, Ollama, OpenAI-compatible.
- `TTSProvider` — mock, Kokoro ONNX, OpenAI-compatible.

The language model receives only an allowed fact packet and must return strict JSON (`SPEAK` or `WAIT`). `ClaimGuard` is deterministic. Vision output is `VISION_INFERENCE` and cannot authorize scores, identities, records, or hidden play calls.

No automatic weight downloads. API keys live in Windows Credential Manager via keyring, never in git.

## Consequences

Deterministic no-model mode is the default for tests and a supported degraded live mode. Remote vision requires explicit opt-in because frames leave the machine.
