# ADR 0003: Capture backend

**Status:** Accepted  
**Date:** 2026-08-16

## Context

The application must capture a user-selected Madden window without touching the Madden process. DXGI Desktop Duplication is typically monitor-wide. Windows Graphics Capture can target a window.

## Decision

Define `CaptureSource` with `list_targets`, `start`, `frames`, `stop`, and `health`.

Implementations:

1. `WindowsCaptureSource` — preferred, Graphics Capture, window-specific.
2. `DxcamCaptureSource` — optional fallback. Monitor capture requires explicit user confirmation.
3. `ReplayCaptureSource` — fixture frames.
4. `SyntheticCaptureSource` — generated HUD frames.

Never default to unrestricted desktop capture. Capture callbacks only copy and enqueue. Latest-frame-wins bounded queues. HDR live commentary is refused in 0.1.

## Consequences

CI and Linux core tests use synthetic and replay sources. Windows capture packages are extras. A normal application window can be used to validate capture without Madden.
