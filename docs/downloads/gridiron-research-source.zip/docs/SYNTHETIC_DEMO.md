# Synthetic replay demo

This demo uses the committed synthetic `drive-scoring-void` fixture. It does not
capture a window, parse a real save, call a model service, or play speech.

After the README setup, run from the source directory:

```powershell
uv run gbc replay --fixture fixtures/synthetic/drive-scoring-void
uv run gbc replay --fixture fixtures/synthetic/drive-scoring-void
uv run gbc benchmark --fixture fixtures/synthetic/drive-scoring-void --out reports
```

Compare the two replay hashes. The expected fixture has three events, including
CONFIRMED and VOIDED outcomes. The benchmark writes JSON and HTML in `reports/`.
The release-candidate receipt in STATUS.md records the observed hash and checks.

## What the output proves

Equal canonical-ledger hashes show repeatability for this fixed synthetic input.
The event status comparison and duplicate-commitment count exercise reconciliation.
Python and Node tests separately exercise their named contracts and mocked paths.

## What the output does not prove

Perception accuracy, unknown-state rate, and unsupported-name/number counts are
not measured by this replay. The candidate report emits JSON null for those
values, labels perception/commentary NOT_MEASURED, and gives an explicit reason.
It preserves the actual utterance count. Event verification requires a complete,
nonempty status oracle, matching event counts, and no duplicate commitments. The report's machine label is a generic
synthetic marker, not captured host metadata. Interpret only the checks actually
exercised; do not cite this report as a live accuracy benchmark.

Live game capture, real Madden 27 save compatibility, speech quality, latency,
complete-game operation, and broadcaster-like quality remain unverified. No EA
assets, real saves, captured frames, announcer voice recordings, or model weights
are included in this demo.
