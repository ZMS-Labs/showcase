# Research Ledger

**Product:** Gridiron Broadcast Companion  
**Research date:** 2026-08-16  
**Researcher:** implementation agent  
**Scope:** harvest-before-adopt for version 0.1 dependencies and safety-adjacent projects.

This ledger records what was inspected, what was adopted, and what was rejected. It is not a license grant.

Candidate recheck (2026-09-19): the installed, locked `madden-franchise` 4.3.6 package declares Node.js >=22.19.0. That observed requirement supersedes the earlier engine inference below; candidate setup and CI use the observed minimum. This does not verify live save parsing.

## 1. bep713/madden-franchise

| Item | Finding |
| --- | --- |
| Registry | https://www.npmjs.com/package/madden-franchise |
| Source | https://github.com/bep713/madden-franchise |
| Current version | **4.3.6** (published 2026-08-04) |
| License | MIT |
| Module system | ESM since 4.0.0; CommonJS consumers must stay on 3.8.0 or older |
| Node engines field | Not declared in package metadata. ESM + current TypeScript toolchain imply Node 18+. This project requires **Node.js 20 LTS or newer**. |
| Madden 27 support | Documented as **full**. Bundled schema present: `schemas/27/M27_525_0.gz`. College Football 27 schema `C27_468_2.gz` is present and unused by this product. |
| Usable lookup APIs | `Franchise.create(path, options)`, `getTableByUniqueId(id)` (stable), `getTableByName(name)` (first match; names can collide), `getAllTablesByName(name)`, `table.readRecords([fields])`, record field access via proxy. |
| Write APIs (prohibited) | `franchise.save([output])`, `franchise.packFile(output)`, record field assignment, `saveOnChange` setting. |
| Incomplete / locked files | Library reads the path it is given. Incomplete copies produce parse errors or partial tables. Locked originals are avoided by copying only after size/mtime stability. Behavior on a truncated snapshot is treated as a capability failure, not a retry against the original. |
| Bundled schemas | Sufficient for Madden 27 according to upstream. This application never extracts schemas via FMT. If a save’s schema version is missing, the capability report marks season-context features degraded. |
| Tables of interest | Looked up first by documented unique ID when known, otherwise by name, then recorded unique ID from `table.header.uniqueId`. Expected names: `Player`, `Team`, `SeasonInfo`, `SeasonGame`, `Standings`, `Injury`, `DepthChart`, plus season/career stat tables when present. Actual availability is reported, never assumed. |

**Adoption decision:** Adopt **only** through the Node franchise-bridge subprocess. Python never imports it. The original save path is never passed to Node.

**Tests required:** source scan for `.save(`, `packFile(`, and writes to the source path; subprocess argument is the snapshot copy; original hash/mtime unchanged.

## 2. Windows capture

### windows-capture 2.0.1

| Item | Finding |
| --- | --- |
| Registry | https://pypi.org/project/windows-capture/ |
| Source | https://github.com/NiiightmareXD/windows-capture |
| License | MIT (`windows-capture-python/LICENCE`) |
| Python | >=3.9 |
| Graphics Capture | `WindowsCapture` supports window-specific capture via documented Windows Graphics Capture APIs. Preferred path. |
| DXGI path | `DxgiDuplicationSession` is monitor/desktop duplication, not window-specific. Must not be the default. |
| Frame timestamps | Frames are delivered through callbacks; this application stamps `captured_at_utc` and `captured_at_monotonic_ns` at enqueue time. |
| Resize / close / minimize | Session must be recreated on resize. Closed windows fail health checks. Minimized or black frames pause capture. |
| HDR | Version 0.1 is SDR-only. Probable HDR is detected and live commentary is refused. |
| Overhead | Native Rust backend; capture callback must only copy/enqueue. |

### dxcam 0.3.0

| Item | Finding |
| --- | --- |
| Registry | https://pypi.org/project/dxcam/ |
| License | MIT |
| Backends | `dxgi` (Desktop Duplication, default) and `winrt` (Graphics Capture). DXGI is monitor-level. |
| Role | Optional fallback behind `CaptureSource`. Full-monitor capture requires an explicit user action. |

**Adoption decision:** `WindowsCaptureSource` is the default. `DxcamCaptureSource` is optional fallback. `ReplayCaptureSource` and `SyntheticCaptureSource` are first-class and do not require Windows capture packages at import time.

## 3. OCR

### RapidOCR 3.9.2

| Item | Finding |
| --- | --- |
| Registry | https://pypi.org/project/rapidocr/ |
| License | Apache-2.0 for engineering code. OCR model copyright remains with Baidu; models are not redistributed in this repository. |
| Install | `rapidocr` + `onnxruntime`. Comparatively simple. |
| Role | First production OCR candidate. |

### PaddleOCR / PP-OCRv6 (PaddleOCR 3.7.0)

| Item | Finding |
| --- | --- |
| Registry | https://pypi.org/project/paddleocr/ |
| License | Apache-2.0 |
| Role | Optional benchmark candidate only. Heavier install (PaddlePaddle). Not required for bootstrap. |

**Adoption decision:** Default OCR provider is RapidOCR when installed, otherwise the deterministic mock used by synthetic fixtures. PaddleOCR is a benchmark extra. Private Madden crop accuracy is `UNVERIFIED` until the operator supplies private samples. Synthetic scoreboard oracle accuracy is the CI gate.

## 4. Proact-VL

| Item | Finding |
| --- | --- |
| Paper | Microsoft Research, ICML 2026 |
| Source | https://github.com/microsoft/AnthropomorphicIntelligence/tree/main/Proact-VL |
| Repo license | MIT (root `LICENSE`, Copyright 2025 Microsoft) |
| PyPI | `proact-vl` 0.1.1, declared Apache-2.0 |
| Ideas used | Silence is valid; timing is separate from wording; bounded real-time commentary; co-commentary roles. |
| Code copied | **None.** Architectural reference only. |

**Adoption decision:** Not a production dependency. Optional experimental adapter may exist behind `providers.vision.type: experimental_proact` and is disabled by default. Version 0.1 works with vision disabled.

## 5. Video2Text (pause-aware commentary)

| Item | Finding |
| --- | --- |
| Paper | Afzal et al., LREC 2026, arXiv:2603.02655 |
| Source | https://github.com/anum94/Video2Text |
| License | **No LICENSE file observed on 2026-08-16.** Repository metadata does not declare a license. |
| Ideas used independently | Separate “what to say” from “when to say it”; WAIT vs SPEAK; pause-aware producer; do not speak continuously. |

**Adoption decision:** Do **not** copy implementation code. Reimplement the documented ideas in the producer and claim-guard path.

## 6. FMT Madden plugin

| Item | Finding |
| --- | --- |
| Source | https://github.com/FMTDev/FMT.Madden26Plugin |
| Stated scope | Madden 26, Madden 27, College Football 27 PC mod loading |
| Anti-tamper | README documents an anti-tamper module (`dpapi.dll`, `EAAntiCheat.exe`) used to bypass anti-tampering. |

**Adoption decision:** Inspected only. **Do not copy, invoke, bundle, or depend on FMT.** Schema extraction via FMT is out of scope. Future deeper integration would be a separate approved project.

## 7. Model and voice licenses

| Asset | License | Redistribution in this repo |
| --- | --- | --- |
| Qwen3-VL-8B-Instruct | Apache-2.0 | Not bundled. Optional remote/local endpoint. |
| Local instruction models via Ollama / OpenAI-compatible | Per configured model | Not bundled. |
| Kokoro-82M weights | Apache-2.0 | Not bundled. Optional documented download. |
| kokoro-onnx 0.5.0 | MIT (upstream README) | Dependency only; weights remain user-installed. |
| Generic Kokoro voices `am_michael`, `am_adam` | Covered by Kokoro Apache-2.0 voicepacks | Selected as two distinct generic male voices. Never labeled as real NFL announcers. |

Checksum strategy: when a local weight file is configured, store SHA-256 in user config and verify before warmup. Missing or mismatched checksums degrade TTS/vision rather than downloading automatically.

## 8. Substitutions

No material incompatibility required substituting the mandated stack. Pin notes:

- Python **3.12** via `uv` even if the host has 3.11.
- `madden-franchise` **4.3.6** rather than the older 4.3.1 snapshot seen in some indexes.
- `windows-capture` **2.0.1**.
- RapidOCR **3.9.2**.
- dxcam **0.3.0** as optional extra.
