# Third-Party Notices

Canonical copy: [`../THIRD_PARTY_NOTICES.md`](../THIRD_PARTY_NOTICES.md)
