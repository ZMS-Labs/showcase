# Model Configuration

Models are configuration, not architecture. Defaults are local, mock, or deterministic.

## Commentary

```yaml
providers:
  commentary:
    type: deterministic   # mock | deterministic | ollama | openai_compatible
    base_url: ""
    model: ""
    timeout_ms: 1800
    temperature: 0.1
    non_thinking: true
```

The provider must return the commentary-plan JSON schema. Extra fields are rejected. Hidden chain-of-thought is not requested.

## Vision

```yaml
providers:
  vision:
    type: disabled        # disabled | mock | ollama | openai_compatible
    base_url: ""
    model: ""
    timeout_ms: 2000
```

Send only bounded crops/clips plus structured diffs. Enumerated tags only. Output is `VISION_INFERENCE`.

Remote vision additionally requires `privacy.allow_remote_vision: true`.

Candidate class: Qwen3-VL 8B Instruct via Ollama or an OpenAI-compatible endpoint. Weights are not downloaded by setup.

## TTS

```yaml
providers:
  tts:
    type: mock            # mock | kokoro_onnx | openai_compatible
    voice_play_by_play: am_michael
    voice_analyst: am_adam
```

Kokoro weights are optional. Documented install:

```powershell
# optional, not run by bootstrap
# download kokoro-v1.0.onnx and voices-v1.0.bin to %LOCALAPPDATA%\GridironBroadcastCompanion\models\kokoro
```

Voices are generic. Do not label them as real announcers. Voice cloning is not implemented.

## Warmup and health

`POST /api/v1/providers/test` and session start call `health()` and `warmup()`. Failures enter a visible degraded mode rather than crashing.

## Secrets

Set `GBC_COMMENTARY_API_KEY` / `GBC_VISION_API_KEY` / `GBC_TTS_API_KEY` or store them with keyring. Never commit keys.
