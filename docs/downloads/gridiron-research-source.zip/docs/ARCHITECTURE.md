# Architecture

Gridiron Broadcast Companion is a neuro-symbolic Windows companion. Models propose language. The canonical ledger and fact compiler authorize facts.

## Process topology

```text
Browser dashboard  <-->  Python FastAPI (127.0.0.1)
                              |
              +---------------+----------------+
              |               |                |
        CaptureSource   FranchiseBridge     AudioWorker
        (window/replay) (Node subprocess)   (sounddevice)
```

The Node bridge is a one-shot CLI. It is not a daemon.

## Data flow

```text
Visible frames + read-only Franchise snapshot
        -> observation / OCR / optional VLM tags
        -> event reconciler (single writer)
        -> canonical game ledger
        -> game memory + broadcast memory
        -> fact compiler
        -> producer (including SILENCE)
        -> commentary provider (strict JSON)
        -> claim guard
        -> TTS scheduler
        -> Windows audio + captions
```

## Packages

| Path | Responsibility |
| --- | --- |
| `backend/src/gbc/contracts` | Authoritative Pydantic models |
| `backend/src/gbc/capture` | Window, replay, synthetic capture |
| `backend/src/gbc/perception` | OCR, consensus, phase, vision |
| `backend/src/gbc/franchise` | Stable copy + bridge client |
| `backend/src/gbc/events` | Reconciler and scoring rules |
| `backend/src/gbc/memory` | Stats, tendencies, storylines, topics |
| `backend/src/gbc/facts` | Deterministic fact compiler |
| `backend/src/gbc/producer` | Speak / silence / speaker / priority |
| `backend/src/gbc/language` | LLM providers + claim guard |
| `backend/src/gbc/speech` | TTS, pronunciation, scheduler |
| `backend/src/gbc/replay` | Fixture clock and runner |
| `franchise-bridge` | Read-only madden-franchise CLI |
| `web` | Local dashboard |

## Concurrency

Capture callbacks enqueue only. Bounded latest-frame queues. OCR workers drop stale frames. The reconciler is single-writer and timestamp-ordered. VLM work is event-triggered. LLM and TTS work is cancellable. Database writes do not block capture.

## Resource presets

`LOW_IMPACT`, `BALANCED`, `HIGH_QUALITY`, `DISTRIBUTED` change FPS, queue depths, and whether vision/commentary run locally.

## Degraded modes

No Franchise, no vision, no commentary model, no TTS, low confidence, capture loss, and `PROFILE_STALE` are first-class dashboard states. Factual speech fails closed.
