# Live Validation

Live validation is **not** claimed from synthetic replay.

## Preconditions

- Windows 11 x86-64
- Madden NFL 27 PC, offline Franchise
- Borderless-windowed or windowed SDR
- Calibrated profile that passes health checks
- User-selected window and save
- Madden commentary volume at zero
- Models optional; deterministic mode is valid

## Procedure

1. Run `.\scripts\dev.ps1`.
2. Acknowledge safety boundaries.
3. Select the Madden window. Confirm capture preview is the game, not the desktop.
4. Select the offline Franchise save. Confirm original hash/mtime unchanged after snapshot.
5. Confirm human team and matchup.
6. Load a validated display profile.
7. Verify scoreboard OCR consensus on a paused pregame or in-game scorebug.
8. Configure providers and warmup.
9. Start the session. Play one complete game.
10. Preserve logs, event ledger, utterances, and metrics.
11. After Madden writes the save, take a post-game snapshot and reconcile.
12. Manually review every scoring play, turnover, correction, and void.
13. Review every spoken factual claim against the ledger.
14. File `docs/validation/live/<date>-<matchup>.md` locally (gitignored if it contains private data).

## Required evidence for IMPLEMENTED_AND_LIVE_VALIDATED

- Complete offline Franchise game
- Final-score match
- Major-event review
- Claim review with zero unsupported spoken facts
- Latency report
- No prohibited integration
- No save modification
- No crash

Until that evidence exists, status remains `IMPLEMENTED_AND_REPLAY_VALIDATED_LIVE_VALIDATION_PENDING` or weaker.
