# Release-candidate status

**Scope:** independently checked synthetic research source; live validation pending.
**Verification date:** 2026-09-19. **Source revision:** `001e174e97f2cf5a79a52bbfa1ebe134802dda3a`.
This candidate includes the documented dependency, compiler, and report-accuracy fixes.
It has not been published, deployed, or validated against a live Madden session.

## Reproduced checks

On Windows with Python 3.12.13, Node v24.13.0, and pnpm 10.12.4:

- Locked Python setup and frozen Node installation passed in an independent copy.
- 38 Python tests passed, including four report-accuracy regressions; coverage 71%.
- Two Franchise bridge tests and three web tests passed.
- The existing browser setup-to-synthetic-replay test passed (one test).
- Python formatting, lint, and mypy passed; both Node workspaces passed formatting,
  lint, and TypeScript checks; the web production build passed.
- All 20 generated contract files remained byte-identical after export.
- Python dependency audit reported no known vulnerabilities across 91 dependencies.
  The production Node audit reported none after the locked fast-uri 3.1.6 patch.
- The candidate secret scan and source-only private-file scan passed. These checks
  are bounded evidence, not a guarantee of all privacy or licensing properties.

Individual commands were executed from a source snapshot. The aggregate
`scripts/verify.ps1` includes Git checks and was not represented as executed from
this Git-free archive. Candidate CI is configured with frozen installs and type
checks; no hosted CI or Linux run of this candidate is claimed.

## Repeated replay

Two CLI runs produced the same canonical-ledger hash:

`3229305cb6a0f7ac6e7d6e9f7b27ca04b791cb9e2ca65a2e44c6eb0162c0d4bb`

Observed: three events, one utterance, matching terminal-status oracle and event
count, and zero duplicate commitments. The existing browser test also exercised
the synthetic replay workflow against an isolated loopback application.

Perception accuracy and unsupported-name/number rates are not measured. Their
values are JSON null, with NOT_MEASURED labels and explicit reasons. Stable replay
does not imply OCR or commentary accuracy. Missing or partial event oracles cannot
produce VERIFIED event evidence. See [the demo](SYNTHETIC_DEMO.md).

## Remaining limits

Live window capture, real Madden 27 save compatibility, complete-game operation,
audio quality, optional models, latency, and game performance remain unverified.
The bridge checks synthetic/non-save bytes; its typed API does not establish live
save compatibility. No game service, paid model, real save, or capture was used.

The fixture is declared original synthetic data. No real saves, game graphics,
announcer recordings, model weights, or installed dependency binaries are bundled.
Existing GPL-3.0-or-later declarations and notices are retained. Publication,
repository naming, contributor rights, and any separately obtained assets require
the maintainer's release decision.
