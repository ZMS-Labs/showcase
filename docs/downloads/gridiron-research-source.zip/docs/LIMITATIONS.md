# Limitations (version 0.1)

- Live Madden perception is `UNVERIFIED` until the operator calibrates a profile and labels a private fixture of at least 50 plays.
- Complete-game live validation is `UNVERIFIED` until one offline Franchise game is run and reviewed.
- Vision is disabled by default. VLM tags cannot authorize scores, identities, or records.
- HDR capture is refused.
- No overlay, no audio ducking, no online/MUT modes, no real announcer voices.
- Franchise table coverage depends on the actual save; missing tables degrade season context.
- Windows Graphics Capture extras are optional; CI uses synthetic and replay sources. Live window grab uses documented Win32 PrintWindow/BitBlt and may return a black frame for DirectX-composed Madden windows until extras are installed.
- Kokoro weights are not bundled.
