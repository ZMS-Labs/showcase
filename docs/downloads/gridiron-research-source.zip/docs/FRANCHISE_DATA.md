# Franchise Data

## Stable-copy protocol

1. User selects the source save.
2. Read size and mtime.
3. Wait until both remain unchanged for `franchise.snapshot_stability_seconds` (default 2).
4. Copy to `%LOCALAPPDATA%\GridironBroadcastCompanion\snapshots\<uuid>\`.
5. Re-read source metadata; discard and retry if changed (`snapshot_retry_count`).
6. SHA-256 the snapshot.
7. Mark the snapshot read-only.
8. Pass only the snapshot path to Node.
9. Preserve the source path only in protected local config.
10. Never put the source path in prompts or logs.

## Bridge commands

```text
node franchise-bridge capabilities --input <snapshot>
node franchise-bridge export --input <snapshot> --output <json>
node franchise-bridge inspect-table --input <snapshot> --table <name-or-unique-id>
node franchise-bridge validate --input <snapshot>
```

`inspect-table` is a local diagnostic and must not dump sensitive rows into normal logs.

## Capability report

Includes detected game year, parser/schema version, table inventory, requested tables/fields found or missing, record counts, warnings, degraded features, and snapshot hash.

## Identity keys

Prefer `header.uniqueId` plus record index or a parser-exposed stable record id. If no stable id exists, the composite key is `tableUniqueId:rowIndex` and is documented as a fallback in the capability report.

## Madden 27 validation

Parser support is documented upstream as full. Actual save parsing is `UNVERIFIED` until an operator-selected Madden 27 offline Franchise file is snapshotted. CI uses synthetic JSON that matches the export schema.

## Prohibited

No `save()`, no `packFile()`, no original-path parse, no FMT schema harvest.
