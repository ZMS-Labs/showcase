# Dependency Decisions

Pinned for Gridiron Broadcast Companion 0.1 on 2026-08-16. Versions are the current releases inspected during harvest-before-adopt. Lockfiles (`uv.lock`, `pnpm-lock.yaml`) are authoritative at install time.

## Runtime policy

- Bootstrap does **not** download model weights.
- Optional extras (`ocr`, `windows-capture`, `dxcam`, `kokoro`) install only when requested.
- CI uses mock providers only.
- GPL-3.0 is the project license. Third-party licenses are recorded in `THIRD_PARTY_NOTICES.md`.

## Python (backend)

| Package | Role | License | Required |
| --- | --- | --- | --- |
| Python 3.12 | Language | PSF | Yes |
| fastapi | HTTP/WebSocket API | MIT | Yes |
| uvicorn | ASGI server | BSD-3-Clause | Yes |
| pydantic / pydantic-settings | Contracts and config | MIT | Yes |
| sqlalchemy | Persistence | MIT | Yes |
| alembic | Migrations | MIT | Yes |
| httpx | Provider HTTP | BSD-3-Clause | Yes |
| structlog | Logging | MIT / Apache-2.0 | Yes |
| orjson | JSON | Apache-2.0 / MIT | Yes |
| numpy | Arrays | BSD | Yes |
| opencv-python-headless | Image preprocess | Apache-2.0 | Yes |
| pillow | Synthetic HUD / crops | HPND | Yes |
| pywin32 | Window enumeration (Windows) | PSF-style | Windows extra |
| watchdog | Optional file watches | Apache-2.0 | Yes |
| rapidfuzz | Name matching | MIT | Yes |
| sounddevice | Playback | MIT | Yes |
| soundfile | PCM IO | BSD-3-Clause | Yes |
| keyring | Credential Manager | MIT | Yes |
| pyyaml | Config | MIT | Yes |
| jsonschema | Contract validation | MIT | Yes |
| windows-capture | Preferred capture | MIT | Windows extra |
| dxcam | Capture fallback | MIT | Optional extra |
| rapidocr + onnxruntime | OCR | Apache-2.0 | Optional extra |
| paddleocr | OCR benchmark | Apache-2.0 | Optional extra, not CI |
| kokoro-onnx | Local TTS | MIT | Optional extra |

Dev: ruff, mypy, pytest, pytest-asyncio, hypothesis, coverage, pip-audit.

## Node (franchise-bridge)

| Package | Role | License | Required |
| --- | --- | --- | --- |
| Node.js >=22.19.0 | Runtime | Various | Yes |
| TypeScript | Language | Apache-2.0 | Yes |
| madden-franchise 4.3.6 | Read-only parse | MIT | Bridge only |
| ajv | JSON Schema | MIT | Yes |
| vitest | Tests | MIT | Dev |

## Frontend (web)

| Package | Role | License |
| --- | --- | --- |
| React 19 | UI | MIT |
| Vite | Bundler | MIT |
| TypeScript | Language | Apache-2.0 |
| @tanstack/react-query | Server state | MIT |
| vitest | Unit tests | MIT |
| playwright | E2E | Apache-2.0 |
| eslint / prettier | Quality | MIT |

## Explicitly rejected

| Item | Reason |
| --- | --- |
| Electron / Tauri | Out of 0.1 scope |
| FMT / Frosty / anti-tamper modules | Safety boundary |
| Proact-VL as required dependency | Research reference only |
| Video2Text source | No license observed |
| Bundled model weights | Size, license redistribution, setup policy |
| pymem / frida / debugger attach | Process integration prohibited |
