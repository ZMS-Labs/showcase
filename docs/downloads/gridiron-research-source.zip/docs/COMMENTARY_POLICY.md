# Commentary Policy

The language model is a writer, not the source of truth.

## Epistemic rules

| Class | Speak? |
| --- | --- |
| PUBLIC_OBSERVATION with CONFIRMED/HIGH | Yes, unqualified if ClaimGuard agrees |
| DETERMINISTIC_DERIVATION with CONFIRMED | Yes |
| INFERENCE / VISION_INFERENCE | Only with calibrated hedging, never as score/identity/record |
| PRIVATE_UNTIL_POSTPLAY | No until post-play confirmation |
| NEVER_SPEAK | Never |
| LOW or UNKNOWN | Never as an unqualified fact |

## Producer

The producer chooses speaker, intent, facts, time budget, or `SILENCE`. Immediate reactions are deterministic and nameless until confirmation. Reflective analysis uses the commentary provider.

Play-by-play: result, confirmed participant, score, clock, field position.  
Analyst: why it mattered, verified tendency, season context, callbacks.

The same prompt is not used for both roles.

## ClaimGuard

Rejects extra JSON fields, unknown fact ids, unspeakable facts, names/numbers not in the allowed set, unauthorized streaks/superlatives/records, mismatched certainty, excess length, recent repetition, banned branding, and meta-language.

One repair attempt, then deterministic fallback or silence.

## Repeated plays

“The same play” requires `EXACT_VERIFIED_PLAY` or equivalently strong structured evidence. Otherwise “a similar look” or silence.

## Voices

Two generic licensed voices. No real-announcer imitation.
