# Troubleshooting

## Bootstrap fails on Python

Install `uv` from https://docs.astral.sh/uv/ then rerun `.\scripts\bootstrap.ps1`. The project requires Python 3.12 even if 3.11 is on PATH.

## Dashboard cannot list Madden

Run Madden in borderless-windowed or windowed mode. Full-screen exclusive is unsupported. Confirm the window appears in Setup. Capture never attaches to the process.

## Scoreboard OCR is wrong

Open Capture Lab, freeze a frame, redraw ROIs, test consensus. If anchors fail, the profile is `PROFILE_STALE` and factual speech is suppressed. Do not lower thresholds to force a green check.

## Franchise snapshot fails

Close anything writing the save. Wait for Madden to finish writing. The companion copies only after size and mtime are stable. The original file is never parsed.

## No speech

Check degraded modes on the dashboard. Deterministic mode still speaks templates for high-salience events. Mock TTS shows captions. Panic mute must be unmuted.

## Models

Bootstrap does not download weights. Configure Ollama or an OpenAI-compatible endpoint in YAML. Remote vision requires `privacy.allow_remote_vision`.
