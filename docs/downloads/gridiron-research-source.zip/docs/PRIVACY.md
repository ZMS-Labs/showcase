# Privacy

## Defaults

- Bind `127.0.0.1` only.
- No analytics or telemetry export.
- No raw-frame persistence.
- No cloud model calls.
- No remote frame transmission.
- Original Franchise save is never parsed in place.
- Secrets are not committed.

## Data locations

Application data defaults to `%LOCALAPPDATA%\GridironBroadcastCompanion`. Snapshots, SQLite, profiles, and logs live there unless the YAML `app.data_dir` setting overrides it. The flat `GBC_DATA_DIR` example is not a verified override in the current loader.

## Remote providers

- Remote vision requires `privacy.allow_remote_vision: true` because frames leave the gaming PC.
- Remote commentary requires `privacy.allow_remote_commentary: true`. Only structured facts are sent.
- Complete Franchise rosters are not sent to remote providers unless explicitly enabled.

## Logging redaction

A redaction helper exists, but the current logging configuration does not establish automatic redaction for every field. Treat logs, prompts, diagnostics, and screenshots as private until their actual contents have been inspected. Do not include credentials, rosters, real saves, or captures in bug reports.

## Diagnostics

A diagnostic bundle lists its contents before export. Crops and frames are included only with explicit consent.

## Credentials

Persistent API keys use Windows Credential Manager through `keyring`.
