# Safety Boundaries

This application is an unofficial external companion. It is not a trainer, injector, or competitive aid.

## Prohibited

The codebase and runtime must not:

- inject code or a DLL into Madden;
- attach a debugger to Madden;
- read or write Madden process memory;
- scan the process for offsets or signatures;
- intercept internal Madden functions;
- patch the executable;
- alter or bypass anti-cheat / anti-tamper;
- impersonate an input device or automate gameplay;
- inspect hidden CPU play calls;
- modify a Franchise save or call `save()` / `packFile()`;
- participate in Ultimate Team or ranked/competitive online play;
- clone or market the voice of a real announcer without a license;
- redistribute EA, NFL, broadcast, or game assets.

## Allowed

- Documented Windows window capture.
- OCR and visual analysis of captured frames.
- Private read-only snapshot of a user-selected offline Franchise save.
- Configured local or remote model endpoints.
- Normal Windows audio output.
- Application-owned SQLite databases.
- Asking the user to mute Madden commentary in-game.

## Enforcement

- Capture backends use Graphics Capture or explicit user-confirmed monitor capture.
- Franchise original path never enters Node.
- Bridge tests fail on write APIs.
- Session start refuses online/MUT modes (operator attestation + no online session types in 0.1).
- Voices are generic Kokoro or user-configured licensed voices, never labeled as real announcers.

## FMT

FMT Madden plugins document anti-tamper bypasses. They are out of scope. Do not copy or invoke them.
