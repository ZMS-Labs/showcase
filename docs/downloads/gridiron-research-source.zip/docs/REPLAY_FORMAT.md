# Replay Format

Schema version: `gbc.replay.v1`

```text
fixture-name/
├─ manifest.json
├─ frames/            # optional; synthetic PNG/WebP
├─ observations/      # optional recorded OCR jsonl
├─ oracle/
│  ├─ scoreboard.jsonl
│  ├─ phases.jsonl
│  ├─ events.jsonl
│  └─ allowed-commentary-facts.jsonl
└─ README.md
```

## Manifest fields

`schema_version`, `source_type` (`synthetic` | `private_madden`), `frame_rate`, `width`, `height`, `timestamps`, `privacy_classification`, `assets_may_be_committed`, `profile_revision`, `oracle_author`, `expected_event_count`.

Synthetic fixtures use original generic graphics. Private Madden fixtures are gitignored.

## ReplayClock

A deterministic clock advances monotonic nanoseconds from fixture timestamps. Mock providers plus the same fixture must produce byte-equivalent canonical ledgers after stripping nondeterministic timestamps.

## Commands

```powershell
uv run gbc replay --fixture fixtures/synthetic/drive-scoring-void
uv run gbc benchmark --fixture fixtures/synthetic/drive-scoring-void --out reports/
```

Outputs: `benchmark.json` and `benchmark.html`.
