# Gridiron Broadcast Companion


Gridiron Broadcast Companion is an unofficial fan-created research project. It is not affiliated with or endorsed by Electronic Arts, EA SPORTS, the NFL, the NFLPA, any broadcaster, or any announcer.

A research prototype for an external Windows companion to **Madden NFL 27**
offline Franchise. Its verified path replays synthetic observations into an event
ledger and deterministic commentary. The implemented live architecture is intended
to capture a selected game window, read a private save snapshot, and produce a
two-person broadcast; live capture, real-save compatibility, and a complete game
remain unverified. A language model may write from supported facts; it does not
establish game state.

```mermaid
flowchart LR
  F[Synthetic observations and event oracle] --> R[Event reconciler]
  R --> L[Canonical ledger and statistics]
  L --> P[Producer]
  P --> I[Fixed immediate line]
  P --> C[Fact packet and template provider]
  C --> G[Claim guard]
  I --> O[Text output]
  G --> O
```

This describes the synthetic replay path. Optional capture, model, and speech
integrations have separate validation requirements.

**License:** [GNU GPL version 3](LICENSE); see [package metadata](pyproject.toml) and [third-party notices](docs/THIRD_PARTY_NOTICES.md) for the recorded terms.

## Status

The [recorded status](docs/STATUS.md) is
synthetic research candidate: setup, replay, and the existing browser demo have
fresh verification evidence, while live capture, Madden 27 save parsing, and a
complete operator-played game remain unverified. Consult
[limitations](docs/LIMITATIONS.md) before using it. A successful replay does not
establish live Madden behavior.

## Requirements

- Windows 11 x86-64 for live capture and audio
- Python 3.12 (selected explicitly below)
- Node.js 22.19.0+ (required by the locked Franchise parser)
- [uv](https://docs.astral.sh/uv/) available on PATH for bootstrap and Python tooling
- pnpm 10.12.4, as pinned in [package.json](package.json)

The included Windows CI workflow is configured for the full core checks; the Linux workflow selects a platform-independent subset. Local Windows results are recorded in STATUS.md; neither workflow configuration nor a synthetic test proves a live Madden session.

## Quick start

Run the synthetic path first. It uses a deterministic text provider and mock
vision/audio; it needs no game, save file, model account, or model weights.
From the source directory in PowerShell:

```powershell
uv python install 3.12
uv sync --locked --python 3.12 --extra dev
npx --yes pnpm@10.12.4 install --frozen-lockfile
uv run gbc replay --fixture fixtures/synthetic/drive-scoring-void
```

See [the synthetic demo](docs/SYNTHETIC_DEMO.md) for a second replay, benchmark,
expected output, and the limits of what these checks prove. `npx` downloads the
pinned package manager into its cache; these commands do not install it globally.

The optional dashboard uses the synthetic development configuration. After a web
build, `uv run gbc serve --env development` binds to localhost:8765. It is a
foreground local process; stop it with Ctrl+C. Runtime data normally goes to
`%LOCALAPPDATA%\GridironBroadcastCompanion`; configuration is read from
`config/default.yaml` plus `config/development.yaml`. The current loader does not
automatically read `.env.example`; use YAML for settings rather than relying on
the flat example variable names.

Use [calibration](docs/CALIBRATION.md), [model configuration](docs/MODEL_CONFIGURATION.md), and the [live validation runbook](docs/LIVE_VALIDATION.md) only when moving from synthetic inputs to the operator-controlled live workflow.

The aggregate verification script uses Git for tracked-file checks. In a source
archive without `.git`, use the individual checks below. The bootstrap helper may
install pnpm globally if it is missing; the pinned quick start above avoids that.

```powershell
.\scripts\verify.ps1
.\scripts\build.ps1
.\scripts\package.ps1
```

Individual developer checks (also usable from a source archive):

```powershell
uv python install 3.12
uv sync --locked --extra dev
npx --yes pnpm@10.12.4 install --frozen-lockfile
uv run pytest
uv run ruff check backend
uv run mypy backend/src/gbc
npx --yes pnpm@10.12.4 --filter franchise-bridge exec tsc --noEmit
npx --yes pnpm@10.12.4 --filter web exec tsc --noEmit
npx --yes pnpm@10.12.4 --filter franchise-bridge test
npx --yes pnpm@10.12.4 --filter web test
uv run gbc replay --fixture fixtures/synthetic/drive-scoring-void
uv run gbc benchmark --fixture fixtures/synthetic/drive-scoring-void --out reports
```

## Safety

This application does not inject into Madden, read process memory, bypass anti-cheat, automate input, or modify Franchise saves. See [`docs/SAFETY_BOUNDARIES.md`](docs/SAFETY_BOUNDARIES.md).

## Documentation

- [Status and evidence](docs/STATUS.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Calibration](docs/CALIBRATION.md)
- [Franchise data](docs/FRANCHISE_DATA.md)
- [Model configuration](docs/MODEL_CONFIGURATION.md)
- [Commentary policy](docs/COMMENTARY_POLICY.md)
- [Replay format](docs/REPLAY_FORMAT.md)
- [Live validation](docs/LIVE_VALIDATION.md)
- [Privacy](docs/PRIVACY.md)
- [Troubleshooting](docs/TROUBLESHOOTING.md)
- [Limitations](docs/LIMITATIONS.md)

## Contributing

Read [CONTRIBUTING.md](CONTRIBUTING.md) before changing contracts or capture
behavior. Keep Franchise saves, screenshots, credentials, and model weights out
of Git. The [architecture guide](docs/ARCHITECTURE.md) maps the Python backend,
Franchise bridge, web UI, fixtures, and scripts; the verification commands above
exercise the existing checks. Report synthetic/replay results separately from
operator-run live validation.
