$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
Remove-Item -Recurse -Force .venv, backend/**/__pycache__, web/dist, reports, dist -ErrorAction SilentlyContinue
Write-Host "clean complete"
