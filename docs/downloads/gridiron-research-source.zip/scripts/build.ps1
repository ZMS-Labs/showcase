$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
uv run python scripts/export_contracts.py
pnpm --filter web build
uv run ruff check backend
Write-Host "build complete"
