$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
$out = Join-Path (Get-Location) "dist\gbc-dev"
if (Test-Path $out) { Remove-Item -Recurse -Force $out }
New-Item -ItemType Directory -Path $out | Out-Null

$items = @(
  "backend",
  "franchise-bridge",
  "web",
  "config",
  "contracts",
  "fixtures",
  "profiles",
  "scripts",
  "docs",
  "pyproject.toml",
  "uv.lock",
  "package.json",
  "pnpm-workspace.yaml",
  "pnpm-lock.yaml",
  "README.md",
  "LICENSE",
  "NOTICE.md",
  "THIRD_PARTY_NOTICES.md"
)
foreach ($item in $items) {
  $source = Join-Path (Get-Location) $item
  if (Test-Path $source) {
    Copy-Item -LiteralPath $source -Destination $out -Recurse -Force
  }
}
Get-ChildItem -LiteralPath $out -Recurse -Directory -Force |
  Where-Object { $_.Name -in @("node_modules", ".venv", "__pycache__", ".pytest_cache") } |
  ForEach-Object { Remove-Item -LiteralPath $_.FullName -Recurse -Force }

$hashes = Get-ChildItem -LiteralPath $out -Recurse -File | ForEach-Object {
  "{0}  {1}" -f (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash, $_.FullName.Substring($out.Length + 1)
}
Set-Content -LiteralPath (Join-Path $out "SHA256SUMS.txt") -Value $hashes -Encoding utf8
Write-Host "Packaged developer folder at $out"
