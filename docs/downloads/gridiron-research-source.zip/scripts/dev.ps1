$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)

if (-not (Test-Path .venv) -and -not (Test-Path .uv)) {
  Write-Host "Run .\scripts\bootstrap.ps1 first"
}

Start-Process -FilePath "pnpm" -ArgumentList "--filter","web","dev" -WindowStyle Hidden
uv run gbc serve --env development
