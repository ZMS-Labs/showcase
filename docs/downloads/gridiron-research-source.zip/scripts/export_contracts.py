from __future__ import annotations

import json
from pathlib import Path

from gbc.contracts import CONTRACT_MODELS


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def export_schemas(out_dir: Path) -> list[Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    for model in CONTRACT_MODELS:
        path = out_dir / f"{model.__name__}.schema.json"
        path.write_text(json.dumps(model.model_json_schema(), indent=2) + "\n", encoding="utf-8")
        written.append(path)
    return written


def export_ts(out_file: Path) -> None:
    lines = [
        "/* Generated from Pydantic contracts. Do not edit. */",
        "export type Authority = 'USER_CONFIRMED' | 'FRANCHISE_SAVE' | 'OCR_CONSENSUS' | 'DETERMINISTIC_DIFF' | 'VISIBLE_PLAY_SELECTION' | 'VISION_INFERENCE' | 'HEURISTIC';",
        "export type EventStatus = 'PROVISIONAL' | 'CONFIRMED' | 'CORRECTED' | 'VOIDED';",
        "export type GamePhase = 'PREGAME' | 'PLAYCALL' | 'PRESNAP' | 'LIVE_PLAY' | 'POSTPLAY_PENDING' | 'POSTPLAY_STABLE' | 'PENALTY' | 'REVIEW' | 'REPLAY' | 'TIMEOUT' | 'QUARTER_BREAK' | 'HALFTIME' | 'FINAL' | 'UNKNOWN';",
        "export type Speaker = 'PLAY_BY_PLAY' | 'ANALYST';",
        "export interface CaptureTarget { target_id: string; title: string; process_name?: string | null; kind: string; width?: number | null; height?: number | null; }",
        "export interface Health { status: string; version: string; degraded: string[]; muted: boolean; }",
        "",
    ]
    out_file.parent.mkdir(parents=True, exist_ok=True)
    out_file.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    root = repo_root()
    schemas = root / "contracts" / "generated"
    export_schemas(schemas)
    export_ts(root / "contracts" / "generated" / "types.ts")
    print(f"exported {len(list(schemas.glob('*.json')))} schemas")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
