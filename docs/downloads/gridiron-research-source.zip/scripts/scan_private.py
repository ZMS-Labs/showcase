from __future__ import annotations

from pathlib import Path

SUSPECT_SUFFIXES = {".franchise", ".save", ".sav", ".mp4", ".mkv", ".avi", ".wav", ".flac"}
SUSPECT_DIRS = {"fixtures/private", "private-data", "captures", "diagnostics", "models"}
MAX_BYTES = 5 * 1024 * 1024


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    tracked = []
    try:
        import subprocess

        out = subprocess.check_output(["git", "ls-files"], cwd=root, text=True)
        tracked = [Path(line) for line in out.splitlines() if line]
    except Exception:
        tracked = [p.relative_to(root) for p in root.rglob("*") if p.is_file()]
    failures: list[str] = []
    for path in tracked:
        posix = path.as_posix()
        if any(posix.startswith(d) for d in SUSPECT_DIRS) and path.name != "README.md":
            failures.append(f"private path tracked: {posix}")
        if path.suffix.lower() in SUSPECT_SUFFIXES:
            failures.append(f"private suffix tracked: {posix}")
        full = root / path
        if full.exists() and full.stat().st_size > MAX_BYTES and "contracts" not in posix:
            failures.append(f"oversized tracked file: {posix}")
    if failures:
        print("\n".join(failures))
        return 1
    print("private scan clean")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
