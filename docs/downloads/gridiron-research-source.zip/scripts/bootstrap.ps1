Param(
  [switch]$SkipOptional
)

$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)

Write-Host "Installing Python 3.12 via uv"
uv python install 3.12
uv sync --locked --extra dev

Write-Host "Installing Node workspace"
if (-not (Get-Command pnpm -ErrorAction SilentlyContinue)) {
  npm install -g pnpm@10.12.4
}
pnpm install --frozen-lockfile

if (-not $SkipOptional) {
  Write-Host "Optional extras are not installed by default (OCR, windows-capture, Kokoro)."
  Write-Host "Install later with: uv sync --locked --extra dev --extra windows --extra ocr"
}

Write-Host "Exporting contracts"
uv run python scripts/export_contracts.py

Write-Host "Bootstrap complete. Run .\scripts\dev.ps1"
