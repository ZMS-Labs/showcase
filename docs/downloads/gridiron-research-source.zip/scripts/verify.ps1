$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)

function Invoke-Checked {
  param([string]$Label, [scriptblock]$Block)
  Write-Host "== $Label =="
  & $Block
  if ($LASTEXITCODE -ne 0) {
    throw "$Label failed with exit $LASTEXITCODE"
  }
}

Invoke-Checked "locked Python install" { uv sync --locked --extra dev }
Invoke-Checked "frozen Node install" { pnpm install --frozen-lockfile }
Invoke-Checked "ruff format" { uv run ruff format --check backend scripts }
Invoke-Checked "ruff lint" { uv run ruff check backend scripts }
Invoke-Checked "mypy" { uv run mypy backend/src/gbc }
Invoke-Checked "pytest" { uv run coverage run -m pytest }
Invoke-Checked "coverage" { uv run coverage report }
Invoke-Checked "contracts" { uv run python scripts/export_contracts.py; git diff --exit-code contracts/generated }
Invoke-Checked "node format" { pnpm --filter franchise-bridge format:check; pnpm --filter web format:check }
Invoke-Checked "node lint" { pnpm --filter franchise-bridge lint; pnpm --filter web lint }
Invoke-Checked "bridge types" { pnpm --filter franchise-bridge exec tsc --noEmit }
Invoke-Checked "web types" { pnpm --filter web exec tsc --noEmit }
Invoke-Checked "node tests" { pnpm --filter franchise-bridge test; pnpm --filter web test }
Invoke-Checked "frontend build" { pnpm --filter web build }
Invoke-Checked "synthetic replay" { uv run gbc replay --fixture fixtures/synthetic/drive-scoring-void }
Invoke-Checked "benchmark" { uv run gbc benchmark --fixture fixtures/synthetic/drive-scoring-void --out reports }
Invoke-Checked "private scan" { uv run python scripts/scan_private.py }
Invoke-Checked "pip-audit" { uv run pip-audit }
Invoke-Checked "pnpm audit" { pnpm audit --prod }
Invoke-Checked "git diff check" { git diff --check }

Write-Host "verify.ps1 passed"
