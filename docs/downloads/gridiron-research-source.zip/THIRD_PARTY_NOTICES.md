# Third-Party Notices

This product includes or may optionally use:

| Component | License | Notes |
| --- | --- | --- |
| madden-franchise | MIT | Node bridge only; read-only |
| windows-capture | MIT | Optional Windows extra |
| dxcam | MIT | Optional fallback |
| RapidOCR | Apache-2.0 | Optional OCR; model copyright Baidu |
| PaddleOCR | Apache-2.0 | Optional benchmark |
| FastAPI, Pydantic, SQLAlchemy, and other Python deps | Various OSI | See lockfile |
| React, Vite, TanStack Query | MIT | Dashboard |
| Kokoro-82M | Apache-2.0 | Optional weights, not bundled |
| kokoro-onnx | MIT | Optional TTS wrapper |
| Qwen3-VL | Apache-2.0 | Optional endpoint; weights not bundled |

Proact-VL (MIT / Apache-2.0) is a research reference only and is not a required dependency.

Video2Text source was not copied (no license observed on 2026-08-16).

FMT is not included.

Full GPL-3.0 text is in `LICENSE`.
