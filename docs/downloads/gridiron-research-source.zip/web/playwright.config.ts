import { defineConfig, devices } from "@playwright/test";

export default defineConfig({
  testDir: "./tests/e2e",
  webServer: {
    command: "uv run gbc serve --env development",
    port: 8765,
    reuseExistingServer: true,
    timeout: 120000,
  },
  use: {
    baseURL: "http://127.0.0.1:8765",
    ...devices["Desktop Chrome"],
  },
});
