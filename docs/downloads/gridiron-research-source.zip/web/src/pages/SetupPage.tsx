import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { api } from "../api/client";

type WindowInfo = { target_id: string; title: string; kind: string };

export function SetupPage() {
  const client = useQueryClient();
  const [savePath, setSavePath] = useState("");
  const [team, setTeam] = useState("CHI");
  const [pbpVoice, setPbpVoice] = useState("generic-play-by-play");
  const [analystVoice, setAnalystVoice] = useState("generic-analyst");
  const windows = useQuery({
    queryKey: ["windows"],
    queryFn: () => api<WindowInfo[]>("/api/v1/windows"),
  });
  const ack = useMutation({
    mutationFn: () =>
      api("/api/v1/safety/ack", {
        method: "POST",
        body: JSON.stringify({ acknowledged: true }),
      }),
  });
  const capture = useMutation({
    mutationFn: (target_id: string) =>
      api("/api/v1/capture/start", {
        method: "POST",
        body: JSON.stringify({ target_id }),
      }),
  });
  const snapshot = useMutation({
    mutationFn: () =>
      api("/api/v1/franchise/snapshot", {
        method: "POST",
        body: JSON.stringify({ path: savePath }),
      }),
  });
  const session = useMutation({
    mutationFn: () =>
      api("/api/v1/session/start", {
        method: "POST",
        body: JSON.stringify({
          human_team: team,
          profile_id: "synthetic-16x9",
        }),
      }),
    onSuccess: () => client.invalidateQueries({ queryKey: ["health"] }),
  });

  return (
    <section>
      <h2>Setup</h2>
      <ol>
        <li>
          <button onClick={() => ack.mutate()}>
            Acknowledge safety boundary
          </button>
          {ack.isSuccess && <span> acknowledged</span>}
        </li>
        <li>
          <p>
            Select a capturable window. Default is the synthetic HUD when Madden
            is not running.
          </p>
          <ul>
            {(windows.data ?? []).map((item) => (
              <li key={item.target_id}>
                <button onClick={() => capture.mutate(item.target_id)}>
                  {item.title} ({item.kind})
                </button>
              </li>
            ))}
          </ul>
        </li>
        <li>
          <label>
            Offline Franchise save path
            <input
              value={savePath}
              onChange={(e) => setSavePath(e.target.value)}
            />
          </label>
          <button onClick={() => snapshot.mutate()} disabled={!savePath}>
            Snapshot (read-only copy)
          </button>
        </li>
        <li>
          <label>
            Human team
            <input value={team} onChange={(e) => setTeam(e.target.value)} />
          </label>
          <label>
            Play-by-play voice
            <select
              value={pbpVoice}
              onChange={(e) => setPbpVoice(e.target.value)}
            >
              <option value="generic-play-by-play">Generic play-by-play</option>
              <option value="generic-play-by-play-alt">
                Generic play-by-play (alt)
              </option>
            </select>
          </label>
          <label>
            Analyst voice
            <select
              value={analystVoice}
              onChange={(e) => setAnalystVoice(e.target.value)}
            >
              <option value="generic-analyst">Generic analyst</option>
              <option value="generic-analyst-alt">Generic analyst (alt)</option>
            </select>
          </label>
          <button onClick={() => session.mutate()}>Start session</button>
        </li>
      </ol>
      <p>
        Mute Madden commentary in-game. This companion does not duck EA audio.
      </p>
    </section>
  );
}
