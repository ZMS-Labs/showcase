import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { api } from "../api/client";

export function PronunciationsPage() {
  const client = useQueryClient();
  const [name, setName] = useState("");
  const [phoneme, setPhoneme] = useState("");
  const list = useQuery({
    queryKey: ["pron"],
    queryFn: () => api<Record<string, string>>("/api/v1/pronunciations"),
  });
  const save = useMutation({
    mutationFn: () =>
      api("/api/v1/pronunciations", {
        method: "POST",
        body: JSON.stringify({ name, phoneme }),
      }),
    onSuccess: () => client.invalidateQueries({ queryKey: ["pron"] }),
  });
  return (
    <section>
      <h2>Pronunciations</h2>
      <input
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <input
        placeholder="Phoneme"
        value={phoneme}
        onChange={(e) => setPhoneme(e.target.value)}
      />
      <button onClick={() => save.mutate()}>Save override</button>
      <pre>{JSON.stringify(list.data, null, 2)}</pre>
    </section>
  );
}
