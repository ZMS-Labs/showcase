import { useMutation } from "@tanstack/react-query";
import { api } from "../api/client";

export function ReplayPage() {
  const run = useMutation({
    mutationFn: () =>
      api<Record<string, unknown>>("/api/v1/replay/run", {
        method: "POST",
        body: JSON.stringify({ fixture: "drive-scoring-void" }),
      }),
  });
  return (
    <section>
      <h2>Replay and evaluation</h2>
      <button onClick={() => run.mutate()}>Run synthetic fixture</button>
      {run.data && <pre>{JSON.stringify(run.data, null, 2)}</pre>}
    </section>
  );
}
