import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRef, useState, type MouseEvent } from "react";
import { api } from "../api/client";

type Roi = {
  roi_id: string;
  roi_type: string;
  x: number;
  y: number;
  w: number;
  h: number;
};

type Profile = {
  profile_id: string;
  revision: number;
  capture_width: number;
  capture_height: number;
  roi_definitions: Roi[];
  stale?: boolean;
};

const DEFAULT_PROFILE: Profile = {
  profile_id: "operator-lab",
  revision: 1,
  capture_width: 1280,
  capture_height: 720,
  roi_definitions: [],
};

export function CaptureLabPage() {
  const client = useQueryClient();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const [drawing, setDrawing] = useState<{ x: number; y: number } | null>(null);
  const [draft, setDraft] = useState<Roi | null>(null);
  const [roiType, setRoiType] = useState("HOME_SCORE");
  const [zoom, setZoom] = useState(1);
  const [frozen, setFrozen] = useState(false);
  const [ocr, setOcr] = useState<Record<string, unknown> | null>(null);
  const types = useQuery({
    queryKey: ["roi-types"],
    queryFn: () => api<string[]>("/api/v1/lab/roi-types"),
  });
  const profiles = useQuery({
    queryKey: ["profiles"],
    queryFn: () => api<Profile[]>("/api/v1/profiles"),
  });
  const current = profiles.data?.[0] ?? DEFAULT_PROFILE;
  const [rois, setRois] = useState<Roi[]>(current.roi_definitions);

  const freeze = useMutation({
    mutationFn: (value: boolean) =>
      api("/api/v1/lab/freeze", {
        method: "POST",
        body: JSON.stringify({ frozen: value }),
      }),
    onSuccess: (_data, value) => setFrozen(value),
  });
  const save = useMutation({
    mutationFn: () =>
      api("/api/v1/profiles", {
        method: "POST",
        body: JSON.stringify({
          profile: {
            profile_id: current.profile_id,
            revision: current.revision,
            capture_width: 1280,
            capture_height: 720,
            created_at: new Date().toISOString(),
            roi_definitions: rois,
            preprocessing_settings: {},
            temporal_thresholds: {},
            visual_anchors: [],
            validation_results: {},
            stale: false,
          },
        }),
      }),
    onSuccess: () => client.invalidateQueries({ queryKey: ["profiles"] }),
  });
  const testRoi = useMutation({
    mutationFn: (roi: Roi) =>
      api<Record<string, unknown>>("/api/v1/lab/ocr-test", {
        method: "POST",
        body: JSON.stringify({ ...roi, variant: "default" }),
      }),
    onSuccess: (data) => setOcr(data),
  });

  function rel(event: MouseEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) / rect.width,
      y: (event.clientY - rect.top) / rect.height,
    };
  }

  function paint(next: Roi[]) {
    const canvas = canvasRef.current;
    const img = imgRef.current;
    if (!canvas || !img) return;
    canvas.width = img.clientWidth;
    canvas.height = img.clientHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (const roi of next) {
      ctx.strokeStyle = "#5ee0a0";
      ctx.lineWidth = 2;
      ctx.strokeRect(
        roi.x * canvas.width,
        roi.y * canvas.height,
        roi.w * canvas.width,
        roi.h * canvas.height,
      );
      ctx.fillStyle = "#5ee0a0";
      ctx.fillText(
        roi.roi_type,
        roi.x * canvas.width + 4,
        roi.y * canvas.height + 12,
      );
    }
    if (draft) {
      ctx.strokeStyle = "#f0c14b";
      ctx.strokeRect(
        draft.x * canvas.width,
        draft.y * canvas.height,
        draft.w * canvas.width,
        draft.h * canvas.height,
      );
    }
  }

  return (
    <section>
      <h2>Capture Lab</h2>
      <p>
        Draw normalized ROIs on the preview. Coordinates are 0–1 relative to
        captured content. Do not ship guessed Madden coordinates.
      </p>
      <div className="lab-toolbar">
        <label>
          ROI type
          <select value={roiType} onChange={(e) => setRoiType(e.target.value)}>
            {(types.data ?? ["HOME_SCORE"]).map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>
        </label>
        <label>
          Zoom
          <input
            type="range"
            min={1}
            max={3}
            step={0.1}
            value={zoom}
            onChange={(e) => setZoom(Number(e.target.value))}
          />
        </label>
        <button onClick={() => freeze.mutate(!frozen)}>
          {frozen ? "Unfreeze" : "Freeze frame"}
        </button>
        <button onClick={() => save.mutate()}>Save profile revision</button>
      </div>
      <div className="lab-stage" style={{ transform: `scale(${zoom})` }}>
        <img
          ref={imgRef}
          alt="lab preview"
          src="/api/v1/capture/preview"
          width={960}
          height={540}
          onLoad={() => paint(rois)}
        />
        <canvas
          ref={canvasRef}
          className="lab-overlay"
          width={960}
          height={540}
          onMouseDown={(event) => setDrawing(rel(event))}
          onMouseMove={(event) => {
            if (!drawing) return;
            const point = rel(event);
            const next = {
              roi_id: `${roiType.toLowerCase()}-${rois.length + 1}`,
              roi_type: roiType,
              x: Math.min(drawing.x, point.x),
              y: Math.min(drawing.y, point.y),
              w: Math.abs(point.x - drawing.x),
              h: Math.abs(point.y - drawing.y),
            };
            setDraft(next);
            paint([...rois, next]);
          }}
          onMouseUp={() => {
            if (draft && draft.w > 0.005 && draft.h > 0.005) {
              const next = [...rois, draft];
              setRois(next);
              paint(next);
            }
            setDrawing(null);
            setDraft(null);
          }}
        />
      </div>
      <ul className="roi-list">
        {rois.map((roi) => (
          <li key={roi.roi_id}>
            {roi.roi_type} ({roi.x.toFixed(3)}, {roi.y.toFixed(3)})
            <button onClick={() => testRoi.mutate(roi)}>Test OCR</button>
          </li>
        ))}
      </ul>
      {ocr && (
        <div>
          <h3>OCR and temporal consensus</h3>
          <pre>{JSON.stringify(ocr, null, 2)}</pre>
        </div>
      )}
    </section>
  );
}
