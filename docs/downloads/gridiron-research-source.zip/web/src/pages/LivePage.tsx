import { useMutation, useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { api } from "../api/client";

type LiveState = {
  capture: Record<string, unknown>;
  phase: string;
  raw_ocr: Record<string, unknown>;
  scoreboard: Record<string, unknown> | null;
  field_confidence: Record<string, string>;
  current_event: Record<string, unknown> | null;
  statistics: Record<string, unknown>;
  storylines: unknown[];
  repeated_plays: unknown[];
  last_utterance: string | null;
  queued_speech: string[];
  commentary_latency_ms: number;
  tts_latency_ms: number;
  dropped_frames: number;
  validation_failures: number;
  degraded: string[];
  muted: boolean;
  profile_stale: boolean;
};

export function LivePage() {
  const [overlay, setOverlay] = useState(true);
  const live = useQuery({
    queryKey: ["live-state"],
    queryFn: () => api<LiveState>("/api/v1/live/state"),
    refetchInterval: 1000,
  });
  const mute = useMutation({
    mutationFn: () => api("/api/v1/audio/mute", { method: "POST" }),
  });
  const stop = useMutation({
    mutationFn: () => api("/api/v1/session/stop", { method: "POST" }),
  });
  const data = live.data;

  return (
    <section>
      <h2>Live broadcast</h2>
      <div className="live-grid">
        <div>
          <img
            alt="capture preview"
            src="/api/v1/capture/preview"
            width={640}
            height={360}
            className={overlay ? "roi-overlay-on" : undefined}
          />
          <label>
            <input
              type="checkbox"
              checked={overlay}
              onChange={(e) => setOverlay(e.target.checked)}
            />
            ROI overlay
          </label>
        </div>
        <dl className="live-metrics">
          <dt>Game phase</dt>
          <dd>{data?.phase ?? "UNKNOWN"}</dd>
          <dt>Current event</dt>
          <dd>{JSON.stringify(data?.current_event ?? "none")}</dd>
          <dt>Field confidence</dt>
          <dd>{JSON.stringify(data?.field_confidence ?? {})}</dd>
          <dt>Dropped frames</dt>
          <dd>{data?.dropped_frames ?? 0}</dd>
          <dt>Validation failures</dt>
          <dd>{data?.validation_failures ?? 0}</dd>
          <dt>Commentary latency ms</dt>
          <dd>{data?.commentary_latency_ms ?? 0}</dd>
          <dt>TTS latency ms</dt>
          <dd>{data?.tts_latency_ms ?? 0}</dd>
          <dt>Last utterance</dt>
          <dd>{data?.last_utterance ?? "(silence)"}</dd>
          <dt>Queued speech</dt>
          <dd>{(data?.queued_speech ?? []).join(" | ") || "(empty)"}</dd>
          <dt>Degraded</dt>
          <dd>{(data?.degraded ?? []).join(", ") || "none"}</dd>
          <dt>Profile stale</dt>
          <dd>{String(data?.profile_stale ?? true)}</dd>
          <dt>Muted</dt>
          <dd>{String(data?.muted ?? false)}</dd>
        </dl>
      </div>
      <h3>Stable scoreboard</h3>
      <pre>{JSON.stringify(data?.scoreboard, null, 2)}</pre>
      <h3>Raw OCR</h3>
      <pre>{JSON.stringify(data?.raw_ocr, null, 2)}</pre>
      <h3>Statistics</h3>
      <pre>{JSON.stringify(data?.statistics, null, 2)}</pre>
      <h3>Storylines and repeated plays</h3>
      <pre>
        {JSON.stringify(
          {
            storylines: data?.storylines,
            repeated_plays: data?.repeated_plays,
          },
          null,
          2,
        )}
      </pre>
      <button onClick={() => mute.mutate()}>Panic mute</button>
      <button onClick={() => stop.mutate()}>Stop session</button>
    </section>
  );
}
