import { useQuery } from "@tanstack/react-query";
import { api } from "../api/client";

export function FranchisePage() {
  const caps = useQuery({
    queryKey: ["caps"],
    queryFn: () =>
      api<Record<string, unknown>>("/api/v1/franchise/capabilities"),
  });
  return (
    <section>
      <h2>Franchise inspector</h2>
      <p>Read-only. There are no edit controls.</p>
      <pre>{JSON.stringify(caps.data, null, 2)}</pre>
    </section>
  );
}
