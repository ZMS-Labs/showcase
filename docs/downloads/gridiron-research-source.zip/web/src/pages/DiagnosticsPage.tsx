import { useMutation, useQuery } from "@tanstack/react-query";
import { api } from "../api/client";

export function DiagnosticsPage() {
  const health = useQuery({
    queryKey: ["health"],
    queryFn: () => api<Record<string, unknown>>("/api/v1/health"),
  });
  const test = useMutation({
    mutationFn: () => api("/api/v1/providers/test", { method: "POST" }),
  });
  return (
    <section>
      <h2>Diagnostics</h2>
      <pre>{JSON.stringify(health.data, null, 2)}</pre>
      <button onClick={() => test.mutate()}>Test providers</button>
      {test.data !== undefined && (
        <pre>{JSON.stringify(test.data, null, 2)}</pre>
      )}
      <p>Diagnostic bundles never include raw frames unless you opt in.</p>
    </section>
  );
}
