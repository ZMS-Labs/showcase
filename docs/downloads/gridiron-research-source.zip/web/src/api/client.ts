export type PageId =
  | "setup"
  | "live"
  | "lab"
  | "replay"
  | "franchise"
  | "pronunciations"
  | "diagnostics";

export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    ...init,
  });
  if (!response.ok) {
    throw new Error(`${path} failed: ${response.status}`);
  }
  return (await response.json()) as T;
}
