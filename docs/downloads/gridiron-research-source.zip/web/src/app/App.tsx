import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { api, type PageId } from "../api/client";
import { CaptureLabPage } from "../pages/CaptureLabPage";
import { DiagnosticsPage } from "../pages/DiagnosticsPage";
import { FranchisePage } from "../pages/FranchisePage";
import { LivePage } from "../pages/LivePage";
import { PronunciationsPage } from "../pages/PronunciationsPage";
import { ReplayPage } from "../pages/ReplayPage";
import { SetupPage } from "../pages/SetupPage";

const PAGES: { id: PageId; label: string }[] = [
  { id: "setup", label: "Setup" },
  { id: "live", label: "Live" },
  { id: "lab", label: "Capture Lab" },
  { id: "replay", label: "Replay" },
  { id: "franchise", label: "Franchise" },
  { id: "pronunciations", label: "Pronunciations" },
  { id: "diagnostics", label: "Diagnostics" },
];

export function App() {
  const [page, setPage] = useState<PageId>("setup");
  const health = useQuery({
    queryKey: ["health"],
    queryFn: () =>
      api<{ status: string; degraded: string[]; muted: boolean }>(
        "/api/v1/health",
      ),
    refetchInterval: 2000,
  });

  return (
    <div className="shell">
      <header>
        <h1>Gridiron Broadcast Companion</h1>
        <p className="disclaimer">
          Unofficial fan-created research project. Not affiliated with or
          endorsed by Electronic Arts, EA SPORTS, the NFL, the NFLPA, any
          broadcaster, or any announcer.
        </p>
        <div className="status">
          <span>health: {health.data?.status ?? "loading"}</span>
          <span>
            degraded: {(health.data?.degraded ?? []).join(", ") || "none"}
          </span>
          <span>muted: {String(health.data?.muted ?? false)}</span>
        </div>
      </header>
      <nav>
        {PAGES.map((item) => (
          <button
            key={item.id}
            data-active={page === item.id}
            onClick={() => setPage(item.id)}
          >
            {item.label}
          </button>
        ))}
      </nav>
      <main>
        {page === "setup" && <SetupPage />}
        {page === "live" && <LivePage />}
        {page === "lab" && <CaptureLabPage />}
        {page === "replay" && <ReplayPage />}
        {page === "franchise" && <FranchisePage />}
        {page === "pronunciations" && <PronunciationsPage />}
        {page === "diagnostics" && <DiagnosticsPage />}
      </main>
    </div>
  );
}
