import { test, expect } from "@playwright/test";

test("setup to replay", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByText("Gridiron Broadcast Companion")).toBeVisible();
  await page
    .getByRole("button", { name: "Acknowledge safety boundary" })
    .click();
  await page.getByRole("button", { name: "Replay" }).click();
  await page.getByRole("button", { name: "Run synthetic fixture" }).click();
  await expect(page.getByText("drive-scoring-void")).toBeVisible({
    timeout: 30000,
  });
});
