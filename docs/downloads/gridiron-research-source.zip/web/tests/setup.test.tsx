import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { SetupPage } from "../src/pages/SetupPage";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

describe("setup page", () => {
  it("renders safety acknowledgment", () => {
    const html = renderToStaticMarkup(
      <QueryClientProvider client={new QueryClient()}>
        <SetupPage />
      </QueryClientProvider>,
    );
    expect(html).toContain("Acknowledge safety boundary");
  });
});
