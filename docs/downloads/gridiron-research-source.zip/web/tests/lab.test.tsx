import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { CaptureLabPage } from "../src/pages/CaptureLabPage";
import { LivePage } from "../src/pages/LivePage";

describe("dashboard pages", () => {
  it("renders capture lab drawing controls", () => {
    const html = renderToStaticMarkup(
      <QueryClientProvider client={new QueryClient()}>
        <CaptureLabPage />
      </QueryClientProvider>,
    );
    expect(html).toContain("Draw normalized ROIs");
    expect(html).toContain("Save profile revision");
    expect(html).toContain("Freeze frame");
  });

  it("renders live broadcast metrics", () => {
    const html = renderToStaticMarkup(
      <QueryClientProvider client={new QueryClient()}>
        <LivePage />
      </QueryClientProvider>,
    );
    expect(html).toContain("Panic mute");
    expect(html).toContain("Stable scoreboard");
    expect(html).toContain("Validation failures");
  });
});
