# Contract generation

Pydantic models in `backend/src/gbc/contracts` are authoritative.

```powershell
uv run python scripts/export_contracts.py
```

CI fails if `contracts/generated` differs from a fresh export.
