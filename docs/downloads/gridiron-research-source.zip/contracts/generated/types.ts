/* Generated from Pydantic contracts. Do not edit. */
export type Authority = 'USER_CONFIRMED' | 'FRANCHISE_SAVE' | 'OCR_CONSENSUS' | 'DETERMINISTIC_DIFF' | 'VISIBLE_PLAY_SELECTION' | 'VISION_INFERENCE' | 'HEURISTIC';
export type EventStatus = 'PROVISIONAL' | 'CONFIRMED' | 'CORRECTED' | 'VOIDED';
export type GamePhase = 'PREGAME' | 'PLAYCALL' | 'PRESNAP' | 'LIVE_PLAY' | 'POSTPLAY_PENDING' | 'POSTPLAY_STABLE' | 'PENALTY' | 'REVIEW' | 'REPLAY' | 'TIMEOUT' | 'QUARTER_BREAK' | 'HALFTIME' | 'FINAL' | 'UNKNOWN';
export type Speaker = 'PLAY_BY_PLAY' | 'ANALYST';
export interface CaptureTarget { target_id: string; title: string; process_name?: string | null; kind: string; width?: number | null; height?: number | null; }
export interface Health { status: string; version: string; degraded: string[]; muted: boolean; }
