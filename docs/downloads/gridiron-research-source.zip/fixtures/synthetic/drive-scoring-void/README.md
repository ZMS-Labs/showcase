# drive-scoring-void

Synthetic fixture with original generic HUD graphics (no EA assets).

1. Confirmed run for positive yards.
2. Flagged play voided with no score change.
3. Confirmed touchdown on a repeated Mesh Spot family.
