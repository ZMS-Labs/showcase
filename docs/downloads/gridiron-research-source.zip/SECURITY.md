# Security

## Product boundary

Gridiron Broadcast Companion must never be used to attack, inject, debug, or modify Madden NFL, EA anti-cheat, or other users' systems.

Report security issues privately to the operator. Do not file public issues that include Franchise saves, captures, API keys, or exploits.

## Runtime defaults

- Loopback bind only (`127.0.0.1`)
- No telemetry
- Secrets via environment or Windows Credential Manager
- Franchise originals are copied, never parsed in place, never written

## Dependency audits

`.\scripts\verify.ps1` runs `uv run pip-audit` and `pnpm audit` where practical.
