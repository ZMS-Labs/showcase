from __future__ import annotations

import asyncio
import hashlib
import sys
from collections.abc import AsyncIterator
from datetime import UTC, datetime

import numpy as np

from gbc.capture.interface import CaptureSource
from gbc.capture.queue import BoundedLatestQueue
from gbc.capture.synthetic import render_synthetic_hud
from gbc.contracts.capture import CaptureHealth, CaptureOptions, CaptureTarget, FrameEnvelope
from gbc.contracts.enums import CaptureBackendName


class WindowsCaptureSource(CaptureSource):
    """Preferred window capture via documented Win32 APIs, then windows-capture if installed."""

    def __init__(self) -> None:
        self._running = False
        self._health = CaptureHealth(running=False, message="not started")
        self._target: CaptureTarget | None = None
        self._options = CaptureOptions()
        self._seq = 0
        self._queue: BoundedLatestQueue[tuple[FrameEnvelope, np.ndarray]] = BoundedLatestQueue(2)
        self._last_bgr: np.ndarray | None = None
        self._backend = CaptureBackendName.WINDOWS_CAPTURE

    def list_targets(self) -> list[CaptureTarget]:
        if sys.platform != "win32":
            return []
        try:
            import ctypes
            from ctypes import wintypes
        except Exception:
            return []
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        targets: list[CaptureTarget] = []

        @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)  # type: ignore[misc,untyped-decorator]
        def _enum(hwnd: int, _lparam: int) -> bool:
            if not user32.IsWindowVisible(hwnd):
                return True
            length = user32.GetWindowTextLengthW(hwnd)
            if length == 0:
                return True
            buf = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buf, length + 1)
            title = buf.value
            if title:
                targets.append(CaptureTarget(target_id=str(int(hwnd)), title=title, process_name=None))
            return True

        user32.EnumWindows(_enum, 0)
        return targets

    def start(self, target: CaptureTarget, options: CaptureOptions) -> None:
        if target.kind == "monitor" and not options.allow_monitor:
            raise PermissionError("Full-monitor capture requires an explicit user action")
        self._target = target
        self._options = options
        self._seq = 0
        self._running = True
        if target.kind == "synthetic":
            self._backend = CaptureBackendName.SYNTHETIC
            self._last_bgr = render_synthetic_hud()
            self._health = CaptureHealth(
                running=True, message=f"capturing {target.title}", fps=float(options.target_fps)
            )
            return
        frame = self._grab()
        if frame is None:
            self._running = False
            self._health = CaptureHealth(
                running=False,
                window_lost=True,
                message="window capture failed; select another window or use synthetic HUD",
            )
            return
        self._last_bgr = frame
        self._health = CaptureHealth(
            running=True,
            message=f"capturing {target.title}",
            fps=float(options.target_fps),
            minimized=self._minimized(),
        )

    def grab_latest(self) -> np.ndarray | None:
        if not self._running or self._target is None:
            return self._last_bgr
        if self._target.kind == "synthetic":
            self._last_bgr = render_synthetic_hud()
            return self._last_bgr
        frame = self._grab()
        if frame is not None:
            self._last_bgr = frame
        return self._last_bgr

    async def frames(self) -> AsyncIterator[FrameEnvelope]:
        interval = 1.0 / max(1, self._options.target_fps)
        while self._running and self._target is not None:
            array = self.grab_latest()
            if array is None:
                self._health.window_lost = True
                self._health.message = "capture lost"
                break
            self._seq += 1
            env = FrameEnvelope(
                frame_id=f"win-{self._seq:08d}",
                sequence=self._seq,
                captured_at_utc=datetime.now(tz=UTC),
                captured_at_monotonic_ns=time_monotonic_ns(),
                width=int(array.shape[1]),
                height=int(array.shape[0]),
                capture_backend=self._backend,
                window_identity=self._target.target_id,
                in_memory_frame_reference=hashlib.sha256(array.tobytes()).hexdigest()[:16],
            )
            self._queue.put((env, array))
            self._health.dropped_frames = self._queue.stats.dropped
            self._health.queue_depth = len(self._queue)
            yield env
            await asyncio.sleep(interval)

    def stop(self) -> None:
        self._running = False
        self._health = CaptureHealth(running=False, message="stopped")

    def health(self) -> CaptureHealth:
        return self._health

    def latest_frame_bytes(self) -> bytes | None:
        if self._last_bgr is None:
            return None
        from io import BytesIO

        from PIL import Image

        rgb = self._last_bgr[:, :, ::-1]
        buf = BytesIO()
        Image.fromarray(rgb).save(buf, format="PNG")
        return buf.getvalue()

    def _minimized(self) -> bool:
        if self._target is None or self._target.kind == "synthetic":
            return False
        try:
            hwnd = int(self._target.target_id)
        except ValueError:
            return False
        from gbc.capture.win32_grab import window_is_minimized

        return window_is_minimized(hwnd)

    def _grab(self) -> np.ndarray | None:
        if self._target is None:
            return None
        try:
            hwnd = int(self._target.target_id)
        except ValueError:
            return None
        from gbc.capture.win32_grab import grab_window_bgr, is_probably_black, window_exists, window_is_minimized

        if not window_exists(hwnd):
            self._health.window_lost = True
            return None
        if window_is_minimized(hwnd):
            self._health.minimized = True
            self._health.message = "window minimized; capture paused"
            return None
        frame = grab_window_bgr(hwnd)
        if frame is None:
            return None
        if is_probably_black(frame):
            self._health.message = "captured frame is black; use borderless-windowed mode or Graphics Capture extras"
        return frame


def time_monotonic_ns() -> int:
    import time

    return time.monotonic_ns()
