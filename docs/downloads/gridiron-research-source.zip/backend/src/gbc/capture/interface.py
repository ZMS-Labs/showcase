from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator

from gbc.contracts.capture import CaptureHealth, CaptureOptions, CaptureTarget, FrameEnvelope


class CaptureSource(ABC):
    @abstractmethod
    def list_targets(self) -> list[CaptureTarget]:
        raise NotImplementedError

    @abstractmethod
    def start(self, target: CaptureTarget, options: CaptureOptions) -> None:
        raise NotImplementedError

    @abstractmethod
    def frames(self) -> AsyncIterator[FrameEnvelope]:
        raise NotImplementedError

    @abstractmethod
    def stop(self) -> None:
        raise NotImplementedError

    @abstractmethod
    def health(self) -> CaptureHealth:
        raise NotImplementedError

    def latest_frame_bytes(self) -> bytes | None:
        return None
