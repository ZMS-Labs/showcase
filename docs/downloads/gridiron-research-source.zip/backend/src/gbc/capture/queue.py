from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Generic, TypeVar

T = TypeVar("T")


@dataclass
class QueueStats:
    dropped: int = 0
    depth: int = 0
    enqueued: int = 0


class BoundedLatestQueue(Generic[T]):
    """Latest-frame-wins bounded queue. Capture callbacks only enqueue."""

    def __init__(self, maxsize: int = 2) -> None:
        if maxsize < 1:
            raise ValueError("maxsize must be >= 1")
        self.maxsize = maxsize
        self._items: deque[T] = deque()
        self.stats = QueueStats()

    def put(self, item: T) -> None:
        self.stats.enqueued += 1
        if len(self._items) >= self.maxsize:
            self._items.popleft()
            self.stats.dropped += 1
        self._items.append(item)
        self.stats.depth = len(self._items)

    def get_latest(self) -> T | None:
        if not self._items:
            return None
        item = self._items.pop()
        self._items.clear()
        self.stats.depth = 0
        return item

    def __len__(self) -> int:
        return len(self._items)
