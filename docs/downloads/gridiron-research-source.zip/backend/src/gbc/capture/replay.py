from __future__ import annotations

import json
from collections.abc import AsyncIterator
from pathlib import Path

from gbc.capture.interface import CaptureSource
from gbc.clocks import FakeClock
from gbc.contracts.capture import CaptureHealth, CaptureOptions, CaptureTarget, FrameEnvelope
from gbc.contracts.enums import CaptureBackendName
from gbc.replay.clock import ReplayClock


class ReplayCaptureSource(CaptureSource):
    def __init__(self, fixture_dir: Path, clock: ReplayClock | None = None) -> None:
        self.fixture_dir = fixture_dir
        self.manifest = json.loads((fixture_dir / "manifest.json").read_text(encoding="utf-8"))
        self.clock = clock or ReplayClock(FakeClock())
        self._running = False
        self._index = 0

    def list_targets(self) -> list[CaptureTarget]:
        return [
            CaptureTarget(
                target_id="replay",
                title=self.manifest.get("name", "replay"),
                kind="replay",
                width=self.manifest["width"],
                height=self.manifest["height"],
            )
        ]

    def start(self, target: CaptureTarget, options: CaptureOptions) -> None:
        del target, options
        self._running = True
        self._index = 0

    async def frames(self) -> AsyncIterator[FrameEnvelope]:
        timestamps = self.manifest.get("timestamps", [])
        for i, ts in enumerate(timestamps, start=1):
            if not self._running:
                break
            mono = int(ts)
            self.clock.set_monotonic(mono)
            yield FrameEnvelope(
                frame_id=f"rep-{i:08d}",
                sequence=i,
                captured_at_utc=self.clock.now_utc(),
                captured_at_monotonic_ns=mono,
                width=self.manifest["width"],
                height=self.manifest["height"],
                capture_backend=CaptureBackendName.REPLAY,
                window_identity="replay",
                in_memory_frame_reference=f"frame-{i:08d}",
            )

    def stop(self) -> None:
        self._running = False

    def health(self) -> CaptureHealth:
        return CaptureHealth(running=self._running, fps=float(self.manifest.get("frame_rate", 10)))
