from __future__ import annotations

from collections.abc import AsyncIterator

from gbc.capture.interface import CaptureSource
from gbc.contracts.capture import CaptureHealth, CaptureOptions, CaptureTarget, FrameEnvelope


class DxcamCaptureSource(CaptureSource):
    def __init__(self) -> None:
        self._running = False
        self._monitor_confirmed = False

    def list_targets(self) -> list[CaptureTarget]:
        return [
            CaptureTarget(
                target_id="monitor-0",
                title="Primary monitor (explicit confirmation required)",
                kind="monitor",
            )
        ]

    def start(self, target: CaptureTarget, options: CaptureOptions) -> None:
        if target.kind == "monitor" and not options.allow_monitor:
            raise PermissionError("Full-monitor capture requires an explicit user action")
        self._monitor_confirmed = bool(options.allow_monitor)
        self._running = True

    async def frames(self) -> AsyncIterator[FrameEnvelope]:
        if self._running:
            return
        if False:  # pragma: no cover
            yield FrameEnvelope.model_construct()

    def stop(self) -> None:
        self._running = False

    def health(self) -> CaptureHealth:
        return CaptureHealth(running=self._running, message="dxcam fallback")
