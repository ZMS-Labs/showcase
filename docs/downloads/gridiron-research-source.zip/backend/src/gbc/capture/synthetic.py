from __future__ import annotations

import hashlib
from collections.abc import AsyncIterator

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from gbc.capture.interface import CaptureSource
from gbc.capture.queue import BoundedLatestQueue
from gbc.clocks import Clock, SystemClock
from gbc.contracts.capture import CaptureHealth, CaptureOptions, CaptureTarget, FrameEnvelope
from gbc.contracts.enums import CaptureBackendName


def render_synthetic_hud(
    *,
    width: int = 1280,
    height: int = 720,
    home: str = "CHI",
    away: str = "GB",
    home_score: int = 14,
    away_score: int = 10,
    quarter: int = 2,
    clock: str = "5:42",
    down: int = 3,
    distance: int = 7,
    possession: str = "CHI",
    ball_spot: str = "GB 32",
    play_clock: int = 18,
) -> np.ndarray:
    image = Image.new("RGB", (width, height), (18, 42, 28))
    draw = ImageDraw.Draw(image)
    draw.rectangle([0, 0, width, 90], fill=(12, 12, 12))
    text = (
        f"{away} {away_score}  {home} {home_score}   Q{quarter} {clock}   "
        f"{down} & {distance}  {ball_spot}  POSS {possession}  PC {play_clock}"
    )
    font: object = ImageFont.load_default()
    try:
        font = ImageFont.truetype("arial.ttf", 28)
    except OSError:
        pass
    draw.text((24, 28), text, fill=(240, 240, 240), font=font)  # type: ignore[arg-type]
    draw.rectangle([40, 120, width - 40, height - 40], outline=(200, 200, 200), width=3)
    array = np.array(image)
    return array[:, :, ::-1].copy()  # RGB -> BGR-like BGR for OpenCV habits


class SyntheticCaptureSource(CaptureSource):
    def __init__(self, clock: Clock | None = None, frames_spec: list[dict[str, object]] | None = None) -> None:
        self.clock = clock or SystemClock()
        self.frames_spec = frames_spec or [{}]
        self._running = False
        self._seq = 0
        self._queue: BoundedLatestQueue[tuple[FrameEnvelope, bytes]] = BoundedLatestQueue(2)
        self._target = CaptureTarget(target_id="synthetic", title="Synthetic HUD", kind="synthetic")

    def list_targets(self) -> list[CaptureTarget]:
        return [self._target]

    def start(self, target: CaptureTarget, options: CaptureOptions) -> None:
        del options
        if target.kind == "monitor":
            raise PermissionError("Monitor capture requires an explicit user action")
        self._running = True
        self._seq = 0

    async def frames(self) -> AsyncIterator[FrameEnvelope]:
        for spec in self.frames_spec:
            if not self._running:
                break
            array = render_synthetic_hud(**{k: v for k, v in spec.items() if k != "delay_ms"})  # type: ignore[arg-type]
            png = _encode_png(array)
            self._seq += 1
            env = FrameEnvelope(
                frame_id=f"syn-{self._seq:08d}",
                sequence=self._seq,
                captured_at_utc=self.clock.now_utc(),
                captured_at_monotonic_ns=self.clock.monotonic_ns(),
                width=array.shape[1],
                height=array.shape[0],
                capture_backend=CaptureBackendName.SYNTHETIC,
                window_identity="synthetic",
                in_memory_frame_reference=hashlib.sha256(png).hexdigest()[:16],
            )
            self._queue.put((env, png))
            yield env

    def stop(self) -> None:
        self._running = False

    def health(self) -> CaptureHealth:
        return CaptureHealth(
            running=self._running,
            fps=30.0,
            dropped_frames=self._queue.stats.dropped,
            queue_depth=len(self._queue),
        )

    def latest_frame_bytes(self) -> bytes | None:
        item = self._queue.get_latest()
        return None if item is None else item[1]


def _encode_png(array: np.ndarray) -> bytes:
    from io import BytesIO

    rgb = array[:, :, ::-1]
    image = Image.fromarray(rgb)
    buf = BytesIO()
    image.save(buf, format="PNG")
    return buf.getvalue()
