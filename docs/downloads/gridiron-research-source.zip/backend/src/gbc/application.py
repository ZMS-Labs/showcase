from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import numpy as np

from gbc.clocks import SystemClock
from gbc.config.settings import Settings, load_settings
from gbc.contracts.capture import CaptureHealth, CaptureTarget, DisplayProfile, RoiDefinition, ScoreboardSnapshot
from gbc.contracts.enums import DegradedMode
from gbc.contracts.franchise import CapabilityReport, SnapshotMeta
from gbc.events.reconciler import EventReconciler
from gbc.language.providers import DeterministicTemplateProvider
from gbc.memory.stats import StatisticsEngine
from gbc.memory.tendencies import TendencyEngine
from gbc.perception.consensus import TemporalReconciler
from gbc.persistence.models import make_engine, make_session_factory
from gbc.producer.producer import Producer
from gbc.speech.scheduler import AudioScheduler, MockTTSProvider


@dataclass
class Runtime:
    settings: Settings
    clock: SystemClock = field(default_factory=SystemClock)
    windows: list[CaptureTarget] = field(default_factory=list)
    selected_window: CaptureTarget | None = None
    snapshot: SnapshotMeta | None = None
    capability: CapabilityReport | None = None
    human_team: str | None = None
    profile: DisplayProfile | None = None
    session_id: str | None = None
    degraded: list[DegradedMode] = field(default_factory=lambda: [DegradedMode.NO_VISION])
    muted: bool = False
    capture_health: CaptureHealth = field(default_factory=lambda: CaptureHealth(running=False))
    last_event: dict[str, Any] | None = None
    queued_speech: list[str] = field(default_factory=list)
    validation_failures: int = 0
    safety_ack: bool = False
    capture_source: Any = None
    reconciler: EventReconciler | None = None
    stats: StatisticsEngine = field(default_factory=StatisticsEngine)
    producer: Producer = field(default_factory=Producer)
    scheduler: AudioScheduler = field(default_factory=AudioScheduler)
    commentary: DeterministicTemplateProvider = field(default_factory=DeterministicTemplateProvider)
    tts: MockTTSProvider = field(default_factory=MockTTSProvider)
    preview_png: bytes | None = None
    preview_bgr: np.ndarray | None = None
    last_hud: dict[str, Any] = field(
        default_factory=lambda: {
            "home": "CHI",
            "away": "GB",
            "home_score": 14,
            "away_score": 10,
            "quarter": 2,
            "clock": "5:42",
            "down": 3,
            "distance": 7,
            "possession": "CHI",
            "ball_spot": "GB 32",
            "play_clock": 18,
        }
    )
    lab_frozen: bool = False
    last_ocr: dict[str, Any] = field(default_factory=dict)
    last_scoreboard: ScoreboardSnapshot | None = None
    consensus: TemporalReconciler = field(default_factory=TemporalReconciler)
    tendencies: TendencyEngine = field(default_factory=TendencyEngine)
    storylines: list[dict[str, Any]] = field(default_factory=list)
    annotations: list[dict[str, Any]] = field(default_factory=list)
    commentary_latency_ms: float = 0.0
    tts_latency_ms: float = 0.0
    profiles: dict[str, DisplayProfile] = field(default_factory=dict)
    pronunciations: dict[str, str] = field(default_factory=dict)
    session_factory: Any = None

    def data_dir(self) -> Path:
        path = self.settings.data_path()
        path.mkdir(parents=True, exist_ok=True)
        (path / "snapshots").mkdir(exist_ok=True)
        return path


def create_runtime(settings: Settings | None = None) -> Runtime:
    loaded = settings or load_settings()
    runtime = Runtime(settings=loaded)
    db_path = runtime.data_dir() / "gbc.sqlite"
    engine = make_engine(str(db_path))
    runtime.session_factory = make_session_factory(engine)
    if loaded.providers.vision.type == "disabled":
        if DegradedMode.NO_VISION not in runtime.degraded:
            runtime.degraded.append(DegradedMode.NO_VISION)
    if loaded.providers.commentary.type in {"deterministic", "mock"}:
        runtime.degraded.append(DegradedMode.NO_COMMENTARY_MODEL)
    if loaded.providers.tts.type == "mock":
        runtime.degraded.append(DegradedMode.NO_TTS)
    synthetic = DisplayProfile(
        profile_id="synthetic-16x9",
        revision=1,
        capture_width=1280,
        capture_height=720,
        created_at=datetime.now(tz=UTC),
        roi_definitions=[
            RoiDefinition(roi_id="away_abbrev", roi_type="AWAY_ABBREV", x=0.02, y=0.03, w=0.06, h=0.08),
            RoiDefinition(roi_id="away_score", roi_type="AWAY_SCORE", x=0.08, y=0.03, w=0.05, h=0.08),
            RoiDefinition(roi_id="home_abbrev", roi_type="HOME_ABBREV", x=0.14, y=0.03, w=0.06, h=0.08),
            RoiDefinition(roi_id="home_score", roi_type="HOME_SCORE", x=0.20, y=0.03, w=0.05, h=0.08),
            RoiDefinition(roi_id="quarter", roi_type="QUARTER", x=0.28, y=0.03, w=0.06, h=0.08),
            RoiDefinition(roi_id="game_clock", roi_type="GAME_CLOCK", x=0.35, y=0.03, w=0.08, h=0.08),
            RoiDefinition(roi_id="down", roi_type="DOWN", x=0.46, y=0.03, w=0.04, h=0.08),
            RoiDefinition(roi_id="distance", roi_type="DISTANCE", x=0.52, y=0.03, w=0.05, h=0.08),
            RoiDefinition(roi_id="ball_spot", roi_type="BALL_SPOT", x=0.58, y=0.03, w=0.10, h=0.08),
            RoiDefinition(roi_id="possession", roi_type="POSSESSION", x=0.72, y=0.03, w=0.08, h=0.08),
            RoiDefinition(roi_id="play_clock", roi_type="PLAY_CLOCK", x=0.84, y=0.03, w=0.08, h=0.08),
        ],
        validation_results={"synthetic": "ok"},
    )
    runtime.profiles[synthetic.profile_id] = synthetic
    runtime.profile = synthetic
    return runtime
