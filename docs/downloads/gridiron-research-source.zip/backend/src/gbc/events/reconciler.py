from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from uuid import uuid4

from gbc.contracts.enums import (
    ConfidenceBand,
    EventStatus,
    GamePhase,
    PenaltyState,
    PlayType,
    ReconcilerState,
    ResultType,
)
from gbc.contracts.events import Participants, PlayEvent, PlaySignature
from gbc.contracts.provenance import FieldPosition, yards_gained


@dataclass
class ScoreboardView:
    home_team: str
    away_team: str
    home_score: int
    away_score: int
    quarter: int
    game_clock_ms: int
    down: int | None
    distance: int | None
    possession_team: str | None
    ball_spot: FieldPosition | None
    penalty_visible: bool = False
    review_visible: bool = False
    snap: bool = False
    postplay: bool = False
    playcall_visible: bool = False


def classify_phase(
    previous: GamePhase,
    view: ScoreboardView,
    clock_decreasing: bool,
) -> GamePhase:
    if view.review_visible:
        return GamePhase.REVIEW
    if view.penalty_visible:
        return GamePhase.PENALTY
    if view.playcall_visible:
        return GamePhase.PLAYCALL
    if view.postplay:
        return GamePhase.POSTPLAY_PENDING
    if view.snap or (clock_decreasing and previous in {GamePhase.PRESNAP, GamePhase.LIVE_PLAY}):
        return GamePhase.LIVE_PLAY
    if previous == GamePhase.LIVE_PLAY and not clock_decreasing:
        return GamePhase.POSTPLAY_PENDING
    if view.down is not None:
        return GamePhase.PRESNAP
    return GamePhase.UNKNOWN


def infer_scoring(
    delta_home: int, delta_away: int, offense: str | None, home: str, away: str
) -> tuple[int, ResultType]:
    delta = 0
    if offense == home:
        delta = delta_home
    elif offense == away:
        delta = delta_away
    else:
        delta = max(delta_home, delta_away)
    mapping = {
        6: ResultType.TOUCHDOWN,
        1: ResultType.EXTRA_POINT_GOOD,
        2: ResultType.TWO_POINT_GOOD,
        3: ResultType.FIELD_GOAL_GOOD,
        8: ResultType.TOUCHDOWN,
    }
    if delta_home < 0 or delta_away < 0:
        return 0, ResultType.UNRESOLVED
    return delta, mapping.get(delta, ResultType.GAIN if delta == 0 else ResultType.UNRESOLVED)


class EventReconciler:
    def __init__(self, session_id: str) -> None:
        self.session_id = session_id
        self.state = ReconcilerState.IDLE
        self.phase = GamePhase.UNKNOWN
        self._open: PlayEvent | None = None
        self._pre: ScoreboardView | None = None
        self.events: list[PlayEvent] = []
        self._ids: dict[str, PlayEvent] = {}
        self._last_clock: int | None = None

    def _new_id(self, key: str) -> str:
        return key

    def handle(
        self,
        view: ScoreboardView,
        now: datetime,
        *,
        observation_key: str | None = None,
        signature: PlaySignature | None = None,
        participants: Participants | None = None,
        play_type: PlayType = PlayType.UNKNOWN,
    ) -> PlayEvent | None:
        clock_decreasing = False
        if self._last_clock is not None and view.game_clock_ms < self._last_clock:
            clock_decreasing = True
        self._last_clock = view.game_clock_ms
        self.phase = classify_phase(self.phase, view, clock_decreasing)

        if view.snap and self.state in {ReconcilerState.IDLE, ReconcilerState.COMMITTED}:
            event_id = observation_key or f"play-{uuid4()}"
            if event_id in self._ids:
                return self._ids[event_id]
            self._open = PlayEvent(
                event_id=event_id,
                session_id=self.session_id,
                status=EventStatus.PROVISIONAL,
                started_at=now,
                offense_team=view.possession_team,
                defense_team=_defense(view),
                play_type=play_type,
                play_signature=signature,
                participants=participants or Participants(),
                down=view.down,
                distance=view.distance,
                quarter=view.quarter,
                ball_spot_pre=view.ball_spot,
            )
            self._pre = view
            self.state = ReconcilerState.LIVE
            self._ids[event_id] = self._open
            return self._open

        if self._open is None:
            if view.penalty_visible:
                self.state = ReconcilerState.PENALTY_PENDING
            return None

        if view.penalty_visible:
            self.state = ReconcilerState.PENALTY_PENDING
            self._open.penalty_state = PenaltyState.FLAG
            return self._open

        if view.review_visible:
            self.state = ReconcilerState.REVIEW_PENDING
            return self._open

        if view.postplay or self.phase in {GamePhase.POSTPLAY_PENDING, GamePhase.POSTPLAY_STABLE}:
            return self._commit_from_diff(view, now)

        return self._open

    def _commit_from_diff(self, view: ScoreboardView, now: datetime) -> PlayEvent:
        assert self._open is not None
        assert self._pre is not None
        pre = self._pre
        event = self._open
        dh = view.home_score - pre.home_score
        da = view.away_score - pre.away_score
        scoring_value, result = infer_scoring(dh, da, pre.possession_team, pre.home_team, pre.away_team)
        possession_changed = (
            view.possession_team is not None
            and pre.possession_team is not None
            and view.possession_team != pre.possession_team
        )
        touchdown = result == ResultType.TOUCHDOWN or scoring_value == 6
        yards = None
        if pre.ball_spot and view.ball_spot:
            yards = yards_gained(
                pre.ball_spot,
                view.ball_spot,
                possession_changed=possession_changed and not touchdown,
                touchdown=touchdown,
                touchback=result == ResultType.TOUCHBACK,
            )
        if self.state == ReconcilerState.PENALTY_PENDING and scoring_value == 0 and not possession_changed:
            event.status = EventStatus.VOIDED
            event.result_type = ResultType.PENALTY_NO_PLAY
            event.penalty_state = PenaltyState.NO_PLAY
            event.ended_at = now
            event.scoring_value = 0
            event.touchdown = False
            event.turnover = False
            self.events.append(event)
            self.state = ReconcilerState.COMMITTED
            self._open = None
            return event

        if possession_changed and scoring_value == 0 and not touchdown:
            if event.play_type == PlayType.PASS:
                result = ResultType.INTERCEPTION
            event.turnover = True

        event.ended_at = now
        event.result_type = result
        event.yards = yards
        event.scoring_value = scoring_value
        event.touchdown = touchdown
        event.safety = result == ResultType.SAFETY
        event.ball_spot_post = view.ball_spot
        event.status = EventStatus.CONFIRMED
        event.confidence_by_field = {
            "result_type": ConfidenceBand.HIGH,
            "yards": ConfidenceBand.HIGH if yards is not None else ConfidenceBand.UNKNOWN,
        }
        if pre.down == 4 and possession_changed and scoring_value == 0 and not event.turnover:
            event.result_type = ResultType.TURNOVER_ON_DOWNS
            event.turnover = True
        self.events.append(event)
        self.state = ReconcilerState.COMMITTED
        self._open = None
        return event

    def void_open(self, now: datetime, reason: str) -> PlayEvent | None:
        if self._open is None:
            return None
        self._open.status = EventStatus.VOIDED
        self._open.correction_reason = reason
        self._open.ended_at = now
        self._open.scoring_value = 0
        self.events.append(self._open)
        event = self._open
        self._open = None
        self.state = ReconcilerState.COMMITTED
        return event

    def correct(self, event_id: str, now: datetime, **changes: object) -> PlayEvent:
        original = self._ids[event_id]
        revised = original.model_copy(update=dict(changes))
        revised.revision = original.revision + 1
        revised.status = EventStatus.CORRECTED
        revised.supersedes_revision = original.revision
        revised.ended_at = now
        self._ids[event_id] = revised
        self.events.append(revised)
        return revised

    def canonical(self) -> list[PlayEvent]:
        latest: dict[str, PlayEvent] = {}
        for event in self.events:
            latest[event.event_id] = event
        return [e for e in latest.values() if e.status != EventStatus.VOIDED]


def _defense(view: ScoreboardView) -> str | None:
    if view.possession_team == view.home_team:
        return view.away_team
    if view.possession_team == view.away_team:
        return view.home_team
    return None
