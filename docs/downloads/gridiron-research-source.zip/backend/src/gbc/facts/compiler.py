from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from gbc.contracts.broadcast import Fact, FactPacket, SpeechIntent
from gbc.contracts.enums import (
    Authority,
    ConfidenceBand,
    EpistemicClass,
    FactScope,
    IntentType,
    PlayMatchLevel,
)
from gbc.contracts.events import PlayEvent
from gbc.memory.stats import GameStatistics
from gbc.memory.tendencies import TendencyRecord, narrative_for
from gbc.perception.parsers import NUMBER_WORDS


def _number_words_for(value: int) -> list[str]:
    inverse = {v: k for k, v in NUMBER_WORDS.items() if k not in {"hundred", "thousand"}}
    words = [str(value)]
    if value in inverse:
        words.append(inverse[value])
    if value == 3:
        words.extend(["three", "third"])
    if value == 4:
        words.extend(["four", "fourth"])
    return words


class FactCompiler:
    def compile(
        self,
        intent: SpeechIntent,
        *,
        session_id: str,
        now: datetime,
        event: PlayEvent | None,
        stats: GameStatistics,
        tendency: TendencyRecord | None,
        recently_said: list[str],
        season_facts: list[Fact] | None = None,
        franchise_available: bool = False,
    ) -> FactPacket:
        facts: list[Fact] = []
        names: list[str] = []
        numbers: list[int] = []
        number_words: list[str] = []
        prohibited = [
            "Do not identify the defensive coverage.",
            "Do not name a participant whose identity is unresolved.",
            "Do not calculate new statistics.",
            "Do not mention schemas, fact IDs, models, or confidence systems.",
        ]
        if event and event.participants.receiver:
            names.append(event.participants.receiver)
        if event and event.participants.passer:
            names.append(event.participants.passer)
        if event and event.participants.rusher:
            names.append(event.participants.rusher)
        if event and event.offense_team:
            names.append(event.offense_team)
        if event and event.defense_team:
            names.append(event.defense_team)

        if event and event.status.value in {"CONFIRMED", "CORRECTED"}:
            if event.touchdown:
                facts.append(
                    self._fact(
                        session_id,
                        event.event_id,
                        now,
                        FactScope.PLAY,
                        event.offense_team or "offense",
                        "scored",
                        "touchdown",
                        "Touchdown.",
                        [6],
                        names,
                    )
                )
                numbers.append(6)
            if event.yards is not None:
                facts.append(
                    self._fact(
                        session_id,
                        event.event_id,
                        now,
                        FactScope.PLAY,
                        event.offense_team or "offense",
                        "gained",
                        str(event.yards),
                        f"The play gained {event.yards} yards.",
                        [event.yards],
                        names,
                    )
                )
                numbers.append(event.yards)
                number_words.extend(_number_words_for(event.yards))
            if event.turnover:
                facts.append(
                    self._fact(
                        session_id,
                        event.event_id,
                        now,
                        FactScope.PLAY,
                        event.defense_team or "defense",
                        "forced",
                        "turnover",
                        "The defense has the football after a turnover.",
                        [stats.turnovers],
                        names,
                    )
                )

        if tendency and narrative_for(tendency):
            same = tendency.match_level == PlayMatchLevel.EXACT_VERIFIED_PLAY
            textual = (
                f"Verified play used {tendency.use_count} times."
                if same
                else f"A similar look has appeared {tendency.use_count} times."
            )
            fact = self._fact(
                session_id,
                event.event_id if event else None,
                now,
                FactScope.GAME,
                tendency.key,
                "repeated",
                str(tendency.use_count),
                textual,
                [tendency.use_count, tendency.success_count],
                names,
            )
            fact.allows_same_play_language = same
            facts.append(fact)
            numbers.extend([tendency.use_count, tendency.success_count])
            number_words.extend(_number_words_for(tendency.use_count))

        if intent.intent_type == IntentType.SEASON_CONTEXT:
            if not franchise_available:
                prohibited.append("Do not make season or career claims.")
            else:
                facts.extend(season_facts or [])

        for fact in facts:
            numbers.extend(fact.allowed_numbers)
            number_words.extend(fact.allowed_number_words)
            names.extend(fact.allowed_names)

        return FactPacket(
            intent=intent,
            facts=facts,
            recently_said=recently_said,
            prohibited=prohibited,
            allowed_names=sorted(set(names)),
            allowed_numbers=sorted(set(numbers)),
            allowed_number_words=sorted(set(number_words)),
            uncertainty_instructions=[
                "Use only supplied facts.",
                "Output WAIT when nothing adds value.",
            ],
        )

    def _fact(
        self,
        session_id: str,
        event_id: str | None,
        now: datetime,
        scope: FactScope,
        subject: str,
        predicate: str,
        obj: str,
        textual: str,
        numbers: list[int],
        names: list[str],
    ) -> Fact:
        words: list[str] = []
        for number in numbers:
            words.extend(_number_words_for(number))
        return Fact(
            fact_id=f"fact_{uuid4().hex[:10]}",
            session_id=session_id,
            event_id=event_id,
            scope=scope,
            subject=subject,
            predicate=predicate,
            object=obj,
            formatted_value=obj,
            textual_form=textual,
            authority=Authority.DETERMINISTIC_DIFF,
            confidence=ConfidenceBand.CONFIRMED,
            epistemic_class=EpistemicClass.DETERMINISTIC_DERIVATION,
            valid_from=now,
            speakable=True,
            allowed_names=names,
            allowed_numbers=numbers,
            allowed_number_words=words,
        )
