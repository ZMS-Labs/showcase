"""Franchise snapshot."""
