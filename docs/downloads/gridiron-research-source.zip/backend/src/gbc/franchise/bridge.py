from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

from gbc.contracts.franchise import CapabilityReport, FranchiseSnapshot


def bridge_entry() -> Path:
    root = Path(__file__).resolve().parents[4]
    return root / "franchise-bridge" / "src" / "cli.ts"


def run_bridge(command: str, snapshot: Path, extra: list[str] | None = None) -> dict[str, object]:
    if ".." in snapshot.as_posix():
        raise ValueError("Refusing path traversal in snapshot path")
    resolved = snapshot.resolve()
    bridge_root = bridge_entry().parent.parent
    args = ["pnpm", "exec", "tsx", "src/cli.ts", command, "--input", str(resolved)]
    if extra:
        args.extend(extra)
    env = os.environ.copy()
    env["GBC_FRANCHISE_READ_ONLY"] = "1"
    completed = subprocess.run(  # noqa: S603
        args,
        check=False,
        capture_output=True,
        text=True,
        env=env,
        cwd=str(bridge_root),
    )
    if completed.returncode != 0:
        raise RuntimeError(completed.stderr or completed.stdout or "franchise bridge failed")
    parsed: dict[str, object] = json.loads(completed.stdout)
    return parsed


def parse_capability(payload: dict[str, object]) -> CapabilityReport:
    return CapabilityReport.model_validate(payload)


def parse_export(payload: dict[str, object]) -> FranchiseSnapshot:
    return FranchiseSnapshot.model_validate(payload)
