from __future__ import annotations

import hashlib
import os
import stat
import time
import uuid
from pathlib import Path

from gbc.clocks import Clock
from gbc.contracts.franchise import SnapshotMeta


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _meta(path: Path) -> tuple[int, int]:
    info = path.stat()
    return info.st_size, getattr(info, "st_mtime_ns", int(info.st_mtime * 1e9))


def create_stable_snapshot(
    source: Path,
    dest_dir: Path,
    *,
    clock: Clock | None = None,
    stability_seconds: float = 2.0,
    retries: int = 5,
    poll_seconds: float | None = None,
) -> SnapshotMeta:
    if not source.is_file():
        raise FileNotFoundError(f"Franchise save not found: {source}")
    dest_dir.mkdir(parents=True, exist_ok=True)
    wait = poll_seconds if poll_seconds is not None else min(0.25, stability_seconds)
    last_size = last_mtime = None
    stable_since: float | None = None
    for _ in range(retries * 20):
        size, mtime_ns = _meta(source)
        now = time.monotonic()
        if last_size == size and last_mtime == mtime_ns:
            if stable_since is None:
                stable_since = now
            if now - stable_since >= stability_seconds:
                break
        else:
            stable_since = now
            last_size, last_mtime = size, mtime_ns
        time.sleep(wait)
    else:
        size, mtime_ns = _meta(source)
        last_size, last_mtime = size, mtime_ns

    assert last_size is not None and last_mtime is not None
    source_hash_before = sha256_file(source)
    snapshot_path = dest_dir / f"{uuid.uuid4().hex}.franchise-snapshot"
    snapshot_path.write_bytes(source.read_bytes())
    size_after, mtime_after = _meta(source)
    source_hash_after = sha256_file(source)
    if size_after != last_size or mtime_after != last_mtime or source_hash_after != source_hash_before:
        snapshot_path.unlink(missing_ok=True)
        raise RuntimeError("Source Franchise save changed during copy; retry required")
    snapshot_hash = sha256_file(snapshot_path)
    os.chmod(snapshot_path, stat.S_IREAD | stat.S_IRGRP | stat.S_IROTH)
    del clock  # reserved for tracing
    return SnapshotMeta(
        snapshot_path=str(snapshot_path),
        source_hash_before=source_hash_before,
        source_mtime_ns_before=last_mtime,
        source_size_before=last_size,
        source_hash_after=source_hash_after,
        source_mtime_ns_after=mtime_after,
        source_size_after=size_after,
        snapshot_hash=snapshot_hash,
        unchanged=True,
    )
