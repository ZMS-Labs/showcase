from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from gbc.contracts.enums import CaptureBackendName
from gbc.contracts.provenance import FieldPosition, Provenanced


class FrameEnvelope(BaseModel):
    model_config = ConfigDict(extra="forbid")

    frame_id: str
    sequence: int
    captured_at_utc: datetime
    captured_at_monotonic_ns: int
    width: int
    height: int
    pixel_format: str = "BGRA"
    capture_backend: CaptureBackendName
    window_identity: str
    profile_revision: str | None = None
    in_memory_frame_reference: str
    probable_hdr: bool = False


class CaptureTarget(BaseModel):
    model_config = ConfigDict(extra="forbid")

    target_id: str
    title: str
    process_name: str | None = None
    kind: str = "window"
    width: int | None = None
    height: int | None = None


class CaptureHealth(BaseModel):
    model_config = ConfigDict(extra="forbid")

    running: bool
    fps: float = 0.0
    dropped_frames: int = 0
    queue_depth: int = 0
    window_lost: bool = False
    minimized: bool = False
    resized: bool = False
    probable_hdr: bool = False
    message: str = ""


class CaptureOptions(BaseModel):
    model_config = ConfigDict(extra="forbid")

    target_fps: int = 30
    allow_monitor: bool = False
    hdr_policy: str = "reject"


class RoiDefinition(BaseModel):
    model_config = ConfigDict(extra="forbid")

    roi_id: str
    roi_type: str
    x: float = Field(ge=0.0, le=1.0)
    y: float = Field(ge=0.0, le=1.0)
    w: float = Field(gt=0.0, le=1.0)
    h: float = Field(gt=0.0, le=1.0)
    alphabet: str | None = None
    regex: str | None = None


class DisplayProfile(BaseModel):
    model_config = ConfigDict(extra="forbid")

    profile_id: str
    revision: int
    game: str = "Madden NFL 27"
    game_version_or_build_hint: str = "unknown"
    capture_width: int
    capture_height: int
    aspect_ratio: str = "16:9"
    created_at: datetime
    roi_definitions: list[RoiDefinition]
    preprocessing_settings: dict[str, str] = Field(default_factory=dict)
    temporal_thresholds: dict[str, float] = Field(default_factory=dict)
    visual_anchors: list[dict[str, str]] = Field(default_factory=list)
    validation_results: dict[str, str] = Field(default_factory=dict)
    stale: bool = False


class RoiObservation(BaseModel):
    model_config = ConfigDict(extra="forbid")

    observation_id: str
    frame_id: str
    roi_id: str
    observation_type: str
    raw_text: str
    normalized_value: str | None = None
    ocr_confidence: float = Field(ge=0.0, le=1.0)
    preprocessing_variant: str = "default"
    evidence_hash: str
    created_at: datetime


class ScoreboardSnapshot(BaseModel):
    model_config = ConfigDict(extra="forbid")

    snapshot_id: str
    timestamp: datetime
    home_team: Provenanced[str]
    away_team: Provenanced[str]
    home_score: Provenanced[int]
    away_score: Provenanced[int]
    quarter: Provenanced[int]
    game_clock_ms: Provenanced[int]
    play_clock_seconds: Provenanced[int]
    down: Provenanced[int]
    distance: Provenanced[int]
    ball_spot: Provenanced[FieldPosition]
    possession_team: Provenanced[str]
    timeouts_home: Provenanced[int]
    timeouts_away: Provenanced[int]
    is_stable: bool
    field_level_evidence: list[str] = Field(default_factory=list)
    penalty_visible: bool = False
    review_visible: bool = False
    playcall_visible: bool = False
    postplay_overlay_visible: bool = False
