from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class CapabilityTable(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str
    unique_id: int | None = None
    found: bool
    record_count: int = 0
    requested_fields_found: list[str] = Field(default_factory=list)
    requested_fields_missing: list[str] = Field(default_factory=list)


class CapabilityReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    detected_game_year: int | None = None
    parser_version: str
    schema_version: str | None = None
    snapshot_hash: str
    tables: list[CapabilityTable] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    degraded_features: list[str] = Field(default_factory=list)


class FranchisePlayer(BaseModel):
    model_config = ConfigDict(extra="forbid")

    player_id: str
    source_ref: str
    first_name: str
    last_name: str
    display_name: str
    team_id: str | None = None
    jersey_number: int | None = None
    position: str | None = None
    generated: bool = False


class FranchiseTeam(BaseModel):
    model_config = ConfigDict(extra="forbid")

    team_id: str
    source_ref: str
    display_name: str
    abbreviation: str
    city: str | None = None


class FranchiseSnapshot(BaseModel):
    model_config = ConfigDict(extra="forbid")

    snapshot_version: str = "gbc.franchise.v1"
    source_file_hash: str
    source_file_size: int
    source_file_modified_at: datetime
    captured_at: datetime
    game_year: int | None = None
    franchise_key: str
    league_name: str | None = None
    season_year: int | None = None
    week: int | None = None
    teams: list[FranchiseTeam] = Field(default_factory=list)
    players: list[FranchisePlayer] = Field(default_factory=list)
    depth_charts: list[dict[str, str]] = Field(default_factory=list)
    schedule: list[dict[str, str]] = Field(default_factory=list)
    completed_games: list[dict[str, str]] = Field(default_factory=list)
    standings: list[dict[str, str]] = Field(default_factory=list)
    injuries: list[dict[str, str]] = Field(default_factory=list)
    transactions: list[dict[str, str]] = Field(default_factory=list)
    season_stats: list[dict[str, str]] = Field(default_factory=list)
    career_stats: list[dict[str, str]] = Field(default_factory=list)
    records: list[dict[str, str]] = Field(default_factory=list)
    capability_report: CapabilityReport
    warnings: list[str] = Field(default_factory=list)


class SnapshotMeta(BaseModel):
    model_config = ConfigDict(extra="forbid")

    snapshot_path: str
    source_hash_before: str
    source_mtime_ns_before: int
    source_size_before: int
    source_hash_after: str
    source_mtime_ns_after: int
    source_size_after: int
    snapshot_hash: str
    unchanged: bool
