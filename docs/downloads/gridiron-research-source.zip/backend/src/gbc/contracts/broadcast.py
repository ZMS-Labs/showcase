from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from gbc.contracts.enums import (
    Authority,
    CertaintyStyle,
    CommentaryDecision,
    ConfidenceBand,
    EpistemicClass,
    FactScope,
    IntentType,
    Interruptibility,
    Speaker,
    StorylineState,
    UtteranceStatus,
)


class Fact(BaseModel):
    model_config = ConfigDict(extra="forbid")

    fact_id: str
    session_id: str
    event_id: str | None = None
    scope: FactScope
    subject: str
    predicate: str
    object: str
    unit: str | None = None
    formatted_value: str
    textual_form: str
    authority: Authority
    confidence: ConfidenceBand
    epistemic_class: EpistemicClass
    evidence_ids: list[str] = Field(default_factory=list)
    valid_from: datetime
    valid_until: datetime | None = None
    phrase_hints: list[str] = Field(default_factory=list)
    speakable: bool = False
    allows_same_play_language: bool = False
    allows_superlative: bool = False
    allows_record_claim: bool = False
    allowed_names: list[str] = Field(default_factory=list)
    allowed_numbers: list[int] = Field(default_factory=list)
    allowed_number_words: list[str] = Field(default_factory=list)


class Storyline(BaseModel):
    model_config = ConfigDict(extra="forbid")

    storyline_id: str
    type: str
    subjects: list[str]
    state: StorylineState
    supporting_fact_ids: list[str] = Field(default_factory=list)
    first_seen: datetime
    last_updated: datetime
    salience: float = 0.0
    resolution_condition: str = ""
    cooldown: float = 0.0


class BroadcastTopic(BaseModel):
    model_config = ConfigDict(extra="forbid")

    topic_id: str
    canonical_topic_key: str
    last_mentioned_at: datetime | None = None
    mention_count: int = 0
    speaker: Speaker | None = None
    semantic_fingerprint: str = ""
    cooldown_until: datetime | None = None
    state_at_last_mention: str = ""


class SpeechIntent(BaseModel):
    model_config = ConfigDict(extra="forbid")

    intent_id: str
    priority: int
    speaker: Speaker | None = None
    intent_type: IntentType
    allowed_fact_ids: list[str] = Field(default_factory=list)
    topic_ids: list[str] = Field(default_factory=list)
    maximum_words: int = 24
    deadline_monotonic_ns: int = 0
    estimated_available_seconds: float = 0.0
    interruptibility: Interruptibility = Interruptibility.SENTENCE
    certainty_style: CertaintyStyle = CertaintyStyle.CONFIRMED
    fallback_template_id: str | None = None


class FactPacket(BaseModel):
    model_config = ConfigDict(extra="forbid")

    intent: SpeechIntent
    facts: list[Fact] = Field(default_factory=list)
    recently_said: list[str] = Field(default_factory=list)
    prohibited: list[str] = Field(default_factory=list)
    allowed_names: list[str] = Field(default_factory=list)
    allowed_numbers: list[int] = Field(default_factory=list)
    allowed_number_words: list[str] = Field(default_factory=list)
    uncertainty_instructions: list[str] = Field(default_factory=list)


class CommentaryPlan(BaseModel):
    model_config = ConfigDict(extra="forbid")

    decision: CommentaryDecision
    speaker: Speaker | None = None
    intent_id: str
    text: str = ""
    fact_ids: list[str] = Field(default_factory=list)
    topic_ids: list[str] = Field(default_factory=list)
    certainty_style: CertaintyStyle = CertaintyStyle.NONE
    estimated_seconds: float = 0.0
    interruptibility: Interruptibility = Interruptibility.IMMEDIATE


class Utterance(BaseModel):
    model_config = ConfigDict(extra="forbid")

    utterance_id: str
    speech_intent_id: str
    speaker: Speaker | None = None
    text: str
    fact_ids: list[str] = Field(default_factory=list)
    topic_ids: list[str] = Field(default_factory=list)
    created_at: datetime
    audio_started_at: datetime | None = None
    audio_ended_at: datetime | None = None
    status: UtteranceStatus
    cancellation_reason: str | None = None
    model_provider: str = "none"
    model_name: str = "none"
    model_latency_ms: float = 0.0
    tts_provider: str = "none"
    tts_latency_ms: float = 0.0
    validation_result: str = "ok"
