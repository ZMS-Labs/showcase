from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from gbc.contracts.enums import (
    ConfidenceBand,
    EventStatus,
    PenaltyState,
    PlayMatchLevel,
    PlayType,
    ResultType,
)
from gbc.contracts.provenance import EvidenceReference, FieldPosition


class PlaySelection(BaseModel):
    model_config = ConfigDict(extra="forbid")

    selection_id: str
    team_id: str
    side_of_ball: str
    play_name: str | None = None
    formation: str | None = None
    personnel: str | None = None
    concept_family: str | None = None
    direction: str | None = None
    selected_at: datetime
    confidence: ConfidenceBand
    speakability: str = "PRIVATE_UNTIL_POSTPLAY"


class PlaySignature(BaseModel):
    model_config = ConfigDict(extra="forbid")

    offense_personnel: str | None = None
    formation: str | None = None
    motion: str | None = None
    play_family: str | None = None
    play_name: str | None = None
    direction: str | None = None
    target_area: str | None = None
    primary_participant: str | None = None
    down_bucket: str | None = None
    distance_bucket: str | None = None
    evidence: list[str] = Field(default_factory=list)
    confidence: ConfidenceBand = ConfidenceBand.UNKNOWN
    match_level: PlayMatchLevel = PlayMatchLevel.INSUFFICIENT_EVIDENCE


class Participants(BaseModel):
    model_config = ConfigDict(extra="forbid")

    passer: str | None = None
    rusher: str | None = None
    target: str | None = None
    receiver: str | None = None
    tacklers: list[str] = Field(default_factory=list)
    sacker: str | None = None
    interceptor: str | None = None
    forced_fumble_by: str | None = None
    recovered_by: str | None = None
    kicker: str | None = None
    returner: str | None = None


class PlayEvent(BaseModel):
    model_config = ConfigDict(extra="forbid")

    event_id: str
    session_id: str
    revision: int = 1
    status: EventStatus
    started_at: datetime
    ended_at: datetime | None = None
    pre_snap_snapshot_id: str | None = None
    post_play_snapshot_id: str | None = None
    offense_team: str | None = None
    defense_team: str | None = None
    play_type: PlayType = PlayType.UNKNOWN
    result_type: ResultType = ResultType.UNRESOLVED
    yards: int | None = None
    first_down: bool = False
    touchdown: bool = False
    turnover: bool = False
    safety: bool = False
    scoring_value: int = 0
    penalty_state: PenaltyState = PenaltyState.NONE
    participants: Participants = Field(default_factory=Participants)
    play_selection: PlaySelection | None = None
    play_signature: PlaySignature | None = None
    evidence: list[EvidenceReference] = Field(default_factory=list)
    confidence_by_field: dict[str, ConfidenceBand] = Field(default_factory=dict)
    correction_reason: str | None = None
    supersedes_revision: int | None = None
    ball_spot_pre: FieldPosition | None = None
    ball_spot_post: FieldPosition | None = None
    down: int | None = None
    distance: int | None = None
    quarter: int | None = None
