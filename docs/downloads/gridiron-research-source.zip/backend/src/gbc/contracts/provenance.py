from __future__ import annotations

from datetime import datetime
from typing import Generic, TypeVar

from pydantic import BaseModel, ConfigDict, Field

from gbc.contracts.enums import Authority, ConfidenceBand, EpistemicClass

T = TypeVar("T")


class EvidenceReference(BaseModel):
    model_config = ConfigDict(extra="forbid")

    evidence_id: str
    source_type: str
    source_id: str
    field: str
    observed_value: str
    authority: Authority
    confidence: ConfidenceBand
    captured_at: datetime
    roi_id: str | None = None
    frame_id: str | None = None
    model_request_id: str | None = None
    value_hash: str | None = None


class Provenanced(BaseModel, Generic[T]):
    model_config = ConfigDict(extra="forbid")

    value: T | None = None
    source: str
    timestamp: datetime
    confidence: ConfidenceBand
    authority: Authority
    epistemic_class: EpistemicClass
    evidence_id: str | None = None
    speakable: bool = False

    def is_unqualified_fact(self) -> bool:
        return self.speakable and self.confidence in {
            ConfidenceBand.CONFIRMED,
            ConfidenceBand.HIGH,
        }


class FieldPosition(BaseModel):
    model_config = ConfigDict(extra="forbid")

    team_whose_side: str | None = None
    yard_number: int | None = Field(default=None, ge=1, le=50)
    at_midfield: bool = False
    distance_to_goal_for_possession: int | None = Field(default=None, ge=0, le=100)

    @classmethod
    def midfield(cls) -> FieldPosition:
        return cls(
            team_whose_side=None,
            yard_number=50,
            at_midfield=True,
            distance_to_goal_for_possession=50,
        )


def distance_to_goal(
    possession_team: str,
    side: str | None,
    yard_number: int | None,
    *,
    at_midfield: bool = False,
) -> int | None:
    if at_midfield or yard_number == 50:
        return 50
    if side is None or yard_number is None:
        return None
    if side == possession_team:
        return 100 - yard_number
    return yard_number


def yards_gained(
    pre: FieldPosition,
    post: FieldPosition,
    *,
    possession_changed: bool,
    touchdown: bool,
    touchback: bool,
) -> int | None:
    if touchdown:
        pre_dtg = pre.distance_to_goal_for_possession
        return pre_dtg if pre_dtg is not None else None
    if touchback:
        return None
    if possession_changed:
        return None
    if pre.distance_to_goal_for_possession is None or post.distance_to_goal_for_possession is None:
        return None
    return pre.distance_to_goal_for_possession - post.distance_to_goal_for_possession
