from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

from gbc.replay.runner import ReplayResult, run_fixture


@dataclass
class BenchmarkReport:
    fixture: str
    perception: dict[str, object]
    events: dict[str, object]
    commentary: dict[str, object]
    latency: dict[str, object]
    performance: dict[str, object]
    labels: dict[str, str]
    machine: dict[str, str]


def evaluate_fixture(fixture_dir: Path) -> tuple[BenchmarkReport, ReplayResult]:
    first = run_fixture(fixture_dir)
    second = run_fixture(fixture_dir)
    deterministic = first.deterministic_hash == second.deterministic_hash
    oracle_events = [
        json.loads(line)
        for line in (fixture_dir / "oracle" / "events.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip() and json.loads(line).get("expect")
    ]
    expected_statuses = [row["expect"] for row in oracle_events]
    observed = first.statuses
    oracle_present = bool(expected_statuses)
    event_match = oracle_present and observed == expected_statuses
    count_match = first.observed_events == first.expected_events == len(expected_statuses)
    report = BenchmarkReport(
        fixture=first.fixture,
        perception={
            "field_accuracy": None,
            "unknown_state_rate": None,
            "label": "NOT_MEASURED",
            "reason": "Replay consumes synthetic observations; OCR accuracy is not measured.",
        },
        events={
            "observed": first.observed_events,
            "expected": first.expected_events,
            "duplicate_event_rate": first.duplicate_commitments,
            "status_match": event_match,
            "count_match": count_match,
            "oracle_present": oracle_present,
            "label": (
                "NOT_MEASURED"
                if not oracle_present
                else "VERIFIED"
                if event_match and count_match and first.duplicate_commitments == 0
                else "UNVERIFIED"
            ),
        },
        commentary={
            "unsupported_name_count": first.unsupported_names,
            "unsupported_number_count": first.unsupported_numbers,
            "utterances": first.utterances,
            "utterance_count": len(first.utterances),
            "label": "NOT_MEASURED",
            "reason": "No independent commentary accuracy evaluator was run.",
        },
        latency={"event_to_decision_ms": "NOT_APPLICABLE"},
        performance={"capture_fps": "NOT_APPLICABLE"},
        labels={
            "synthetic_replay": "VERIFIED" if deterministic else "UNVERIFIED",
            "madden_live": "UNVERIFIED",
            "franchise_madden27": "UNVERIFIED",
        },
        machine={"os": "ci", "mode": "synthetic"},
    )
    return report, first


def write_reports(report: BenchmarkReport, out_dir: Path) -> tuple[Path, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / "benchmark.json"
    html_path = out_dir / "benchmark.html"
    payload = asdict(report)
    json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    rows = "".join(f"<tr><th>{key}</th><td>{value}</td></tr>" for key, value in report.labels.items())
    html_path.write_text(
        f"""<!doctype html><html><head><meta charset="utf-8"><title>GBC Benchmark</title></head>
<body><h1>Gridiron Broadcast Companion Benchmark</h1>
<p>Fixture: {report.fixture}</p>
<table>{rows}</table>
<pre>{json.dumps(payload, indent=2)}</pre>
</body></html>
""",
        encoding="utf-8",
    )
    return json_path, html_path
