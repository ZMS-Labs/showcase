from __future__ import annotations

import logging
import re
from typing import Any

import structlog

REDACT = re.compile(
    r"(C:\\Users\\[^\\]+)|([A-Za-z]:\\Users\\[^\\]+)|(sk-[A-Za-z0-9]+)|(\.franchise)|(\.save)",
    re.I,
)


def redact(value: str) -> str:
    return REDACT.sub("[redacted]", value)


def configure_logging() -> None:
    structlog.configure(
        processors=[
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(logging.INFO),
    )


def bind_trace(trace_id: str, **kwargs: Any) -> Any:
    return structlog.get_logger().bind(trace_id=trace_id, **kwargs)
