from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from gbc.clocks import FakeClock
from gbc.contracts.enums import (
    ConfidenceBand,
    EventStatus,
    PlayType,
    ResultType,
)
from gbc.contracts.events import PlaySignature
from gbc.contracts.provenance import FieldPosition
from gbc.events.reconciler import EventReconciler, ScoreboardView
from gbc.facts.compiler import FactCompiler
from gbc.language.guard import ClaimGuard
from gbc.language.providers import DeterministicTemplateProvider
from gbc.memory.stats import StatisticsEngine
from gbc.memory.tendencies import TendencyEngine
from gbc.producer.producer import Producer
from gbc.replay.clock import ReplayClock


@dataclass
class ReplayResult:
    fixture: str
    expected_events: int
    observed_events: int
    statuses: list[str]
    unsupported_names: int | None
    unsupported_numbers: int | None
    duplicate_commitments: int
    ledger: list[dict[str, object]]
    utterances: list[str]
    deterministic_hash: str


def _view(row: dict[str, Any], home: str, away: str) -> ScoreboardView:
    spot = row.get("ball_spot")
    field = None
    if isinstance(spot, dict):
        field = FieldPosition.model_validate(spot)
    return ScoreboardView(
        home_team=home,
        away_team=away,
        home_score=int(row["home_score"]),
        away_score=int(row["away_score"]),
        quarter=int(row["quarter"]),
        game_clock_ms=int(row["game_clock_ms"]),
        down=int(row["down"]) if row.get("down") is not None else None,
        distance=int(row["distance"]) if row.get("distance") is not None else None,
        possession_team=str(row["possession"]) if row.get("possession") else None,
        ball_spot=field,
        penalty_visible=bool(row.get("penalty")),
        review_visible=bool(row.get("review")),
        snap=bool(row.get("snap")),
        postplay=bool(row.get("postplay")),
        playcall_visible=bool(row.get("playcall")),
    )


def run_fixture(fixture_dir: Path) -> ReplayResult:
    manifest = json.loads((fixture_dir / "manifest.json").read_text(encoding="utf-8"))
    oracle_events = [
        json.loads(line)
        for line in (fixture_dir / "oracle" / "events.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    scoreboard_rows = [
        json.loads(line)
        for line in (fixture_dir / "oracle" / "scoreboard.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    clock = ReplayClock(FakeClock())
    session_id = "replay-session"
    reconciler = EventReconciler(session_id)
    stats = StatisticsEngine()
    tendencies = TendencyEngine()
    producer = Producer()
    compiler = FactCompiler()
    guard = ClaimGuard()
    language = DeterministicTemplateProvider()
    home = manifest.get("home_team", "CHI")
    away = manifest.get("away_team", "GB")
    utterances: list[str] = []
    seen_commit: set[str] = set()
    duplicates = 0
    now = clock.now_utc()

    for row in scoreboard_rows:
        clock.set_monotonic(int(row.get("t", 0)))
        now = clock.now_utc()
        sig = None
        if row.get("play_name") or row.get("play_family"):
            sig = PlaySignature(
                play_name=row.get("play_name"),
                play_family=row.get("play_family"),
                formation=row.get("formation"),
                target_area=row.get("target_area"),
                confidence=ConfidenceBand.CONFIRMED,
            )
        event = reconciler.handle(
            _view(row, home, away),
            now,
            observation_key=row.get("event_id"),
            signature=sig,
            play_type=PlayType(row["play_type"]) if row.get("play_type") else PlayType.UNKNOWN,
        )
        if event and event.status in {
            EventStatus.CONFIRMED,
            EventStatus.VOIDED,
            EventStatus.CORRECTED,
        }:
            key = f"{event.event_id}:{event.revision}:{event.status}"
            if key in seen_commit:
                duplicates += 1
            seen_commit.add(key)
            if event.status == EventStatus.VOIDED:
                stats.apply(event)
            else:
                stats.apply(event)
                rec = tendencies.observe(event)
                decision = producer.decide(
                    event=event,
                    tendency=rec,
                    now=now,
                    deadline_ns=clock.monotonic_ns() + 1_000_000,
                )
                packet = compiler.compile(
                    decision.intent,
                    session_id=session_id,
                    now=now,
                    event=event,
                    stats=stats.current,
                    tendency=rec,
                    recently_said=utterances[-3:],
                )
                if decision.immediate_text:
                    utterances.append(decision.immediate_text)
                elif decision.use_model:
                    plan = language.generate(packet)
                    result = guard.validate(plan, packet)
                    if result.accepted and plan.text:
                        utterances.append(plan.text)

    for row in oracle_events:
        if row.get("action") == "correct":
            previous = next(e for e in reconciler.events if e.event_id == row["event_id"])
            revised = reconciler.correct(
                row["event_id"],
                now,
                status=EventStatus.CORRECTED,
                scoring_value=int(row.get("scoring_value", 0)),
                touchdown=bool(row.get("touchdown", False)),
                result_type=ResultType(row["result_type"]) if row.get("result_type") else previous.result_type,
            )
            stats.replace(previous, revised)

    canonical = [e.model_dump(mode="json") for e in reconciler.events]
    for item in canonical:
        item.pop("started_at", None)
        item.pop("ended_at", None)
    blob = json.dumps(canonical, sort_keys=True, separators=(",", ":"))
    import hashlib

    return ReplayResult(
        fixture=manifest.get("name", fixture_dir.name),
        expected_events=int(manifest.get("expected_event_count", len(oracle_events))),
        observed_events=len(reconciler.events),
        statuses=[e.status.value for e in reconciler.events],
        unsupported_names=None,
        unsupported_numbers=None,
        duplicate_commitments=duplicates,
        ledger=canonical,
        utterances=utterances,
        deterministic_hash=hashlib.sha256(blob.encode("utf-8")).hexdigest(),
    )
