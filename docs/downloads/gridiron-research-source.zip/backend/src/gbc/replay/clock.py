from __future__ import annotations

from datetime import datetime

from gbc.clocks import FakeClock


class ReplayClock:
    def __init__(self, inner: FakeClock) -> None:
        self.inner = inner

    def now_utc(self) -> datetime:
        return self.inner.now_utc()

    def monotonic_ns(self) -> int:
        return self.inner.monotonic_ns()

    def set_monotonic(self, ns: int) -> None:
        self.inner._mono = ns

    def advance_ms(self, ms: int) -> None:
        self.inner.advance_ms(ms)
