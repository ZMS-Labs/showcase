from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from gbc.contracts.enums import PlayMatchLevel
from gbc.contracts.events import PlayEvent, PlaySignature


@dataclass
class TendencyRecord:
    key: str
    match_level: PlayMatchLevel
    use_count: int = 0
    success_count: int = 0
    total_yards: int = 0
    last_used: datetime | None = None
    discussed: bool = False
    down_buckets: list[str] = field(default_factory=list)

    @property
    def average_gain(self) -> float:
        if self.use_count == 0:
            return 0.0
        return self.total_yards / self.use_count


def signature_key(sig: PlaySignature, level: PlayMatchLevel) -> str | None:
    if level == PlayMatchLevel.EXACT_VERIFIED_PLAY:
        if not sig.play_name:
            return None
        return f"exact:{sig.play_name}"
    if level == PlayMatchLevel.SAME_PLAY_FAMILY:
        if not sig.play_family:
            return None
        return f"family:{sig.play_family}"
    if level == PlayMatchLevel.SAME_FORMATION_AND_TARGET_AREA:
        if not sig.formation or not sig.target_area:
            return None
        return f"look:{sig.formation}:{sig.target_area}"
    if level == PlayMatchLevel.SIMILAR_LOOK:
        if not sig.formation:
            return None
        return f"form:{sig.formation}"
    return None


def classify_match(current: PlaySignature, previous: PlaySignature) -> PlayMatchLevel:
    if current.play_name and previous.play_name and current.play_name == previous.play_name:
        if current.confidence.value in {"CONFIRMED", "HIGH"} and previous.confidence.value in {
            "CONFIRMED",
            "HIGH",
        }:
            return PlayMatchLevel.EXACT_VERIFIED_PLAY
    if current.play_family and current.play_family == previous.play_family:
        return PlayMatchLevel.SAME_PLAY_FAMILY
    if (
        current.formation
        and current.target_area
        and current.formation == previous.formation
        and current.target_area == previous.target_area
    ):
        return PlayMatchLevel.SAME_FORMATION_AND_TARGET_AREA
    if current.formation and current.formation == previous.formation:
        return PlayMatchLevel.SIMILAR_LOOK
    return PlayMatchLevel.INSUFFICIENT_EVIDENCE


class TendencyEngine:
    def __init__(self) -> None:
        self.records: dict[str, TendencyRecord] = {}
        self.history: list[PlaySignature] = []

    def observe(self, event: PlayEvent) -> TendencyRecord | None:
        sig = event.play_signature
        if sig is None:
            return None
        level = PlayMatchLevel.INSUFFICIENT_EVIDENCE
        for previous in self.history:
            candidate = classify_match(sig, previous)
            if candidate.value < level.value or level == PlayMatchLevel.INSUFFICIENT_EVIDENCE:
                # StrEnum order is not numeric; pick the strongest explicitly.
                pass
        strongest = PlayMatchLevel.INSUFFICIENT_EVIDENCE
        for previous in self.history:
            candidate = classify_match(sig, previous)
            strongest = _stronger(strongest, candidate)
        key = signature_key(sig, strongest) or signature_key(sig, PlayMatchLevel.EXACT_VERIFIED_PLAY)
        if key is None:
            key = signature_key(sig, PlayMatchLevel.SAME_PLAY_FAMILY)
        if key is None:
            self.history.append(sig)
            return None
        rec = self.records.get(key) or TendencyRecord(key=key, match_level=strongest)
        rec.use_count += 1
        rec.total_yards += event.yards or 0
        if event.first_down or event.touchdown:
            rec.success_count += 1
        rec.last_used = event.ended_at or event.started_at
        rec.match_level = strongest
        self.records[key] = rec
        self.history.append(sig)
        return rec

    def reverse(self, event: PlayEvent) -> None:
        sig = event.play_signature
        if sig is None:
            return
        for level in (
            PlayMatchLevel.EXACT_VERIFIED_PLAY,
            PlayMatchLevel.SAME_PLAY_FAMILY,
            PlayMatchLevel.SAME_FORMATION_AND_TARGET_AREA,
            PlayMatchLevel.SIMILAR_LOOK,
        ):
            key = signature_key(sig, level)
            if key and key in self.records:
                rec = self.records[key]
                rec.use_count = max(0, rec.use_count - 1)
                rec.total_yards -= event.yards or 0
                if event.first_down or event.touchdown:
                    rec.success_count = max(0, rec.success_count - 1)


def _stronger(a: PlayMatchLevel, b: PlayMatchLevel) -> PlayMatchLevel:
    order = [
        PlayMatchLevel.EXACT_VERIFIED_PLAY,
        PlayMatchLevel.SAME_PLAY_FAMILY,
        PlayMatchLevel.SAME_FORMATION_AND_TARGET_AREA,
        PlayMatchLevel.SIMILAR_LOOK,
        PlayMatchLevel.INSUFFICIENT_EVIDENCE,
    ]
    return a if order.index(a) <= order.index(b) else b


def narrative_for(record: TendencyRecord) -> str | None:
    if record.match_level == PlayMatchLevel.INSUFFICIENT_EVIDENCE:
        return None
    if record.use_count <= 1:
        return None
    if record.match_level != PlayMatchLevel.EXACT_VERIFIED_PLAY and record.use_count == 2:
        return "similar_look"
    if record.use_count == 2:
        return "shown_before"
    if record.use_count == 3:
        return "verified_tendency"
    if record.use_count >= 4:
        return "continued_tendency"
    return None
