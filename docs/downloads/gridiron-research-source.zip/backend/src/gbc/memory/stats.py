from __future__ import annotations

from dataclasses import dataclass, field

from gbc.contracts.enums import EventStatus, PlayType, ResultType
from gbc.contracts.events import PlayEvent


@dataclass
class GameStatistics:
    team_points: dict[str, int] = field(default_factory=dict)
    drives: int = 0
    first_downs: int = 0
    turnovers: int = 0
    third_down_attempts: int = 0
    third_down_conversions: int = 0
    fourth_down_attempts: int = 0
    fourth_down_conversions: int = 0
    pass_attempts: int = 0
    completions: int = 0
    interceptions: int = 0
    passing_yards: int = 0
    rushing_attempts: int = 0
    rushing_yards: int = 0
    receptions: int = 0
    receiving_yards: int = 0
    sacks: int = 0
    field_goal_attempts: int = 0
    field_goals_made: int = 0
    play_family_counts: dict[str, int] = field(default_factory=dict)

    def copy(self) -> GameStatistics:
        return GameStatistics(
            team_points=dict(self.team_points),
            drives=self.drives,
            first_downs=self.first_downs,
            turnovers=self.turnovers,
            third_down_attempts=self.third_down_attempts,
            third_down_conversions=self.third_down_conversions,
            fourth_down_attempts=self.fourth_down_attempts,
            fourth_down_conversions=self.fourth_down_conversions,
            pass_attempts=self.pass_attempts,
            completions=self.completions,
            interceptions=self.interceptions,
            passing_yards=self.passing_yards,
            rushing_attempts=self.rushing_attempts,
            rushing_yards=self.rushing_yards,
            receptions=self.receptions,
            receiving_yards=self.receiving_yards,
            sacks=self.sacks,
            field_goal_attempts=self.field_goal_attempts,
            field_goals_made=self.field_goals_made,
            play_family_counts=dict(self.play_family_counts),
        )


class StatisticsEngine:
    def __init__(self) -> None:
        self.current = GameStatistics()
        self._applied: dict[tuple[str, int], GameStatistics] = {}

    def apply(self, event: PlayEvent) -> None:
        key = (event.event_id, event.revision)
        if key in self._applied:
            return
        if event.status == EventStatus.VOIDED:
            self._applied[key] = self.current.copy()
            return
        before = self.current.copy()
        self._apply_delta(event, sign=1)
        self._applied[key] = before

    def reverse(self, event: PlayEvent) -> None:
        key = (event.event_id, event.revision)
        if key not in self._applied:
            return
        if event.status != EventStatus.VOIDED:
            self._apply_delta(event, sign=-1)
        del self._applied[key]

    def replace(self, previous: PlayEvent, corrected: PlayEvent) -> None:
        self.reverse(previous)
        self.apply(corrected)

    def _apply_delta(self, event: PlayEvent, sign: int) -> None:
        offense = event.offense_team or "UNK"
        self.current.team_points[offense] = self.current.team_points.get(offense, 0) + sign * event.scoring_value
        if event.first_down:
            self.current.first_downs += sign
        if event.turnover:
            self.current.turnovers += sign
        if event.down == 3:
            self.current.third_down_attempts += sign
            if event.first_down or event.touchdown:
                self.current.third_down_conversions += sign
        if event.down == 4:
            self.current.fourth_down_attempts += sign
            if event.first_down or event.touchdown:
                self.current.fourth_down_conversions += sign
        yards = event.yards or 0
        if event.play_type == PlayType.PASS:
            self.current.pass_attempts += sign
            if event.result_type == ResultType.INTERCEPTION:
                self.current.interceptions += sign
            elif event.result_type != ResultType.INCOMPLETE:
                self.current.completions += sign
                self.current.passing_yards += sign * yards
                if event.participants.receiver:
                    self.current.receptions += sign
                    self.current.receiving_yards += sign * yards
        if event.play_type == PlayType.RUN:
            self.current.rushing_attempts += sign
            self.current.rushing_yards += sign * yards
        if event.play_type == PlayType.SACK:
            self.current.sacks += sign
        if event.play_type == PlayType.FIELD_GOAL:
            self.current.field_goal_attempts += sign
            if event.result_type == ResultType.FIELD_GOAL_GOOD:
                self.current.field_goals_made += sign
        if event.play_signature and event.play_signature.play_family:
            family = event.play_signature.play_family
            self.current.play_family_counts[family] = self.current.play_family_counts.get(family, 0) + sign
