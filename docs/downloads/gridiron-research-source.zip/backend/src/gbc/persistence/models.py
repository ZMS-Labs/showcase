from __future__ import annotations

from datetime import datetime

from sqlalchemy import JSON, Boolean, DateTime, Float, Integer, String, Text, create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker


class Base(DeclarativeBase):
    pass


class FranchiseRow(Base):
    __tablename__ = "franchises"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    name: Mapped[str] = mapped_column(String)


class FranchiseSnapshotRow(Base):
    __tablename__ = "franchise_snapshots"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    franchise_id: Mapped[str] = mapped_column(String)
    snapshot_hash: Mapped[str] = mapped_column(String)
    captured_at: Mapped[datetime] = mapped_column(DateTime)
    payload: Mapped[dict[str, object]] = mapped_column(JSON)


class SessionRow(Base):
    __tablename__ = "sessions"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime)
    human_team: Mapped[str | None] = mapped_column(String, nullable=True)
    status: Mapped[str] = mapped_column(String)


class ScoreboardSnapshotRow(Base):
    __tablename__ = "scoreboard_snapshots"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    session_id: Mapped[str] = mapped_column(String)
    payload: Mapped[dict[str, object]] = mapped_column(JSON)


class EventRevisionRow(Base):
    __tablename__ = "event_revisions"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    event_id: Mapped[str] = mapped_column(String)
    revision: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String)
    payload: Mapped[dict[str, object]] = mapped_column(JSON)


class FactRow(Base):
    __tablename__ = "facts"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    session_id: Mapped[str] = mapped_column(String)
    payload: Mapped[dict[str, object]] = mapped_column(JSON)


class GameStatisticsRow(Base):
    __tablename__ = "game_statistics"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    session_id: Mapped[str] = mapped_column(String)
    payload: Mapped[dict[str, object]] = mapped_column(JSON)


class PlaySignatureRow(Base):
    __tablename__ = "play_signatures"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    session_id: Mapped[str] = mapped_column(String)
    payload: Mapped[dict[str, object]] = mapped_column(JSON)


class StorylineRow(Base):
    __tablename__ = "storylines"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    payload: Mapped[dict[str, object]] = mapped_column(JSON)


class BroadcastTopicRow(Base):
    __tablename__ = "broadcast_topics"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    payload: Mapped[dict[str, object]] = mapped_column(JSON)


class UtteranceRow(Base):
    __tablename__ = "utterances"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    session_id: Mapped[str] = mapped_column(String)
    text: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String)
    payload: Mapped[dict[str, object]] = mapped_column(JSON)


class ProviderRequestRow(Base):
    __tablename__ = "provider_requests"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    kind: Mapped[str] = mapped_column(String)
    latency_ms: Mapped[float] = mapped_column(Float)
    ok: Mapped[bool] = mapped_column(Boolean)


class MetricRow(Base):
    __tablename__ = "metrics"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    name: Mapped[str] = mapped_column(String)
    value: Mapped[float] = mapped_column(Float)


class ProfileRevisionRow(Base):
    __tablename__ = "profile_revisions"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    payload: Mapped[dict[str, object]] = mapped_column(JSON)


def make_engine(path: str) -> Engine:
    engine = create_engine(f"sqlite:///{path}", future=True)
    with engine.connect() as conn:
        conn.exec_driver_sql("PRAGMA journal_mode=WAL")
        conn.commit()
    Base.metadata.create_all(engine)
    return engine


def make_session_factory(engine: Engine) -> sessionmaker:  # type: ignore[type-arg]
    return sessionmaker(engine, expire_on_commit=False)
