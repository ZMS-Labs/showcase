from pathlib import Path


def repo_root() -> Path:
    here = Path(__file__).resolve()
    for candidate in [here.parent, *here.parents]:
        if (candidate / "config" / "default.yaml").exists():
            return candidate
    raise FileNotFoundError("Could not locate repository root containing config/default.yaml")
