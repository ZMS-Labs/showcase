from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


def expand_data_dir(value: str) -> Path:
    expanded = os.path.expandvars(value)
    return Path(expanded).expanduser()


class AppSettings(BaseModel):
    data_dir: str = r"%LOCALAPPDATA%\GridironBroadcastCompanion"
    bind_host: str = "127.0.0.1"
    bind_port: int = Field(default=8765, ge=1, le=65535)
    open_browser: bool = True
    resource_preset: Literal["LOW_IMPACT", "BALANCED", "HIGH_QUALITY", "DISTRIBUTED"] = "BALANCED"

    @field_validator("bind_host")
    @classmethod
    def _host(cls, value: str) -> str:
        if value not in {"127.0.0.1", "localhost", "::1"} and value != "0.0.0.0":
            return value
        return value


class CaptureSettings(BaseModel):
    backend: Literal["windows_capture", "dxcam", "replay", "synthetic"] = "windows_capture"
    target_fps: int = Field(default=30, ge=1, le=120)
    analysis_fps: int = Field(default=10, ge=1, le=60)
    ring_buffer_seconds: int = Field(default=6, ge=1, le=30)
    allow_monitor_capture: bool = False
    hdr_policy: Literal["reject", "warn"] = "reject"
    latest_queue_size: int = Field(default=2, ge=1, le=8)


class PrivacySettings(BaseModel):
    persist_raw_frames: bool = False
    allow_remote_vision: bool = False
    allow_remote_commentary: bool = False
    diagnostic_crop_retention: bool = False
    send_full_roster_remote: bool = False


class FranchiseSettings(BaseModel):
    snapshot_stability_seconds: float = Field(default=2.0, ge=0.1, le=30)
    snapshot_retry_count: int = Field(default=5, ge=1, le=20)
    read_only: bool = True

    @field_validator("read_only")
    @classmethod
    def _readonly(cls, value: bool) -> bool:
        if not value:
            raise ValueError("franchise.read_only must remain true in version 0.1")
        return value


class ProviderEndpoint(BaseModel):
    type: str = "disabled"
    base_url: str = ""
    model: str = ""
    timeout_ms: int = 2000
    temperature: float = 0.1
    voice_play_by_play: str = "am_michael"
    voice_analyst: str = "am_adam"


class ProvidersSettings(BaseModel):
    vision: ProviderEndpoint = Field(default_factory=ProviderEndpoint)
    commentary: ProviderEndpoint = Field(
        default_factory=lambda: ProviderEndpoint(type="deterministic", timeout_ms=1800)
    )
    tts: ProviderEndpoint = Field(default_factory=lambda: ProviderEndpoint(type="mock", timeout_ms=1500))


class ProducerSettings(BaseModel):
    minimum_speak_salience: float = Field(default=0.60, ge=0.0, le=1.0)
    pre_snap_cancel_margin_ms: int = 300
    recent_topic_window_seconds: int = 240
    maximum_queue_depth: int = Field(default=3, ge=1, le=16)


class AudioSettings(BaseModel):
    output_device: str = "default"
    cancellation_fade_ms: int = 75
    cache_generic_reactions: bool = True


class OcrSettings(BaseModel):
    provider: Literal["mock", "rapidocr", "paddleocr"] = "mock"
    consensus_window: int = Field(default=5, ge=2, le=30)
    min_agreeing_frames: int = Field(default=3, ge=2, le=20)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="GBC_",
        env_nested_delimiter="__",
        extra="forbid",
    )

    app: AppSettings = Field(default_factory=AppSettings)
    capture: CaptureSettings = Field(default_factory=CaptureSettings)
    privacy: PrivacySettings = Field(default_factory=PrivacySettings)
    franchise: FranchiseSettings = Field(default_factory=FranchiseSettings)
    providers: ProvidersSettings = Field(default_factory=ProvidersSettings)
    producer: ProducerSettings = Field(default_factory=ProducerSettings)
    audio: AudioSettings = Field(default_factory=AudioSettings)
    ocr: OcrSettings = Field(default_factory=OcrSettings)

    @model_validator(mode="after")
    def _remote_privacy(self) -> Settings:
        vision_remote = self.providers.vision.type in {"openai_compatible"} and bool(self.providers.vision.base_url)
        if vision_remote and not self.privacy.allow_remote_vision:
            raise ValueError("Remote vision endpoint configured but privacy.allow_remote_vision is false")
        commentary_remote = self.providers.commentary.type == "openai_compatible" and bool(
            self.providers.commentary.base_url
        )
        if commentary_remote and not self.privacy.allow_remote_commentary:
            if "localhost" not in self.providers.commentary.base_url and "127.0.0.1" not in (
                self.providers.commentary.base_url
            ):
                raise ValueError("Remote commentary endpoint configured but privacy.allow_remote_commentary is false")
        return self

    def data_path(self) -> Path:
        return expand_data_dir(self.app.data_dir)

    def non_loopback_bind(self) -> bool:
        return self.app.bind_host not in {"127.0.0.1", "localhost", "::1"}


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    out = dict(base)
    for key, value in override.items():
        if key in out and isinstance(out[key], dict) and isinstance(value, dict):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = value
    return out


def load_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Configuration file not found: {path}")
    loaded = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(loaded, dict):
        raise ValueError(f"Configuration must be a mapping: {path}")
    return loaded


def load_settings(
    config_dir: Path | None = None,
    *,
    environment: str = "development",
) -> Settings:
    from gbc.paths import repo_root

    directory = config_dir or (repo_root() / "config")
    data = load_yaml(directory / "default.yaml")
    env_path = directory / f"{environment}.yaml"
    if env_path.exists():
        data = _deep_merge(data, load_yaml(env_path))
    try:
        return Settings.model_validate(data)
    except Exception as exc:
        raise ValueError(f"Invalid configuration in {directory}: {exc}") from exc
