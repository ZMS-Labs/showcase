from __future__ import annotations

import json
from io import BytesIO
from pathlib import Path
from typing import Any
from uuid import uuid4

import numpy as np
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles
from PIL import Image
from pydantic import BaseModel

from gbc.application import Runtime, create_runtime
from gbc.capture import WindowsCaptureSource
from gbc.capture.synthetic import render_synthetic_hud
from gbc.config.settings import Settings
from gbc.contracts.capture import CaptureOptions, CaptureTarget, DisplayProfile, ScoreboardSnapshot
from gbc.contracts.enums import RoiType
from gbc.evaluation.benchmark import evaluate_fixture, write_reports
from gbc.franchise.bridge import parse_capability, run_bridge
from gbc.franchise.snapshot import create_stable_snapshot
from gbc.perception.ocr.lab import crop_normalized, normalize_ocr, recognize_crop
from gbc.replay.runner import run_fixture


class SafetyAck(BaseModel):
    acknowledged: bool


class SelectWindow(BaseModel):
    target_id: str
    allow_monitor: bool = False


class FranchiseSelect(BaseModel):
    path: str


class SessionStart(BaseModel):
    human_team: str
    profile_id: str


class ProfileIn(BaseModel):
    profile: DisplayProfile


class ReplayIn(BaseModel):
    fixture: str = "drive-scoring-void"


class PronunciationIn(BaseModel):
    name: str
    phoneme: str


class LabOcrIn(BaseModel):
    roi_id: str = "lab"
    roi_type: str
    x: float
    y: float
    w: float
    h: float
    variant: str = "default"


class LabFreezeIn(BaseModel):
    frozen: bool


class LabAnnotationIn(BaseModel):
    kind: str
    label: str
    payload: dict[str, Any] = {}


def create_app(runtime: Runtime | None = None) -> FastAPI:
    rt = runtime or create_runtime()
    app = FastAPI(title="Gridiron Broadcast Companion", version="0.1.0")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://127.0.0.1:8765", "http://localhost:8765", "http://127.0.0.1:5173"],
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.state.runtime = rt

    @app.get("/api/v1/health")
    def health() -> dict[str, Any]:
        settings: Settings = rt.settings
        warning = None
        if settings.non_loopback_bind():
            warning = "Non-loopback bind is enabled. This exposes the companion on the network."
        return {
            "status": "ok",
            "version": "0.1.0",
            "bind": f"{settings.app.bind_host}:{settings.app.bind_port}",
            "degraded": [m.value for m in rt.degraded],
            "safety_ack": rt.safety_ack,
            "security_warning": warning,
            "capture": rt.capture_health.model_dump(),
            "validation_failures": rt.validation_failures,
            "muted": rt.muted,
        }

    @app.post("/api/v1/safety/ack")
    def safety_ack(body: SafetyAck) -> dict[str, bool]:
        rt.safety_ack = body.acknowledged
        return {"ok": rt.safety_ack}

    @app.get("/api/v1/windows")
    def windows() -> list[dict[str, Any]]:
        source = WindowsCaptureSource()
        live = source.list_targets()
        synthetic = CaptureTarget(target_id="synthetic", title="Synthetic HUD", kind="synthetic")
        rt.windows = [synthetic, *live]
        return [t.model_dump() for t in rt.windows]

    @app.post("/api/v1/capture/start")
    def capture_start(body: SelectWindow) -> dict[str, Any]:
        target = next((t for t in rt.windows or [] if t.target_id == body.target_id), None)
        if target is None:
            if body.target_id == "synthetic":
                target = CaptureTarget(target_id="synthetic", title="Synthetic HUD", kind="synthetic")
            else:
                target = CaptureTarget(target_id=body.target_id, title=body.target_id)
        if target.kind == "monitor" and not body.allow_monitor:
            raise HTTPException(400, "Full-monitor capture requires an explicit user action")
        rt.selected_window = target
        source = WindowsCaptureSource()
        source.start(target, CaptureOptions(allow_monitor=body.allow_monitor))
        rt.capture_source = source
        frame: np.ndarray | None
        if target.kind == "synthetic":
            frame = render_synthetic_hud()
            rt.capture_health = source.health()
            rt.capture_health.running = True
            rt.capture_health.message = f"capturing {target.title}"
        else:
            frame = source.grab_latest()
            if frame is None:
                raise HTTPException(400, source.health().message or "window capture failed")
            rt.capture_health = source.health()
        if frame is None:
            raise HTTPException(400, "capture produced no frame")
        rt.preview_bgr = frame
        rt.preview_png = _png(frame)
        return {"ok": True, "target": target.model_dump(), "health": rt.capture_health.model_dump()}

    @app.post("/api/v1/capture/stop")
    def capture_stop() -> dict[str, bool]:
        rt.capture_health.running = False
        return {"ok": True}

    @app.get("/api/v1/capture/preview")
    def capture_preview() -> Response:
        if not rt.lab_frozen and rt.capture_source is not None and rt.selected_window is not None:
            latest = getattr(rt.capture_source, "grab_latest", lambda: None)()
            if latest is not None:
                rt.preview_bgr = latest
                rt.preview_png = _png(latest)
        data = rt.preview_png or _png(render_synthetic_hud())
        return Response(content=data, media_type="image/png")

    @app.get("/api/v1/profiles")
    def profiles() -> list[dict[str, Any]]:
        return [p.model_dump(mode="json") for p in rt.profiles.values()]

    @app.post("/api/v1/profiles")
    def save_profile(body: ProfileIn) -> dict[str, Any]:
        profile = body.profile
        existing = rt.profiles.get(profile.profile_id)
        if existing is not None and existing.roi_definitions != profile.roi_definitions:
            profile = profile.model_copy(update={"revision": existing.revision + 1})
        rt.profiles[profile.profile_id] = profile
        rt.profile = profile
        return profile.model_dump(mode="json")

    @app.post("/api/v1/profiles/{profile_id}/validate")
    def validate_profile(profile_id: str) -> dict[str, Any]:
        profile = rt.profiles.get(profile_id)
        if profile is None:
            raise HTTPException(404, "profile not found")
        stale = profile.stale or not profile.roi_definitions
        return {"profile_id": profile_id, "stale": stale, "ok": not stale}

    @app.get("/api/v1/lab/roi-types")
    def lab_roi_types() -> list[str]:
        return [item.value for item in RoiType]

    @app.post("/api/v1/lab/freeze")
    def lab_freeze(body: LabFreezeIn) -> dict[str, bool]:
        rt.lab_frozen = body.frozen
        return {"frozen": rt.lab_frozen}

    @app.post("/api/v1/lab/ocr-test")
    def lab_ocr_test(body: LabOcrIn) -> dict[str, Any]:
        import hashlib
        from datetime import UTC, datetime
        from uuid import uuid4

        frame = rt.preview_bgr
        if frame is None:
            frame = render_synthetic_hud()
            rt.preview_bgr = frame
        crop = crop_normalized(frame, body.x, body.y, body.w, body.h)
        hud = rt.last_hud if (rt.selected_window is None or rt.selected_window.kind == "synthetic") else None
        variants = {}
        for variant in ("default", "invert", "threshold", "contrast"):
            result = recognize_crop(crop, body.roi_type, variant, hud=hud)
            variants[variant] = {"raw_text": result.text, "confidence": result.confidence}
        chosen = variants.get(body.variant, variants["default"])
        normalized = normalize_ocr(body.roi_type, str(chosen["raw_text"]))
        rt.consensus.ingest(body.roi_type, normalized)
        consensus_value, band = rt.consensus.consensus(body.roi_type)
        observation = {
            "observation_id": uuid4().hex,
            "roi_id": body.roi_id,
            "roi_type": body.roi_type,
            "raw_text": chosen["raw_text"],
            "normalized_value": normalized,
            "ocr_confidence": chosen["confidence"],
            "preprocessing_variant": body.variant,
            "evidence_hash": hashlib.sha256(crop.tobytes()).hexdigest()[:16],
            "created_at": datetime.now(tz=UTC).isoformat(),
            "consensus_value": consensus_value,
            "consensus_confidence": band.value,
        }
        rt.last_ocr[body.roi_type] = observation
        fields = rt.consensus.snapshot_fields(datetime.now(tz=UTC))
        required = ["home_score", "away_score", "quarter", "down", "distance"]
        rt.last_scoreboard = ScoreboardSnapshot(
            snapshot_id=uuid4().hex,
            timestamp=datetime.now(tz=UTC),
            home_team=fields["home_team"],
            away_team=fields["away_team"],
            home_score=fields["home_score"],
            away_score=fields["away_score"],
            quarter=fields["quarter"],
            game_clock_ms=fields["game_clock_ms"],
            play_clock_seconds=fields["play_clock_seconds"],
            down=fields["down"],
            distance=fields["distance"],
            ball_spot=fields["ball_spot"],
            possession_team=fields["possession_team"],
            timeouts_home=fields["timeouts_home"],
            timeouts_away=fields["timeouts_away"],
            is_stable=rt.consensus.is_stable(fields, required),
            field_level_evidence=[body.roi_id],
        )
        return {
            "observation": observation,
            "variants": variants,
            "scoreboard": rt.last_scoreboard.model_dump(mode="json"),
        }

    @app.post("/api/v1/lab/annotations")
    def lab_annotate(body: LabAnnotationIn) -> dict[str, Any]:
        item = {"kind": body.kind, "label": body.label, "payload": body.payload}
        rt.annotations.append(item)
        return {"count": len(rt.annotations), "item": item}

    @app.get("/api/v1/live/state")
    def live_state() -> dict[str, Any]:
        event = None
        if rt.reconciler and rt.reconciler.events:
            last = rt.reconciler.events[-1]
            event = {
                "event_id": last.event_id,
                "status": last.status.value,
                "play_type": last.play_type.value,
                "result_type": last.result_type.value,
            }
            rt.last_event = event
        scoreboard = rt.last_scoreboard.model_dump(mode="json") if rt.last_scoreboard else None
        field_confidence = {}
        if rt.last_scoreboard:
            for name in (
                "home_score",
                "away_score",
                "quarter",
                "down",
                "distance",
                "game_clock_ms",
                "possession_team",
            ):
                field = getattr(rt.last_scoreboard, name)
                field_confidence[name] = field.confidence.value
        return {
            "capture": rt.capture_health.model_dump(),
            "phase": rt.reconciler.phase.value if rt.reconciler else "UNKNOWN",
            "raw_ocr": rt.last_ocr,
            "scoreboard": scoreboard,
            "field_confidence": field_confidence,
            "current_event": event,
            "statistics": rt.stats.current.__dict__,
            "storylines": rt.storylines,
            "repeated_plays": [
                {
                    "key": rec.key,
                    "match_level": rec.match_level.value,
                    "use_count": rec.use_count,
                    "success_count": rec.success_count,
                }
                for rec in rt.tendencies.records.values()
            ],
            "last_utterance": rt.scheduler.captions[-1] if rt.scheduler.captions else None,
            "queued_speech": [item.text for item in rt.scheduler.queue if not item.cancelled],
            "commentary_latency_ms": rt.commentary_latency_ms,
            "tts_latency_ms": rt.tts_latency_ms,
            "dropped_frames": rt.capture_health.dropped_frames,
            "validation_failures": rt.validation_failures,
            "degraded": [m.value for m in rt.degraded],
            "muted": rt.muted,
            "profile_stale": bool(rt.profile.stale) if rt.profile else True,
        }

    @app.post("/api/v1/franchise/snapshot")
    def franchise_snapshot(body: FranchiseSelect) -> dict[str, Any]:
        source = Path(body.path)
        if ".." in source.as_posix():
            raise HTTPException(400, "path traversal rejected")
        dest = rt.data_dir() / "snapshots"
        try:
            meta = create_stable_snapshot(
                source,
                dest,
                stability_seconds=0.01,
                retries=2,
                poll_seconds=0.0,
            )
        except Exception as exc:
            raise HTTPException(400, str(exc)) from exc
        rt.snapshot = meta
        try:
            payload = run_bridge("capabilities", Path(meta.snapshot_path))
            rt.capability = parse_capability(payload)
        except Exception as exc:
            from gbc.contracts.franchise import CapabilityReport

            rt.capability = CapabilityReport(
                parser_version="madden-franchise/4.3.6",
                snapshot_hash=meta.snapshot_hash,
                warnings=[f"Bridge unavailable or snapshot unreadable: {exc}"],
                degraded_features=["season_context", "roster"],
            )
        return {**meta.model_dump(), "capability": rt.capability.model_dump(mode="json")}

    @app.get("/api/v1/franchise/capabilities")
    def franchise_capabilities() -> dict[str, Any]:
        if rt.capability is not None:
            return rt.capability.model_dump(mode="json")
        if rt.snapshot is None:
            return {
                "parser_version": "unparsed",
                "snapshot_hash": "",
                "tables": [],
                "warnings": ["No snapshot selected"],
                "degraded_features": ["season_context"],
            }
        return {
            "parser_version": "madden-franchise/4.3.6",
            "snapshot_hash": rt.snapshot.snapshot_hash,
            "tables": [],
            "warnings": ["Madden 27 live parse UNVERIFIED until Node bridge runs on a real save"],
            "degraded_features": ["season_context"],
        }

    @app.post("/api/v1/session/start")
    def session_start(body: SessionStart) -> dict[str, Any]:
        if not rt.safety_ack:
            raise HTTPException(400, "Safety boundary must be acknowledged")
        rt.human_team = body.human_team
        rt.profile = rt.profiles.get(body.profile_id, rt.profile)
        if rt.profile and rt.profile.stale:
            raise HTTPException(400, "PROFILE_STALE")
        rt.session_id = uuid4().hex
        from gbc.events.reconciler import EventReconciler

        rt.reconciler = EventReconciler(rt.session_id)
        return {"session_id": rt.session_id, "degraded": [m.value for m in rt.degraded]}

    @app.post("/api/v1/session/stop")
    def session_stop() -> dict[str, Any]:
        sid = rt.session_id
        rt.session_id = None
        return {"stopped": sid}

    @app.get("/api/v1/session/current")
    def session_current() -> dict[str, Any]:
        return {
            "session_id": rt.session_id,
            "human_team": rt.human_team,
            "window": rt.selected_window.model_dump() if rt.selected_window else None,
            "degraded": [m.value for m in rt.degraded],
            "phase": rt.reconciler.phase.value if rt.reconciler else "UNKNOWN",
            "muted": rt.muted,
        }

    @app.get("/api/v1/events")
    def events() -> list[dict[str, Any]]:
        if not rt.reconciler:
            return []
        return [e.model_dump(mode="json") for e in rt.reconciler.events]

    @app.get("/api/v1/facts")
    def facts() -> list[dict[str, Any]]:
        if not rt.reconciler or not rt.reconciler.events:
            return []
        from datetime import UTC, datetime

        from gbc.contracts.broadcast import SpeechIntent
        from gbc.contracts.enums import CertaintyStyle, IntentType, Interruptibility, Speaker
        from gbc.facts.compiler import FactCompiler

        event = rt.reconciler.events[-1]
        intent = SpeechIntent(
            intent_id="inspect",
            priority=5,
            speaker=Speaker.ANALYST,
            intent_type=IntentType.ANALYSIS,
            allowed_fact_ids=[],
            topic_ids=[],
            maximum_words=24,
            deadline_monotonic_ns=0,
            estimated_available_seconds=6.0,
            interruptibility=Interruptibility.SENTENCE,
            certainty_style=CertaintyStyle.CONFIRMED,
            fallback_template_id="silence",
        )
        packet = FactCompiler().compile(
            intent,
            session_id=rt.session_id or "none",
            now=datetime.now(tz=UTC),
            event=event,
            stats=rt.stats.current,
            tendency=None,
            recently_said=rt.scheduler.captions[-5:],
            franchise_available=rt.capability is not None,
        )
        return [f.model_dump(mode="json") for f in packet.facts]

    @app.get("/api/v1/utterances")
    def utterances() -> list[str]:
        return rt.scheduler.captions

    @app.get("/api/v1/metrics")
    def metrics() -> dict[str, Any]:
        return {
            "dropped_frames": rt.capture_health.dropped_frames,
            "validation_failures": rt.validation_failures,
            "queue_depth": len(rt.scheduler.queue),
            "fps": rt.capture_health.fps,
        }

    @app.post("/api/v1/audio/mute")
    def mute() -> dict[str, bool]:
        rt.muted = True
        rt.scheduler.panic_mute()
        return {"muted": True}

    @app.post("/api/v1/audio/unmute")
    def unmute() -> dict[str, bool]:
        rt.muted = False
        rt.scheduler.unmute()
        return {"muted": False}

    @app.post("/api/v1/providers/test")
    def providers_test() -> dict[str, Any]:
        return {
            "commentary": rt.commentary.health(),
            "tts": rt.tts.health(),
            "vision": {"status": "disabled", "provider": "disabled"},
        }

    @app.post("/api/v1/replay/run")
    def replay_run(body: ReplayIn) -> dict[str, Any]:
        fixture = _safe_fixture(body.fixture)
        result = run_fixture(fixture)
        report, _ = evaluate_fixture(fixture)
        out = rt.data_dir() / "reports" / result.fixture
        json_path, html_path = write_reports(report, out)
        return {
            "id": result.fixture,
            "observed_events": result.observed_events,
            "expected_events": result.expected_events,
            "statuses": result.statuses,
            "utterances": result.utterances,
            "deterministic_hash": result.deterministic_hash,
            "report_json": str(json_path),
            "report_html": str(html_path),
        }

    @app.get("/api/v1/replay/report/{report_id}")
    def replay_report(report_id: str) -> dict[str, Any]:
        path = rt.data_dir() / "reports" / report_id / "benchmark.json"
        if not path.exists():
            raise HTTPException(404, "report not found")
        payload: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
        return payload

    @app.post("/api/v1/pronunciations")
    def save_pronunciation(body: PronunciationIn) -> dict[str, str]:
        rt.pronunciations[body.name] = body.phoneme
        return {"name": body.name, "phoneme": body.phoneme}

    @app.get("/api/v1/pronunciations")
    def list_pronunciations() -> dict[str, str]:
        return rt.pronunciations

    @app.websocket("/api/v1/live")
    async def live(ws: WebSocket) -> None:
        await ws.accept()
        try:
            await ws.send_json(
                {
                    "phase": rt.reconciler.phase.value if rt.reconciler else "UNKNOWN",
                    "capture": rt.capture_health.model_dump(),
                    "degraded": [m.value for m in rt.degraded],
                    "muted": rt.muted,
                }
            )
            while True:
                await ws.receive_text()
                await ws.send_json({"ok": True})
        except WebSocketDisconnect:
            return

    web_dist = Path(__file__).resolve().parents[4] / "web" / "dist"
    if web_dist.exists():
        app.mount("/", StaticFiles(directory=str(web_dist), html=True), name="web")

    return app


def _png(array: np.ndarray) -> bytes:
    image = Image.fromarray(array[:, :, ::-1])
    buf = BytesIO()
    image.save(buf, format="PNG")
    return buf.getvalue()


def _safe_fixture(name: str) -> Path:
    root = Path(__file__).resolve().parents[4] / "fixtures" / "synthetic"
    candidate = (root / name).resolve()
    if root.resolve() not in candidate.parents and candidate != root:
        raise HTTPException(400, "invalid fixture path")
    if not candidate.exists():
        raise HTTPException(404, "fixture not found")
    return candidate
