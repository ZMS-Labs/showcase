from __future__ import annotations

import re
from typing import Any

import numpy as np

from gbc.contracts.enums import RoiType
from gbc.perception.ocr.providers import MockOcrProvider, OcrRawResult, RapidOcrProvider
from gbc.perception.parsers import (
    parse_ball_spot,
    parse_clock_ms,
    parse_distance,
    parse_down,
    parse_play_clock,
    parse_quarter,
    parse_score,
    parse_team_abbrev,
)

SYNTHETIC_FIELD_MAP: dict[str, str] = {
    RoiType.HOME_ABBREV.value: "home",
    RoiType.AWAY_ABBREV.value: "away",
    RoiType.HOME_SCORE.value: "home_score",
    RoiType.AWAY_SCORE.value: "away_score",
    RoiType.QUARTER.value: "quarter",
    RoiType.GAME_CLOCK.value: "clock",
    RoiType.PLAY_CLOCK.value: "play_clock",
    RoiType.DOWN.value: "down",
    RoiType.DISTANCE.value: "distance",
    RoiType.BALL_SPOT.value: "ball_spot",
    RoiType.POSSESSION.value: "possession",
}


def crop_normalized(image: np.ndarray, x: float, y: float, w: float, h: float) -> np.ndarray:
    height, width = image.shape[:2]
    x0 = max(0, min(width - 1, int(x * width)))
    y0 = max(0, min(height - 1, int(y * height)))
    x1 = max(x0 + 1, min(width, int((x + w) * width)))
    y1 = max(y0 + 1, min(height, int((y + h) * height)))
    return image[y0:y1, x0:x1].copy()


def preprocess(image: np.ndarray, variant: str) -> np.ndarray:
    gray: np.ndarray = image.mean(axis=2).astype(np.uint8) if image.ndim == 3 else image.astype(np.uint8)
    if variant == "invert":
        inverted: np.ndarray = np.asarray(255 - gray, dtype=np.uint8)
        return inverted
    if variant == "threshold":
        return np.where(gray > 128, 255, 0).astype(np.uint8)
    if variant == "contrast":
        stretched = (gray.astype(np.float32) - gray.min()) / max(1, int(gray.max() - gray.min()))
        contrasted: np.ndarray = (stretched * 255).astype(np.uint8)
        return contrasted
    return gray


def normalize_ocr(roi_type: str, raw: str) -> str | None:
    if roi_type in {RoiType.HOME_SCORE.value, RoiType.AWAY_SCORE.value}:
        parsed = parse_score(raw)
        return None if parsed is None else str(parsed)
    if roi_type == RoiType.QUARTER.value:
        parsed = parse_quarter(raw)
        return None if parsed is None else str(parsed)
    if roi_type == RoiType.GAME_CLOCK.value:
        if parse_clock_ms(raw) is None:
            return None
        match = re.search(r"(\d{1,2}:\d{2})", raw)
        return match.group(1) if match else None
    if roi_type == RoiType.PLAY_CLOCK.value:
        parsed = parse_play_clock(raw)
        return None if parsed is None else str(parsed)
    if roi_type == RoiType.DOWN.value:
        parsed = parse_down(raw)
        return None if parsed is None else str(parsed)
    if roi_type == RoiType.DISTANCE.value:
        parsed = parse_distance(raw)
        return None if parsed is None else str(parsed)
    if roi_type in {RoiType.HOME_ABBREV.value, RoiType.AWAY_ABBREV.value, RoiType.POSSESSION.value}:
        return parse_team_abbrev(raw)
    if roi_type == RoiType.BALL_SPOT.value:
        spot = parse_ball_spot(raw, None)
        if spot is None:
            return raw.strip() or None
        if spot.at_midfield:
            return "50"
        return f"{spot.team_whose_side} {spot.yard_number}"
    cleaned = raw.strip()
    return cleaned or None


def synthetic_text(hud: dict[str, Any], roi_type: str) -> str:
    key = SYNTHETIC_FIELD_MAP.get(roi_type)
    if key is None:
        return ""
    return str(hud.get(key, ""))


def recognize_crop(
    crop: np.ndarray,
    roi_type: str,
    variant: str,
    *,
    hud: dict[str, Any] | None = None,
    prefer_rapid: bool = True,
) -> OcrRawResult:
    processed = preprocess(crop, variant)
    if hud is not None and roi_type in SYNTHETIC_FIELD_MAP:
        text = synthetic_text(hud, roi_type)
        return OcrRawResult(text=text, confidence=0.99 if text else 0.0)
    if prefer_rapid:
        try:
            return RapidOcrProvider().recognize(processed, roi_type)
        except RuntimeError:
            pass
    return MockOcrProvider().recognize(processed, roi_type)
