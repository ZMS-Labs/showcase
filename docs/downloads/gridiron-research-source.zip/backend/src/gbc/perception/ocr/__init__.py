"""OCR providers."""
