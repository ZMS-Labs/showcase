from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass
class OcrRawResult:
    text: str
    confidence: float


class MockOcrProvider:
    name = "mock"

    def recognize(self, image: np.ndarray, roi_type: str, settings: dict[str, Any] | None = None) -> OcrRawResult:
        del image, settings
        return OcrRawResult(text="", confidence=0.0)


class RapidOcrProvider:
    name = "rapidocr"

    def __init__(self) -> None:
        try:
            from rapidocr import RapidOCR
        except ImportError as exc:
            raise RuntimeError("rapidocr is not installed") from exc
        self._engine = RapidOCR()

    def recognize(self, image: np.ndarray, roi_type: str, settings: dict[str, Any] | None = None) -> OcrRawResult:
        del roi_type, settings
        result = self._engine(image)
        if not result:
            return OcrRawResult(text="", confidence=0.0)
        texts = []
        confs = []
        payload = result[0] if isinstance(result, tuple) else result
        for item in payload or []:
            if len(item) >= 2:
                texts.append(str(item[1]))
            if len(item) >= 3:
                try:
                    confs.append(float(item[2]))
                except (TypeError, ValueError):
                    pass
        return OcrRawResult(text=" ".join(texts), confidence=sum(confs) / len(confs) if confs else 0.0)
