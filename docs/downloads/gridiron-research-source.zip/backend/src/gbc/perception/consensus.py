from __future__ import annotations

from collections import defaultdict, deque
from datetime import datetime
from typing import Any

from gbc.contracts.enums import Authority, ConfidenceBand, EpistemicClass, RoiType
from gbc.contracts.provenance import Provenanced
from gbc.perception.parsers import (
    parse_ball_spot,
    parse_clock_ms,
    parse_distance,
    parse_down,
    parse_play_clock,
    parse_quarter,
    parse_score,
    parse_team_abbrev,
)


def _unknown(now: datetime) -> Provenanced[Any]:
    return Provenanced(
        value=None,
        source="none",
        timestamp=now,
        confidence=ConfidenceBand.UNKNOWN,
        authority=Authority.HEURISTIC,
        epistemic_class=EpistemicClass.PUBLIC_OBSERVATION,
        speakable=False,
    )


def _prov(value: Any, now: datetime, conf: ConfidenceBand) -> Provenanced[Any]:
    speakable = conf in {ConfidenceBand.CONFIRMED, ConfidenceBand.HIGH}
    return Provenanced(
        value=value,
        source="ocr_consensus",
        timestamp=now,
        confidence=conf,
        authority=Authority.OCR_CONSENSUS,
        epistemic_class=EpistemicClass.PUBLIC_OBSERVATION,
        speakable=speakable,
    )


class TemporalReconciler:
    """Combine multiple OCR observations into stable per-field values."""

    def __init__(self, window: int = 5, min_agree: int = 3) -> None:
        self.window = window
        self.min_agree = min_agree
        self._buffers: dict[str, deque[str]] = defaultdict(lambda: deque(maxlen=window))
        self._last_scores: dict[str, int] = {"HOME_SCORE": 0, "AWAY_SCORE": 0}
        self._last_quarter: int | None = None

    def ingest(self, roi_type: str, normalized: str | None) -> None:
        if normalized is None or normalized == "":
            return
        self._buffers[roi_type].append(normalized)

    def consensus(self, roi_type: str) -> tuple[str | None, ConfidenceBand]:
        values = list(self._buffers.get(roi_type, ()))
        if not values:
            return None, ConfidenceBand.UNKNOWN
        counts: dict[str, int] = {}
        for item in values:
            counts[item] = counts.get(item, 0) + 1
        winner, count = max(counts.items(), key=lambda kv: kv[1])
        if count >= self.min_agree:
            band = ConfidenceBand.CONFIRMED if count >= self.window - 1 else ConfidenceBand.HIGH
            return winner, band
        if count >= 2:
            return winner, ConfidenceBand.MEDIUM
        return winner, ConfidenceBand.LOW

    def _score(self, roi_type: str, now: datetime) -> Provenanced[int]:
        raw, band = self.consensus(roi_type)
        parsed = parse_score(raw or "")
        if parsed is None:
            return _unknown(now)
        last = self._last_scores.get(roi_type, 0)
        if parsed < last and band != ConfidenceBand.CONFIRMED:
            return _prov(last, now, ConfidenceBand.MEDIUM)
        if parsed < last and band == ConfidenceBand.CONFIRMED:
            # Ordinary scores cannot decrease; keep last unless a correction path resets.
            return _prov(last, now, ConfidenceBand.HIGH)
        if band in {ConfidenceBand.CONFIRMED, ConfidenceBand.HIGH}:
            self._last_scores[roi_type] = parsed
        return _prov(parsed, now, band)

    def snapshot_fields(
        self,
        now: datetime,
        *,
        allowed_teams: set[str] | None = None,
        possession_hint: str | None = None,
    ) -> dict[str, Provenanced[Any]]:
        home_ab, home_band = self.consensus(RoiType.HOME_ABBREV.value)
        away_ab, away_band = self.consensus(RoiType.AWAY_ABBREV.value)
        q_raw, q_band = self.consensus(RoiType.QUARTER.value)
        clock_raw, clock_band = self.consensus(RoiType.GAME_CLOCK.value)
        play_raw, play_band = self.consensus(RoiType.PLAY_CLOCK.value)
        down_raw, down_band = self.consensus(RoiType.DOWN.value)
        dist_raw, dist_band = self.consensus(RoiType.DISTANCE.value)
        poss_raw, poss_band = self.consensus(RoiType.POSSESSION.value)
        spot_raw, spot_band = self.consensus(RoiType.BALL_SPOT.value)
        to_h_raw, to_h_band = self.consensus(RoiType.TIMEOUTS_HOME.value)
        to_a_raw, to_a_band = self.consensus(RoiType.TIMEOUTS_AWAY.value)

        quarter = parse_quarter(q_raw or "")
        if quarter is not None and self._last_quarter is not None and quarter < self._last_quarter:
            if q_band != ConfidenceBand.CONFIRMED:
                quarter = self._last_quarter
                q_band = ConfidenceBand.MEDIUM
        if quarter is not None and q_band in {ConfidenceBand.CONFIRMED, ConfidenceBand.HIGH}:
            self._last_quarter = quarter

        possession = parse_team_abbrev(poss_raw or "", allowed_teams) if poss_raw else None
        spot = parse_ball_spot(spot_raw or "", possession or possession_hint)

        def wrap(value: Any, band: ConfidenceBand) -> Provenanced[Any]:
            if value is None:
                return _unknown(now)
            return _prov(value, now, band)

        return {
            "home_team": wrap(parse_team_abbrev(home_ab or "", allowed_teams), home_band),
            "away_team": wrap(parse_team_abbrev(away_ab or "", allowed_teams), away_band),
            "home_score": self._score(RoiType.HOME_SCORE.value, now),
            "away_score": self._score(RoiType.AWAY_SCORE.value, now),
            "quarter": wrap(quarter, q_band),
            "game_clock_ms": wrap(parse_clock_ms(clock_raw or ""), clock_band),
            "play_clock_seconds": wrap(parse_play_clock(play_raw or ""), play_band),
            "down": wrap(parse_down(down_raw or ""), down_band),
            "distance": wrap(parse_distance(dist_raw or ""), dist_band),
            "possession_team": wrap(possession, poss_band),
            "ball_spot": wrap(spot, spot_band),
            "timeouts_home": wrap(parse_score(to_h_raw or ""), to_h_band),
            "timeouts_away": wrap(parse_score(to_a_raw or ""), to_a_band),
        }

    def is_stable(self, fields: dict[str, Provenanced[Any]], required: list[str]) -> bool:
        for key in required:
            item = fields.get(key)
            if item is None or item.value is None:
                return False
            if item.confidence not in {ConfidenceBand.CONFIRMED, ConfidenceBand.HIGH}:
                return False
        return True

    def reset_scores_for_correction(self, home: int, away: int) -> None:
        self._last_scores["HOME_SCORE"] = home
        self._last_scores["AWAY_SCORE"] = away
