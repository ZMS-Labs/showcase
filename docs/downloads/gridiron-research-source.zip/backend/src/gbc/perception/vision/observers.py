from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class VisionTags:
    tags: list[str] = field(default_factory=list)
    jersey_numbers: list[int] = field(default_factory=list)
    confidence: float = 0.0
    authority: str = "VISION_INFERENCE"


class MockVisionObserver:
    name = "mock"

    def health(self) -> dict[str, str]:
        return {"status": "ok", "provider": self.name}

    def warmup(self) -> None:
        return None

    def observe(self, request: dict[str, Any]) -> VisionTags:
        del request
        return VisionTags()


class DisabledVisionObserver(MockVisionObserver):
    name = "disabled"
