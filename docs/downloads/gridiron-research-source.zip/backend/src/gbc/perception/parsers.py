from __future__ import annotations

import re

from gbc.contracts.provenance import FieldPosition, distance_to_goal

QUARTER_MAP = {
    "1": 1,
    "1ST": 1,
    "Q1": 1,
    "2": 2,
    "2ND": 2,
    "Q2": 2,
    "3": 3,
    "3RD": 3,
    "Q3": 3,
    "4": 4,
    "4TH": 4,
    "Q4": 4,
    "OT": 5,
    "OT1": 5,
}

NUMBER_WORDS = {
    "zero": 0,
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "six": 6,
    "seven": 7,
    "eight": 8,
    "nine": 9,
    "ten": 10,
    "eleven": 11,
    "twelve": 12,
    "thirteen": 13,
    "fourteen": 14,
    "fifteen": 15,
    "sixteen": 16,
    "seventeen": 17,
    "eighteen": 18,
    "nineteen": 19,
    "twenty": 20,
    "thirty": 30,
    "forty": 40,
    "fifty": 50,
    "sixty": 60,
    "seventy": 70,
    "eighty": 80,
    "ninety": 90,
    "hundred": 100,
    "thousand": 1000,
}

ORDINALS = {
    "first": 1,
    "second": 2,
    "third": 3,
    "fourth": 4,
    "fifth": 5,
    "sixth": 6,
    "seventh": 7,
    "eighth": 8,
    "ninth": 9,
    "tenth": 10,
}


def parse_score(text: str) -> int | None:
    cleaned = re.sub(r"[^0-9]", "", text)
    if cleaned == "":
        return None
    value = int(cleaned)
    if 0 <= value <= 99:
        return value
    return None


def parse_quarter(text: str) -> int | None:
    key = re.sub(r"[^A-Z0-9]", "", text.upper())
    return QUARTER_MAP.get(key)


def parse_clock_ms(text: str) -> int | None:
    match = re.search(r"(\d{1,2}):(\d{2})", text)
    if not match:
        return None
    minutes = int(match.group(1))
    seconds = int(match.group(2))
    if seconds >= 60 or minutes > 15:
        return None
    return (minutes * 60 + seconds) * 1000


def parse_play_clock(text: str) -> int | None:
    cleaned = re.sub(r"[^0-9]", "", text)
    if cleaned == "":
        return None
    value = int(cleaned)
    if 0 <= value <= 40:
        return value
    return None


def parse_down(text: str) -> int | None:
    key = re.sub(r"[^A-Z0-9]", "", text.upper())
    mapping = {"1": 1, "1ST": 1, "2": 2, "2ND": 2, "3": 3, "3RD": 3, "4": 4, "4TH": 4}
    return mapping.get(key)


def parse_distance(text: str) -> int | None:
    upper = text.upper().strip()
    if "INCH" in upper or upper in {"IN", "INCHES"}:
        return 0
    if "GOAL" in upper or upper in {"G", "GL"}:
        return 0
    cleaned = re.sub(r"[^0-9]", "", text)
    if cleaned == "":
        return None
    value = int(cleaned)
    if 0 <= value <= 99:
        return value
    return None


def parse_team_abbrev(text: str, allowed: set[str] | None = None) -> str | None:
    key = re.sub(r"[^A-Z]", "", text.upper())
    if len(key) < 2 or len(key) > 4:
        return None
    if allowed is not None and key not in allowed:
        return None
    return key


def parse_ball_spot(text: str, possession_team: str | None) -> FieldPosition | None:
    upper = text.upper().strip()
    if "50" in upper or "MID" in upper:
        return FieldPosition.midfield()
    match = re.search(r"([A-Z]{2,4})\s*(\d{1,2})", upper)
    if not match:
        return None
    side = match.group(1)
    yard = int(match.group(2))
    if yard < 1 or yard > 50:
        return None
    dtg = distance_to_goal(possession_team or side, side, yard, at_midfield=False)
    return FieldPosition(
        team_whose_side=side,
        yard_number=yard,
        at_midfield=False,
        distance_to_goal_for_possession=dtg,
    )


def parse_number_words(text: str) -> list[int]:
    tokens = re.findall(r"[a-zA-Z]+|\d+", text.lower())
    found: list[int] = []
    acc = 0
    used = False
    for token in tokens:
        if token.isdigit():
            if used:
                found.append(acc)
                acc = 0
                used = False
            found.append(int(token))
            continue
        if token in ORDINALS:
            if used:
                found.append(acc)
                acc = 0
            found.append(ORDINALS[token])
            used = False
            continue
        if token not in NUMBER_WORDS:
            if used:
                found.append(acc)
                acc = 0
                used = False
            continue
        value = NUMBER_WORDS[token]
        if value in {100, 1000} and acc:
            acc *= value
        elif value >= 20 and acc or acc and value < 10:
            acc += value
        else:
            acc = acc + value if used else value
        used = True
    if used:
        found.append(acc)
    return found


def extract_names(text: str) -> list[str]:
    return re.findall(r"\b[A-Z][a-z]+(?:\s[A-Z][a-z]+)?\b", text)
