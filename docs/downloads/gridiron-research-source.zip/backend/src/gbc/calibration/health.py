from gbc.contracts.capture import DisplayProfile


def profile_health(profile: DisplayProfile) -> dict[str, object]:
    stale = profile.stale or not profile.roi_definitions
    if profile.aspect_ratio != "16:9":
        stale = True
    if profile.capture_width / max(profile.capture_height, 1) < 1.6:
        stale = True
    return {"stale": stale, "ok": not stale, "mode": "PROFILE_STALE" if stale else "OK"}
