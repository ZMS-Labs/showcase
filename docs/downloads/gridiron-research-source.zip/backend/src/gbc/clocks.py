from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import UTC, datetime


class Clock(ABC):
    @abstractmethod
    def now_utc(self) -> datetime:
        raise NotImplementedError

    @abstractmethod
    def monotonic_ns(self) -> int:
        raise NotImplementedError


class SystemClock(Clock):
    def now_utc(self) -> datetime:
        return datetime.now(tz=UTC)

    def monotonic_ns(self) -> int:
        import time

        return time.monotonic_ns()


class FakeClock(Clock):
    def __init__(self, start: datetime | None = None, monotonic_ns: int = 0) -> None:
        self._now = start or datetime(2026, 8, 16, 18, 0, tzinfo=UTC)
        self._mono = monotonic_ns

    def now_utc(self) -> datetime:
        return self._now

    def monotonic_ns(self) -> int:
        return self._mono

    def advance_ms(self, ms: int) -> None:
        from datetime import timedelta

        self._now = self._now + timedelta(milliseconds=ms)
        self._mono += ms * 1_000_000
