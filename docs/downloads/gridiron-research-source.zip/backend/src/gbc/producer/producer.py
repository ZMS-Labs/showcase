from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from uuid import uuid4

from gbc.contracts.broadcast import SpeechIntent
from gbc.contracts.enums import (
    CertaintyStyle,
    IntentType,
    Interruptibility,
    Speaker,
)
from gbc.contracts.events import PlayEvent
from gbc.memory.tendencies import TendencyRecord, narrative_for


@dataclass
class ProducerDecision:
    intent: SpeechIntent
    immediate_text: str | None = None
    use_model: bool = False


class Producer:
    def __init__(self, minimum_salience: float = 0.60) -> None:
        self.minimum_salience = minimum_salience
        self._last_topics: dict[str, datetime] = {}
        self.validation_failures: int = 0

    def decide(
        self,
        *,
        event: PlayEvent | None,
        tendency: TendencyRecord | None,
        now: datetime,
        deadline_ns: int,
        capture_lost: bool = False,
        profile_stale: bool = False,
        low_confidence: bool = False,
        new_snap: bool = False,
    ) -> ProducerDecision:
        if capture_lost or profile_stale or low_confidence:
            return self._silence(deadline_ns, 1)
        if new_snap:
            return self._silence(deadline_ns, 2)
        if event is None:
            return self._silence(deadline_ns, 11)
        salience = self._salience(event, tendency)
        if salience < self.minimum_salience:
            return self._silence(deadline_ns, 11)
        if event.touchdown or event.turnover or event.safety:
            return ProducerDecision(
                intent=SpeechIntent(
                    intent_id=f"intent_{uuid4().hex[:8]}",
                    priority=3,
                    speaker=Speaker.PLAY_BY_PLAY,
                    intent_type=IntentType.IMMEDIATE_REACTION,
                    maximum_words=8,
                    deadline_monotonic_ns=deadline_ns,
                    estimated_available_seconds=1.5,
                    interruptibility=Interruptibility.IMMEDIATE,
                    certainty_style=CertaintyStyle.CONFIRMED,
                    fallback_template_id="immediate_score",
                ),
                immediate_text=self._immediate(event),
                use_model=False,
            )
        if tendency and narrative_for(tendency):
            topic = tendency.key
            last = self._last_topics.get(topic)
            if last and (now - last).total_seconds() < 240:
                return self._silence(deadline_ns, 11)
            self._last_topics[topic] = now
            return ProducerDecision(
                intent=SpeechIntent(
                    intent_id=f"intent_{uuid4().hex[:8]}",
                    priority=8,
                    speaker=Speaker.ANALYST,
                    intent_type=IntentType.ANALYSIS,
                    maximum_words=24,
                    deadline_monotonic_ns=deadline_ns,
                    estimated_available_seconds=6.0,
                    interruptibility=Interruptibility.SENTENCE,
                    certainty_style=CertaintyStyle.CONFIRMED,
                    fallback_template_id="tendency",
                ),
                use_model=True,
            )
        return ProducerDecision(
            intent=SpeechIntent(
                intent_id=f"intent_{uuid4().hex[:8]}",
                priority=6,
                speaker=Speaker.PLAY_BY_PLAY,
                intent_type=IntentType.PLAY_BY_PLAY,
                maximum_words=18,
                deadline_monotonic_ns=deadline_ns,
                estimated_available_seconds=4.0,
                interruptibility=Interruptibility.SENTENCE,
                certainty_style=CertaintyStyle.CONFIRMED,
                fallback_template_id="play_result",
            ),
            use_model=True,
        )

    def _silence(self, deadline_ns: int, priority: int) -> ProducerDecision:
        return ProducerDecision(
            intent=SpeechIntent(
                intent_id=f"intent_{uuid4().hex[:8]}",
                priority=priority,
                speaker=None,
                intent_type=IntentType.SILENCE,
                maximum_words=0,
                deadline_monotonic_ns=deadline_ns,
                interruptibility=Interruptibility.IMMEDIATE,
                certainty_style=CertaintyStyle.NONE,
            ),
            use_model=False,
        )

    def _salience(self, event: PlayEvent, tendency: TendencyRecord | None) -> float:
        score = 0.2
        if event.touchdown or event.safety:
            score = 1.0
        elif event.turnover:
            score = 0.95
        elif event.scoring_value:
            score = 0.9
        elif event.first_down:
            score = 0.65
        elif tendency and tendency.use_count >= 3:
            score = 0.7
        elif event.yards and abs(event.yards) >= 20:
            score = 0.75
        return score

    def _immediate(self, event: PlayEvent) -> str:
        if event.touchdown:
            return "Touchdown!"
        if event.result_type.value == "INTERCEPTION":
            return "Picked off!"
        if event.turnover:
            return "Turnover!"
        if event.safety:
            return "Safety!"
        if event.penalty_state.value != "NONE":
            return "There's a flag."
        if event.result_type.value == "FIELD_GOAL_GOOD":
            return "The kick is good."
        return "Big play!"
