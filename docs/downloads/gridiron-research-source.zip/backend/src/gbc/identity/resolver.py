from __future__ import annotations

from dataclasses import dataclass, field
from uuid import uuid4

from rapidfuzz import fuzz

from gbc.contracts.enums import ConfidenceBand
from gbc.contracts.franchise import FranchisePlayer


@dataclass
class ParticipantResolution:
    participant_id: str
    resolved_player_id: str | None
    display_name: str | None
    confidence: ConfidenceBand
    candidate_list: list[str] = field(default_factory=list)
    evidence: list[str] = field(default_factory=list)


class IdentityResolver:
    def __init__(self, roster: list[FranchisePlayer]) -> None:
        self.roster = roster

    def resolve(
        self,
        *,
        visible_name: str | None,
        jersey: int | None,
        team_id: str | None,
        role: str | None = None,
    ) -> ParticipantResolution:
        pid = uuid4().hex[:12]
        if visible_name:
            matches = [
                p
                for p in self.roster
                if p.last_name.lower() == visible_name.lower()
                or p.display_name.lower() == visible_name.lower()
                or fuzz.ratio(p.display_name.lower(), visible_name.lower()) >= 90
            ]
            if team_id:
                matches = [p for p in matches if p.team_id == team_id] or matches
            if len(matches) == 1:
                player = matches[0]
                return ParticipantResolution(
                    participant_id=pid,
                    resolved_player_id=player.player_id,
                    display_name=player.display_name,
                    confidence=ConfidenceBand.HIGH,
                    candidate_list=[player.display_name],
                    evidence=["visible_name+roster"],
                )
            if matches:
                return ParticipantResolution(
                    participant_id=pid,
                    resolved_player_id=None,
                    display_name=None,
                    confidence=ConfidenceBand.LOW,
                    candidate_list=[p.display_name for p in matches],
                    evidence=["ambiguous_name"],
                )
        if jersey is not None and team_id:
            matches = [p for p in self.roster if p.team_id == team_id and p.jersey_number == jersey]
            if len(matches) == 1:
                player = matches[0]
                return ParticipantResolution(
                    participant_id=pid,
                    resolved_player_id=player.player_id,
                    display_name=player.display_name,
                    confidence=ConfidenceBand.HIGH,
                    candidate_list=[player.display_name],
                    evidence=["jersey+team"],
                )
            return ParticipantResolution(
                participant_id=pid,
                resolved_player_id=None,
                display_name=None,
                confidence=ConfidenceBand.UNKNOWN,
                candidate_list=[p.display_name for p in matches],
                evidence=["non_unique_jersey"],
            )
        del role  # depth chart may narrow, never assert
        return ParticipantResolution(
            participant_id=pid,
            resolved_player_id=None,
            display_name=None,
            confidence=ConfidenceBand.UNKNOWN,
            evidence=["unresolved"],
        )
