from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class ScheduledUtterance:
    utterance_id: str
    speaker: str
    text: str
    pcm: np.ndarray
    cancelled: bool = False
    started: bool = False
    finished: bool = False


class AudioScheduler:
    def __init__(self, fade_ms: int = 75, sample_rate: int = 24000) -> None:
        self.fade_ms = fade_ms
        self.sample_rate = sample_rate
        self.queue: list[ScheduledUtterance] = []
        self.muted = False
        self.current: ScheduledUtterance | None = None
        self.captions: list[str] = []

    def enqueue(self, item: ScheduledUtterance) -> None:
        if self.muted:
            self.captions.append(item.text)
            return
        if self.current and not self.current.finished:
            return
        self.queue.append(item)
        self.captions.append(item.text)

    def cancel(self, reason: str) -> None:
        del reason
        if self.current and not self.current.finished:
            self.current.cancelled = True
        for item in self.queue:
            item.cancelled = True
        self.queue = [item for item in self.queue if not item.cancelled]

    def panic_mute(self) -> None:
        self.muted = True
        self.cancel("panic_mute")

    def unmute(self) -> None:
        self.muted = False

    def pop_playable(self) -> ScheduledUtterance | None:
        while self.queue:
            item = self.queue.pop(0)
            if item.cancelled:
                continue
            self.current = item
            item.started = True
            return item
        return None


class MockTTSProvider:
    name = "mock"

    def health(self) -> dict[str, str]:
        return {"status": "ok", "provider": self.name}

    def warmup(self, voice: str) -> None:
        del voice

    async def synthesize(self, text: str, voice: str, request_id: str) -> np.ndarray:
        del voice, request_id
        samples = max(240, len(text) * 80)
        return np.zeros(samples, dtype=np.float32)

    def cancel(self, request_id: str) -> None:
        del request_id


PRONUNCIATIONS = {
    "CHI": "Chicago",
    "GB": "Green Bay",
    "TD": "touchdown",
}


def normalize_for_speech(text: str, overrides: dict[str, str] | None = None) -> str:
    mapping = dict(PRONUNCIATIONS)
    if overrides:
        mapping.update(overrides)
    out = text
    for src, dest in mapping.items():
        out = out.replace(src, dest)
    return out
