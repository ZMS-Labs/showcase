from __future__ import annotations

import argparse
import webbrowser
from pathlib import Path

import uvicorn

from gbc.application import create_runtime
from gbc.config.settings import load_settings
from gbc.evaluation.benchmark import evaluate_fixture, write_reports
from gbc.replay.runner import run_fixture


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="gbc")
    sub = parser.add_subparsers(dest="cmd", required=True)
    serve = sub.add_parser("serve")
    serve.add_argument("--env", default="development")
    replay = sub.add_parser("replay")
    replay.add_argument("--fixture", required=True)
    bench = sub.add_parser("benchmark")
    bench.add_argument("--fixture", required=True)
    bench.add_argument("--out", default="reports")
    args = parser.parse_args(argv)

    if args.cmd == "serve":
        settings = load_settings(environment=args.env)
        runtime = create_runtime(settings)
        from gbc.api.app import create_app

        app = create_app(runtime)
        if settings.app.open_browser:
            webbrowser.open(f"http://{settings.app.bind_host}:{settings.app.bind_port}")
        uvicorn.run(app, host=settings.app.bind_host, port=settings.app.bind_port, log_level="info")
        return 0
    if args.cmd == "replay":
        result = run_fixture(Path(args.fixture))
        print(result.deterministic_hash)
        print(f"events={result.observed_events} utterances={len(result.utterances)}")
        return 0
    if args.cmd == "benchmark":
        fixture = Path(args.fixture)
        report, result = evaluate_fixture(fixture)
        json_path, html_path = write_reports(report, Path(args.out))
        print(json_path)
        print(html_path)
        print(result.deterministic_hash)
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
