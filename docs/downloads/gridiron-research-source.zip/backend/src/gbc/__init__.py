"""Gridiron Broadcast Companion."""

__version__ = "0.1.0"
