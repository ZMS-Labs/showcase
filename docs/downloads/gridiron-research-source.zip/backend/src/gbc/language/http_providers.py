from __future__ import annotations

import json

import httpx

from gbc.contracts.broadcast import CommentaryPlan, FactPacket


class OpenAICompatibleCommentaryProvider:
    name = "openai_compatible"

    def __init__(self, base_url: str, model: str, api_key: str = "", timeout_ms: int = 1800) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.timeout_ms = timeout_ms
        self._cancelled: set[str] = set()

    def health(self) -> dict[str, str]:
        return {"status": "configured" if self.base_url else "missing", "provider": self.name}

    def warmup(self) -> None:
        return None

    def cancel(self, request_id: str) -> None:
        self._cancelled.add(request_id)

    def generate(self, packet: FactPacket, deadline_ns: int | None = None) -> CommentaryPlan:
        del deadline_ns
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        body = {
            "model": self.model,
            "temperature": 0.1,
            "response_format": {"type": "json_object"},
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "You are a broadcast writer. Use only supplied facts. "
                        "Do not calculate. Do not invent names or numbers. "
                        "Do not imitate a named real announcer. Return strict JSON."
                    ),
                },
                {"role": "user", "content": packet.model_dump_json()},
            ],
        }
        with httpx.Client(timeout=self.timeout_ms / 1000) as client:
            response = client.post(f"{self.base_url}/chat/completions", headers=headers, json=body)
            response.raise_for_status()
            content = response.json()["choices"][0]["message"]["content"]
        return CommentaryPlan.model_validate(json.loads(content))


class OllamaCommentaryProvider(OpenAICompatibleCommentaryProvider):
    name = "ollama"
