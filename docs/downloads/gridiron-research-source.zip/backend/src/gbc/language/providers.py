from __future__ import annotations

from gbc.contracts.broadcast import CommentaryPlan, FactPacket
from gbc.contracts.enums import CertaintyStyle, CommentaryDecision, IntentType


class DeterministicTemplateProvider:
    name = "deterministic"

    def health(self) -> dict[str, str]:
        return {"status": "ok", "provider": self.name}

    def warmup(self) -> None:
        return None

    def generate(self, packet: FactPacket, deadline_ns: int | None = None) -> CommentaryPlan:
        del deadline_ns
        intent = packet.intent
        if intent.intent_type == IntentType.SILENCE or not packet.facts:
            return CommentaryPlan(
                decision=CommentaryDecision.WAIT,
                speaker=None,
                intent_id=intent.intent_id,
                certainty_style=CertaintyStyle.NONE,
            )
        text = packet.facts[0].textual_form
        return CommentaryPlan(
            decision=CommentaryDecision.SPEAK,
            speaker=intent.speaker,
            intent_id=intent.intent_id,
            text=text,
            fact_ids=[packet.facts[0].fact_id],
            topic_ids=list(intent.topic_ids),
            certainty_style=intent.certainty_style,
            estimated_seconds=min(6.0, max(1.0, len(text.split()) * 0.35)),
            interruptibility=intent.interruptibility,
        )

    def cancel(self, request_id: str) -> None:
        del request_id


class MockCommentaryProvider(DeterministicTemplateProvider):
    name = "mock"
