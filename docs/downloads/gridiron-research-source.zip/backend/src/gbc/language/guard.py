from __future__ import annotations

import re
from dataclasses import dataclass

from gbc.contracts.broadcast import CommentaryPlan, FactPacket
from gbc.contracts.enums import CommentaryDecision, ConfidenceBand, IntentType
from gbc.perception.parsers import extract_names, parse_number_words

BANNED = [
    "madden",
    "ea sports",
    "fact_id",
    "schema",
    "language model",
    "as an ai",
    "confidence band",
]

CALLBACK_WORDS = ["again", "same", "third straight", "fourth straight", "hat trick"]


@dataclass
class GuardResult:
    accepted: bool
    errors: list[str]
    repaired: bool = False


class ClaimGuard:
    def validate(self, plan: CommentaryPlan, packet: FactPacket) -> GuardResult:
        errors: list[str] = []
        if plan.intent_id != packet.intent.intent_id:
            errors.append("intent_id mismatch")
        if plan.decision == CommentaryDecision.WAIT:
            if plan.text.strip():
                errors.append("WAIT must have empty text")
            return GuardResult(accepted=not errors, errors=errors)
        if packet.intent.intent_type == IntentType.SILENCE:
            errors.append("silence intent cannot speak")
        if plan.speaker != packet.intent.speaker:
            errors.append("speaker mismatch")
        fact_map = {fact.fact_id: fact for fact in packet.facts}
        for fact_id in plan.fact_ids:
            if fact_id not in fact_map:
                errors.append(f"unknown fact {fact_id}")
            elif not fact_map[fact_id].speakable:
                errors.append(f"unspeakable fact {fact_id}")
        words = plan.text.split()
        if len(words) > packet.intent.maximum_words:
            errors.append("exceeds maximum_words")
        lowered = plan.text.lower()
        for banned in BANNED:
            if banned in lowered:
                errors.append(f"banned phrase: {banned}")
        for recent in packet.recently_said:
            if recent and recent.lower() in lowered:
                errors.append("repeats recent utterance")
        allowed_names = {name.lower() for name in packet.allowed_names}
        for name in extract_names(plan.text):
            if name.lower() not in allowed_names and name.lower() not in {
                "touchdown",
                "interception",
                "field",
                "goal",
                "penalty",
                "flag",
                "kick",
                "they",
            }:
                # Single common nouns from extract_names are ignored if not proper roster names.
                if name[0].isupper() and name.lower() not in {
                    "that",
                    "they",
                    "this",
                    "there",
                    "after",
                    "chicago",
                    "offense",
                    "defense",
                }:
                    if name.lower() not in allowed_names:
                        errors.append(f"unsupported name {name}")
        spoken_numbers = set(parse_number_words(plan.text))
        spoken_numbers.update(int(n) for n in re.findall(r"\b\d+\b", plan.text))
        allowed_numbers = set(packet.allowed_numbers)
        for number in spoken_numbers:
            if number not in allowed_numbers:
                errors.append(f"unsupported number {number}")
        same_ok = any(fact.allows_same_play_language for fact in packet.facts)
        if any(word in lowered for word in CALLBACK_WORDS) and not same_ok:
            if "same" in lowered or "again" in lowered or "straight" in lowered:
                errors.append("callback language not authorized")
        if any(word in lowered for word in ["best", "greatest", "record"]) and not any(
            fact.allows_record_claim or fact.allows_superlative for fact in packet.facts
        ):
            errors.append("superlative or record claim not authorized")
        low_facts = [
            f
            for f in packet.facts
            if f.fact_id in plan.fact_ids
            and f.confidence
            in {
                ConfidenceBand.LOW,
                ConfidenceBand.UNKNOWN,
            }
        ]
        if low_facts:
            errors.append("cannot speak LOW or UNKNOWN facts")
        return GuardResult(accepted=not errors, errors=errors)
