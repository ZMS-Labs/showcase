from datetime import UTC, datetime

from gbc.contracts.broadcast import CommentaryPlan, SpeechIntent
from gbc.contracts.enums import (
    CertaintyStyle,
    CommentaryDecision,
    ConfidenceBand,
    IntentType,
    Interruptibility,
    PlayMatchLevel,
    Speaker,
)
from gbc.contracts.events import PlayEvent, PlaySignature
from gbc.facts.compiler import FactCompiler
from gbc.language.guard import ClaimGuard
from gbc.memory.stats import GameStatistics
from gbc.memory.tendencies import TendencyEngine, TendencyRecord
from gbc.producer.producer import Producer


def test_same_play_requires_exact_verified() -> None:
    engine = TendencyEngine()
    now = datetime.now(tz=UTC)
    sig = PlaySignature(
        play_name="Mesh Spot",
        play_family="mesh",
        confidence=ConfidenceBand.CONFIRMED,
    )
    event = PlayEvent(
        event_id="e1",
        session_id="s",
        status="CONFIRMED",
        started_at=now,
        play_signature=sig,
        yards=12,
        first_down=True,
    )
    engine.observe(event)
    rec = engine.observe(event)
    assert rec is not None
    assert rec.match_level == PlayMatchLevel.EXACT_VERIFIED_PLAY


def test_claim_guard_rejects_hallucinated_name_and_number() -> None:
    now = datetime.now(tz=UTC)
    intent = SpeechIntent(
        intent_id="intent_1",
        priority=6,
        speaker=Speaker.ANALYST,
        intent_type=IntentType.ANALYSIS,
        maximum_words=24,
        interruptibility=Interruptibility.SENTENCE,
        certainty_style=CertaintyStyle.CONFIRMED,
    )
    packet = FactCompiler().compile(
        intent,
        session_id="s",
        now=now,
        event=None,
        stats=GameStatistics(),
        tendency=TendencyRecord(key="k", match_level=PlayMatchLevel.EXACT_VERIFIED_PLAY, use_count=3),
        recently_said=[],
    )
    plan = CommentaryPlan(
        decision=CommentaryDecision.SPEAK,
        speaker=Speaker.ANALYST,
        intent_id="intent_1",
        text="Mahomes has 47 catches and they ran the same play again.",
        fact_ids=["missing"],
        certainty_style=CertaintyStyle.CONFIRMED,
    )
    result = ClaimGuard().validate(plan, packet)
    assert result.accepted is False
    assert any("name" in e or "number" in e or "fact" in e or "callback" in e for e in result.errors)


def test_producer_can_choose_silence() -> None:
    producer = Producer(minimum_salience=0.99)
    now = datetime.now(tz=UTC)
    event = PlayEvent(
        event_id="e",
        session_id="s",
        status="CONFIRMED",
        started_at=now,
        yards=1,
    )
    decision = producer.decide(event=event, tendency=None, now=now, deadline_ns=0)
    assert decision.intent.intent_type.value == "SILENCE"
