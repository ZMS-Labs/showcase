import pytest
from pydantic import ValidationError

from gbc.config.settings import load_settings


def test_default_config_loads() -> None:
    settings = load_settings(environment="development")
    assert settings.app.bind_host == "127.0.0.1"
    assert settings.franchise.read_only is True
    assert settings.providers.commentary.type == "deterministic"


def test_read_only_cannot_be_disabled() -> None:
    from gbc.config.settings import FranchiseSettings

    with pytest.raises(ValidationError):
        FranchiseSettings(read_only=False)
