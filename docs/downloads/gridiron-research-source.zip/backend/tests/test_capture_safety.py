import pytest

from gbc.capture.dxcam_source import DxcamCaptureSource
from gbc.capture.windows import WindowsCaptureSource
from gbc.contracts.capture import CaptureOptions, CaptureTarget


def test_monitor_capture_requires_explicit_flag() -> None:
    source = DxcamCaptureSource()
    target = CaptureTarget(target_id="monitor-0", title="monitor", kind="monitor")
    with pytest.raises(PermissionError):
        source.start(target, CaptureOptions(allow_monitor=False))


def test_windows_source_refuses_monitor_without_flag() -> None:
    source = WindowsCaptureSource()
    target = CaptureTarget(target_id="1", title="monitor", kind="monitor")
    with pytest.raises(PermissionError):
        source.start(target, CaptureOptions(allow_monitor=False))


def test_invalid_hwnd_grab_returns_none() -> None:
    from gbc.capture.win32_grab import grab_window_bgr

    assert grab_window_bgr(0) is None
