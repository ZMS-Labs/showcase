from pathlib import Path

PROHIBITED = (".save(", "packFile(", "saveOnChange")


def test_bridge_source_has_no_write_api() -> None:
    root = Path(__file__).resolve().parents[2] / "franchise-bridge" / "src"
    assert root.exists()
    for path in root.rglob("*.ts"):
        text = path.read_text(encoding="utf-8")
        for token in PROHIBITED:
            assert token not in text, f"{path} contains prohibited {token}"
