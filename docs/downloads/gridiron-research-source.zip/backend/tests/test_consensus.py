from datetime import UTC, datetime

from gbc.perception.consensus import TemporalReconciler
from gbc.perception.parsers import (
    parse_clock_ms,
    parse_down,
    parse_number_words,
    parse_quarter,
    parse_score,
)


def test_parsers() -> None:
    assert parse_score("14") == 14
    assert parse_quarter("Q2") == 2
    assert parse_clock_ms("5:42") == 342000
    assert parse_down("3rd") == 3
    assert 3 in parse_number_words("third")
    assert 14 in parse_number_words("fourteen")


def test_single_frame_is_not_confirmed() -> None:
    rec = TemporalReconciler(window=5, min_agree=3)
    rec.ingest("HOME_SCORE", "7")
    value, band = rec.consensus("HOME_SCORE")
    assert value == "7"
    assert band.value in {"LOW", "MEDIUM"}
    assert band.value != "CONFIRMED"


def test_scores_do_not_decrease_from_flicker() -> None:
    rec = TemporalReconciler(window=5, min_agree=3)
    now = datetime.now(tz=UTC)
    for _ in range(4):
        rec.ingest("HOME_SCORE", "14")
    snap = rec.snapshot_fields(now)
    assert snap["home_score"].value == 14
    rec.ingest("HOME_SCORE", "1")
    rec.ingest("HOME_SCORE", "1")
    snap = rec.snapshot_fields(now)
    assert snap["home_score"].value == 14
