import json
import shutil
from pathlib import Path

import pytest

from gbc.evaluation.benchmark import evaluate_fixture

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "synthetic" / "drive-scoring-void"


def test_stable_replay_does_not_claim_unmeasured_accuracy() -> None:
    report, result = evaluate_fixture(FIXTURE)
    assert report.labels["synthetic_replay"] == "VERIFIED"
    assert report.events["label"] == "VERIFIED"
    assert report.perception["field_accuracy"] is None
    assert report.perception["unknown_state_rate"] is None
    assert report.perception["label"] == "NOT_MEASURED"
    assert report.perception["reason"]
    assert result.unsupported_names is None
    assert result.unsupported_numbers is None
    assert report.commentary["unsupported_name_count"] is None
    assert report.commentary["unsupported_number_count"] is None
    assert report.commentary["label"] == "NOT_MEASURED"
    assert report.commentary["reason"]
    assert report.commentary["utterance_count"] == 1


@pytest.mark.parametrize("mismatch", ["prefix_only", "empty_oracle", "wrong_count"])
def test_event_verification_requires_complete_oracle_and_count(tmp_path: Path, mismatch: str) -> None:
    fixture = tmp_path / "fixture"
    shutil.copytree(FIXTURE, fixture)
    oracle = fixture / "oracle" / "events.jsonl"
    if mismatch == "prefix_only":
        oracle.write_text('{"event_id": "p1", "expect": "CONFIRMED"}\n', encoding="utf-8")
    elif mismatch == "empty_oracle":
        oracle.write_text("", encoding="utf-8")
    else:
        manifest_path = fixture / "manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        manifest["expected_event_count"] = 4
        manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    report, result = evaluate_fixture(fixture)
    assert result.observed_events == 3
    assert report.labels["synthetic_replay"] == "VERIFIED"
    assert report.events["label"] != "VERIFIED"
    if mismatch == "empty_oracle":
        assert report.events["label"] == "NOT_MEASURED"
