from datetime import UTC, datetime

from gbc.contracts.enums import EventStatus
from gbc.contracts.events import PlayEvent
from gbc.memory.stats import StatisticsEngine


def test_conftest_placeholder() -> None:
    assert EventStatus.CONFIRMED.value == "CONFIRMED"
    engine = StatisticsEngine()
    event = PlayEvent(
        event_id="x",
        session_id="s",
        status=EventStatus.CONFIRMED,
        started_at=datetime.now(tz=UTC),
        offense_team="CHI",
        scoring_value=3,
    )
    engine.apply(event)
    engine.apply(event)
    assert engine.current.team_points["CHI"] == 3
