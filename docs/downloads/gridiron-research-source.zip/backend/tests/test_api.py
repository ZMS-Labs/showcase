from fastapi.testclient import TestClient

from gbc.api.app import create_app
from gbc.application import create_runtime
from gbc.config.settings import load_settings


def test_health_and_replay_api() -> None:
    settings = load_settings(environment="development")
    settings.app.open_browser = False
    runtime = create_runtime(settings)
    app = create_app(runtime)
    client = TestClient(app)
    health = client.get("/api/v1/health")
    assert health.status_code == 200
    assert health.json()["status"] == "ok"
    windows = client.get("/api/v1/windows")
    assert windows.status_code == 200
    assert any(w["target_id"] == "synthetic" for w in windows.json())
    ack = client.post("/api/v1/safety/ack", json={"acknowledged": True})
    assert ack.json()["ok"] is True
    start = client.post("/api/v1/capture/start", json={"target_id": "synthetic"})
    assert start.status_code == 200
    preview = client.get("/api/v1/capture/preview")
    assert preview.status_code == 200
    assert preview.headers["content-type"] == "image/png"
    replay = client.post("/api/v1/replay/run", json={"fixture": "drive-scoring-void"})
    assert replay.status_code == 200
    body = replay.json()
    assert body["observed_events"] >= 3
    mute = client.post("/api/v1/audio/mute")
    assert mute.json()["muted"] is True
