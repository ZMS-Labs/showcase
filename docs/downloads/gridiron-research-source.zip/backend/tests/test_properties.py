from datetime import UTC, datetime

from hypothesis import given, settings
from hypothesis import strategies as st

from gbc.contracts.enums import EventStatus, PlayType
from gbc.contracts.events import PlayEvent
from gbc.memory.stats import StatisticsEngine


@given(yards=st.integers(min_value=-20, max_value=80), scoring=st.sampled_from([0, 3, 6, 7, 8]))
@settings(max_examples=40)
def test_apply_reverse_restores_stats(yards: int, scoring: int) -> None:
    engine = StatisticsEngine()
    before = engine.current.copy()
    event = PlayEvent(
        event_id="e",
        session_id="s",
        status=EventStatus.CONFIRMED,
        started_at=datetime.now(tz=UTC),
        offense_team="CHI",
        play_type=PlayType.RUN,
        yards=yards,
        scoring_value=scoring,
        first_down=yards >= 10,
    )
    engine.apply(event)
    engine.reverse(event)
    assert engine.current.team_points.get("CHI", 0) == before.team_points.get("CHI", 0)
    assert engine.current.rushing_attempts == before.rushing_attempts
    assert engine.current.rushing_yards == before.rushing_yards


def test_voided_event_zero_stat_effect() -> None:
    engine = StatisticsEngine()
    event = PlayEvent(
        event_id="v",
        session_id="s",
        status=EventStatus.VOIDED,
        started_at=datetime.now(tz=UTC),
        offense_team="CHI",
        play_type=PlayType.PASS,
        scoring_value=6,
        touchdown=True,
        yards=40,
    )
    engine.apply(event)
    assert engine.current.team_points.get("CHI", 0) == 0
    assert engine.current.pass_attempts == 0
