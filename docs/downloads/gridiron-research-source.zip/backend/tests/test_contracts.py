from datetime import UTC, datetime

from gbc.contracts.enums import ConfidenceBand
from gbc.contracts.provenance import FieldPosition, distance_to_goal, yards_gained


def test_own_side_distance_to_goal() -> None:
    assert distance_to_goal("CHI", "CHI", 20) == 80


def test_opponent_side_distance_to_goal() -> None:
    assert distance_to_goal("CHI", "GB", 20) == 20


def test_midfield() -> None:
    pos = FieldPosition.midfield()
    assert pos.distance_to_goal_for_possession == 50
    assert yards_gained(pos, pos, possession_changed=False, touchdown=False, touchback=False) == 0


def test_touchdown_yards_use_pre_distance() -> None:
    pre = FieldPosition(team_whose_side="GB", yard_number=8, distance_to_goal_for_possession=8)
    post = FieldPosition(team_whose_side="GB", yard_number=1, distance_to_goal_for_possession=0)
    assert yards_gained(pre, post, possession_changed=False, touchdown=True, touchback=False) == 8


def test_low_confidence_not_unqualified() -> None:
    from gbc.contracts.enums import Authority, EpistemicClass
    from gbc.contracts.provenance import Provenanced

    item = Provenanced[int](
        value=7,
        source="ocr",
        timestamp=datetime.now(tz=UTC),
        confidence=ConfidenceBand.LOW,
        authority=Authority.OCR_CONSENSUS,
        epistemic_class=EpistemicClass.PUBLIC_OBSERVATION,
        speakable=False,
    )
    assert item.is_unqualified_fact() is False
