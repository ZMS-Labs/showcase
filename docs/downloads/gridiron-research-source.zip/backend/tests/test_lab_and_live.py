from gbc.api.app import create_app
from gbc.application import create_runtime
from gbc.config.settings import load_settings


def _client():
    settings = load_settings(environment="development")
    settings.app.open_browser = False
    runtime = create_runtime(settings)
    return runtime, create_app(runtime)


def test_lab_ocr_consensus_and_live_state() -> None:
    from fastapi.testclient import TestClient

    _runtime, app = _client()
    client = TestClient(app)
    types = client.get("/api/v1/lab/roi-types")
    assert types.status_code == 200
    assert "HOME_SCORE" in types.json()
    start = client.post("/api/v1/capture/start", json={"target_id": "synthetic"})
    assert start.status_code == 200
    payload = {
        "roi_id": "home_score",
        "roi_type": "HOME_SCORE",
        "x": 0.2,
        "y": 0.03,
        "w": 0.05,
        "h": 0.08,
        "variant": "default",
    }
    last = None
    for _ in range(3):
        last = client.post("/api/v1/lab/ocr-test", json=payload)
        assert last.status_code == 200
    body = last.json() if last is not None else {}
    assert body["observation"]["normalized_value"] == "14"
    assert "default" in body["variants"]
    assert body["observation"]["consensus_confidence"] in {"HIGH", "CONFIRMED", "MEDIUM"}
    live = client.get("/api/v1/live/state")
    assert live.status_code == 200
    state = live.json()
    assert state["phase"] == "UNKNOWN"
    assert "degraded" in state
    freeze = client.post("/api/v1/lab/freeze", json={"frozen": True})
    assert freeze.json()["frozen"] is True
    profile = client.post(
        "/api/v1/profiles",
        json={
            "profile": {
                "profile_id": "operator-lab",
                "revision": 1,
                "capture_width": 1280,
                "capture_height": 720,
                "created_at": "2026-08-16T00:00:00Z",
                "roi_definitions": [
                    {
                        "roi_id": "home_score",
                        "roi_type": "HOME_SCORE",
                        "x": 0.2,
                        "y": 0.03,
                        "w": 0.05,
                        "h": 0.08,
                    }
                ],
            }
        },
    )
    assert profile.status_code == 200
    assert profile.json()["revision"] >= 1


def test_franchise_snapshot_invokes_bridge(tmp_path) -> None:  # type: ignore[no-untyped-def]
    from fastapi.testclient import TestClient

    source = tmp_path / "demo.franchise"
    source.write_bytes(b"not-a-real-save")
    _runtime, app = _client()
    client = TestClient(app)
    response = client.post("/api/v1/franchise/snapshot", json={"path": str(source)})
    assert response.status_code == 200
    body = response.json()
    assert body["unchanged"] is True
    caps = client.get("/api/v1/franchise/capabilities")
    assert caps.status_code == 200
    report = caps.json()
    assert "parser_version" in report
    assert report["degraded_features"]
