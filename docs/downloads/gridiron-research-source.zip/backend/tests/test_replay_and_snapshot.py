from pathlib import Path

from gbc.capture.queue import BoundedLatestQueue
from gbc.evaluation.benchmark import evaluate_fixture
from gbc.franchise.snapshot import create_stable_snapshot, sha256_file
from gbc.persistence.models import make_engine
from gbc.replay.runner import run_fixture


def test_bounded_queue_drops_oldest() -> None:
    q: BoundedLatestQueue[int] = BoundedLatestQueue(2)
    q.put(1)
    q.put(2)
    q.put(3)
    assert q.stats.dropped == 1
    assert q.get_latest() == 3
    assert len(q) == 0


def test_snapshot_does_not_modify_source(tmp_path: Path) -> None:
    source = tmp_path / "team.franchise"
    source.write_bytes(b"franchise-bytes-not-ea")
    before = sha256_file(source)
    mtime = source.stat().st_mtime_ns
    meta = create_stable_snapshot(
        source,
        tmp_path / "snap",
        stability_seconds=0,
        retries=1,
        poll_seconds=0,
    )
    assert sha256_file(source) == before
    assert source.stat().st_mtime_ns == mtime
    assert meta.unchanged is True
    assert Path(meta.snapshot_path).exists()


def test_sqlite_wal(tmp_path: Path) -> None:
    engine = make_engine(str(tmp_path / "t.sqlite"))
    with engine.connect() as conn:
        mode = conn.exec_driver_sql("PRAGMA journal_mode").scalar_one()
    assert str(mode).lower() == "wal"


def test_synthetic_replay_deterministic() -> None:
    fixture = Path(__file__).resolve().parents[2] / "fixtures" / "synthetic" / "drive-scoring-void"
    a = run_fixture(fixture)
    b = run_fixture(fixture)
    assert a.deterministic_hash == b.deterministic_hash
    assert "VOIDED" in a.statuses
    assert "CONFIRMED" in a.statuses
    assert a.duplicate_commitments == 0
    report, _ = evaluate_fixture(fixture)
    assert report.labels["synthetic_replay"] == "VERIFIED"
    assert report.labels["madden_live"] == "UNVERIFIED"
