from datetime import UTC, datetime

from gbc.contracts.enums import EventStatus, PlayType
from gbc.contracts.provenance import FieldPosition
from gbc.events.reconciler import EventReconciler, ScoreboardView
from gbc.memory.stats import StatisticsEngine


def _view(**kwargs: object) -> ScoreboardView:
    base = dict(
        home_team="CHI",
        away_team="GB",
        home_score=0,
        away_score=0,
        quarter=1,
        game_clock_ms=900000,
        down=1,
        distance=10,
        possession_team="CHI",
        ball_spot=FieldPosition(
            team_whose_side="CHI",
            yard_number=25,
            distance_to_goal_for_possession=75,
        ),
    )
    base.update(kwargs)
    return ScoreboardView(**base)  # type: ignore[arg-type]


def test_duplicate_observation_does_not_duplicate_event() -> None:
    rec = EventReconciler("s")
    now = datetime.now(tz=UTC)
    rec.handle(_view(snap=True), now, observation_key="p1", play_type=PlayType.RUN)
    rec.handle(_view(snap=True), now, observation_key="p1", play_type=PlayType.RUN)
    assert len(rec._ids) == 1


def test_penalty_voids_without_stat_effect() -> None:
    rec = EventReconciler("s")
    stats = StatisticsEngine()
    now = datetime.now(tz=UTC)
    rec.handle(_view(snap=True), now, observation_key="p2", play_type=PlayType.PASS)
    rec.handle(_view(penalty_visible=True, game_clock_ms=890000), now, observation_key="p2")
    event = rec.handle(_view(postplay=True, game_clock_ms=890000), now, observation_key="p2")
    assert event is not None
    assert event.status == EventStatus.VOIDED
    stats.apply(event)
    assert stats.current.team_points.get("CHI", 0) == 0
    assert stats.current.pass_attempts == 0


def test_touchdown_then_correction_reverses() -> None:
    rec = EventReconciler("s")
    stats = StatisticsEngine()
    now = datetime.now(tz=UTC)
    rec.handle(_view(snap=True), now, observation_key="p3", play_type=PlayType.PASS)
    event = rec.handle(_view(postplay=True, home_score=6, game_clock_ms=880000), now)
    assert event is not None
    stats.apply(event)
    assert stats.current.team_points["CHI"] == 6
    corrected = rec.correct("p3", now, scoring_value=0, touchdown=False)
    stats.replace(event, corrected)
    assert stats.current.team_points["CHI"] == 0
