import numpy as np

from gbc.contracts.franchise import FranchisePlayer
from gbc.identity.resolver import IdentityResolver
from gbc.speech.scheduler import AudioScheduler, ScheduledUtterance, normalize_for_speech


def test_identity_not_guessed_when_ambiguous() -> None:
    roster = [
        FranchisePlayer(
            player_id="1",
            source_ref="t:0",
            first_name="Jon",
            last_name="Smith",
            display_name="Jon Smith",
            team_id="CHI",
            jersey_number=11,
        ),
        FranchisePlayer(
            player_id="2",
            source_ref="t:1",
            first_name="Jay",
            last_name="Smith",
            display_name="Jay Smith",
            team_id="CHI",
            jersey_number=12,
        ),
    ]
    resolved = IdentityResolver(roster).resolve(visible_name="Smith", jersey=None, team_id="CHI")
    assert resolved.resolved_player_id is None
    assert resolved.display_name is None
    assert len(resolved.candidate_list) == 2


def test_audio_cancel_does_not_replay() -> None:
    sched = AudioScheduler()
    item = ScheduledUtterance(
        utterance_id="u1",
        speaker="PLAY_BY_PLAY",
        text="Touchdown!",
        pcm=np.zeros(10, dtype=np.float32),
    )
    sched.enqueue(item)
    sched.cancel("new_snap")
    assert sched.pop_playable() is None


def test_pronunciation_expands_abbrev() -> None:
    assert "Chicago" in normalize_for_speech("CHI scores")
