from datetime import UTC, datetime

from gbc.clocks import FakeClock


def test_fake_clock_advances() -> None:
    clock = FakeClock(datetime(2026, 8, 16, tzinfo=UTC), monotonic_ns=1000)
    clock.advance_ms(250)
    assert clock.monotonic_ns() == 1000 + 250_000_000
    assert clock.now_utc().microsecond == 250000
