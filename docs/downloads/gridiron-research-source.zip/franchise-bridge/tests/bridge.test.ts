import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { parseSnapshot } from "../src/parser.ts";
import { emptyReport } from "../src/capability-report.ts";

describe("franchise bridge", () => {
  it("returns a degraded capability report for non-franchise bytes", async () => {
    const dir = mkdtempSync(join(tmpdir(), "gbc-"));
    const snapshot = join(dir, "copy.franchise-snapshot");
    writeFileSync(snapshot, "not-a-franchise-file");
    const parsed = await parseSnapshot(snapshot);
    expect(parsed.capability.parser_version).toContain("madden-franchise");
    expect(parsed.capability.degraded_features.length).toBeGreaterThan(0);
    expect(parsed.exportPayload.snapshot_version).toBe("gbc.franchise.v1");
  });

  it("empty report lists requested tables as missing", () => {
    const report = emptyReport("abc", "missing");
    expect(
      report.tables.some((t) => t.name === "Player" && t.found === false),
    ).toBe(true);
  });
});
