import { REQUESTED_TABLES } from "./field-mappings.ts";

export type CapabilityTable = {
  name: string;
  unique_id: number | null;
  found: boolean;
  record_count: number;
  requested_fields_found: string[];
  requested_fields_missing: string[];
};

export type CapabilityReport = {
  detected_game_year: number | null;
  parser_version: string;
  schema_version: string | null;
  snapshot_hash: string;
  tables: CapabilityTable[];
  warnings: string[];
  degraded_features: string[];
};

export function emptyReport(
  snapshotHash: string,
  warning: string,
): CapabilityReport {
  return {
    detected_game_year: null,
    parser_version: "madden-franchise/4.3.6",
    schema_version: null,
    snapshot_hash: snapshotHash,
    tables: REQUESTED_TABLES.map((table) => ({
      name: table.name,
      unique_id: null,
      found: false,
      record_count: 0,
      requested_fields_found: [],
      requested_fields_missing: [...table.fields],
    })),
    warnings: [warning],
    degraded_features: [
      "season_context",
      "roster",
      "schedule",
      "standings",
      "injuries",
    ],
  };
}
