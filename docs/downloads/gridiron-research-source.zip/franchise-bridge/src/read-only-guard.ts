import { chmodSync, statSync } from "node:fs";

export function assertReadOnlySnapshot(inputPath: string): void {
  const info = statSync(inputPath);
  if (!info.isFile()) {
    throw new Error("snapshot path is not a file");
  }
  try {
    chmodSync(inputPath, 0o444);
  } catch {
    // Windows may ignore chmod; Python already marked the copy read-only.
  }
}

export function assertNoSourcePath(
  inputPath: string,
  originalHint: string | undefined,
): void {
  if (originalHint && inputPath === originalHint) {
    throw new Error("refusing to parse the original Franchise save path");
  }
}
