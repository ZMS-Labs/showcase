export const REQUESTED_TABLES = [
  {
    name: "Player",
    fields: ["FirstName", "LastName", "Position", "JerseyNum", "TeamIndex"],
  },
  { name: "Team", fields: ["DisplayName", "ShortName", "NickName"] },
  { name: "SeasonInfo", fields: ["SeasonYear", "WeekIndex"] },
  {
    name: "SeasonGame",
    fields: ["HomeTeam", "AwayTeam", "HomeScore", "AwayScore"],
  },
  { name: "Standings", fields: ["TeamIndex", "Wins", "Losses"] },
  { name: "Injury", fields: ["Player", "InjuryType"] },
  { name: "DepthChart", fields: ["TeamIndex", "Position"] },
] as const;
