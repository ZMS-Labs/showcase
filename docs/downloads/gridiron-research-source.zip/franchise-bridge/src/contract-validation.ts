import { Ajv } from "ajv";

export function validateExport(schema: object, payload: unknown): void {
  const ajv = new Ajv({ allErrors: true, strict: false });
  const validate = ajv.compile(schema);
  if (!validate(payload)) {
    throw new Error(
      `contract validation failed: ${ajv.errorsText(validate.errors)}`,
    );
  }
}
