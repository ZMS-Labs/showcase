import { writeFileSync } from "node:fs";
import { parseSnapshot } from "./parser.ts";
import {
  assertNoSourcePath,
  assertReadOnlySnapshot,
} from "./read-only-guard.ts";

function arg(flag: string): string | undefined {
  const index = process.argv.indexOf(flag);
  if (index === -1) return undefined;
  return process.argv[index + 1];
}

async function main(): Promise<void> {
  const command = process.argv[2];
  const input = arg("--input");
  if (!command || !input) {
    throw new Error(
      "usage: capabilities|export|inspect-table|validate --input <snapshot>",
    );
  }
  if (["write", "mutate", "pack"].includes(command)) {
    throw new Error("write commands are not available");
  }
  assertReadOnlySnapshot(input);
  assertNoSourcePath(input, process.env.GBC_ORIGINAL_SAVE_PATH);
  const parsed = await parseSnapshot(input);
  if (command === "capabilities" || command === "validate") {
    process.stdout.write(`${JSON.stringify(parsed.capability)}\n`);
    return;
  }
  if (command === "export") {
    const output = arg("--output");
    const body = JSON.stringify(parsed.exportPayload, null, 2);
    if (output) {
      writeFileSync(output, body);
    } else {
      process.stdout.write(`${body}\n`);
    }
    return;
  }
  if (command === "inspect-table") {
    const table = arg("--table") ?? "";
    const found = parsed.capability.tables.find(
      (item) => item.name === table || String(item.unique_id) === table,
    );
    process.stdout.write(
      `${JSON.stringify({ table, found: Boolean(found), record_count: found?.record_count ?? 0 })}\n`,
    );
    return;
  }
  throw new Error(`unknown command ${command}`);
}

main().catch((error: unknown) => {
  const message = error instanceof Error ? error.message : "bridge failed";
  process.stderr.write(`${message}\n`);
  process.exit(1);
});
