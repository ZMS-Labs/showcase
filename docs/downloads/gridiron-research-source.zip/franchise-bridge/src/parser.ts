import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import Franchise, { FranchiseFileSettings } from "madden-franchise";
import { REQUESTED_TABLES } from "./field-mappings.ts";
import { emptyReport, type CapabilityReport } from "./capability-report.ts";

export function hashFile(path: string): string {
  return createHash("sha256").update(readFileSync(path)).digest("hex");
}

type FranchiseLike = Awaited<ReturnType<typeof Franchise.create>>;

export async function parseSnapshot(inputPath: string): Promise<{
  capability: CapabilityReport;
  exportPayload: Record<string, unknown>;
}> {
  const snapshotHash = hashFile(inputPath);
  let franchise: FranchiseLike;
  try {
    franchise = await Franchise.create(
      inputPath,
      new FranchiseFileSettings({ autoParse: true }),
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : "parse failed";
    const capability = emptyReport(
      snapshotHash,
      `Parser could not read snapshot (${message}). Madden 27 live validation remains UNVERIFIED.`,
    );
    return {
      capability,
      exportPayload: {
        snapshot_version: "gbc.franchise.v1",
        source_file_hash: snapshotHash,
        source_file_size: readFileSync(inputPath).length,
        source_file_modified_at: new Date().toISOString(),
        captured_at: new Date().toISOString(),
        franchise_key: snapshotHash.slice(0, 12),
        teams: [],
        players: [],
        depth_charts: [],
        schedule: [],
        completed_games: [],
        standings: [],
        injuries: [],
        transactions: [],
        season_stats: [],
        career_stats: [],
        records: [],
        capability_report: capability,
        warnings: capability.warnings,
      },
    };
  }

  const tables = [];
  for (const requested of REQUESTED_TABLES) {
    const table = franchise.getTableByName?.(requested.name);
    if (!table) {
      tables.push({
        name: requested.name,
        unique_id: null,
        found: false,
        record_count: 0,
        requested_fields_found: [],
        requested_fields_missing: [...requested.fields],
      });
      continue;
    }
    if (table.readRecords) {
      await table.readRecords([...requested.fields]);
    }
    const records = table.records ?? [];
    const sample = records[0] ?? {};
    const foundFields = requested.fields.filter((field) => field in sample);
    const missing = requested.fields.filter((field) => !(field in sample));
    tables.push({
      name: requested.name,
      unique_id: table.header?.uniqueId ?? null,
      found: true,
      record_count: records.length,
      requested_fields_found: foundFields,
      requested_fields_missing: missing,
    });
  }

  const degraded = tables
    .filter((t) => !t.found)
    .map((t) => t.name.toLowerCase());
  const capability: CapabilityReport = {
    detected_game_year: franchise.gameYear ?? null,
    parser_version: "madden-franchise/4.3.6",
    schema_version: franchise.schema?.meta?.version ?? null,
    snapshot_hash: snapshotHash,
    tables,
    warnings: degraded.length ? [`Missing tables: ${degraded.join(", ")}`] : [],
    degraded_features: degraded,
  };

  return {
    capability,
    exportPayload: {
      snapshot_version: "gbc.franchise.v1",
      source_file_hash: snapshotHash,
      source_file_size: readFileSync(inputPath).length,
      source_file_modified_at: new Date().toISOString(),
      captured_at: new Date().toISOString(),
      game_year: franchise.gameYear ?? null,
      franchise_key: snapshotHash.slice(0, 12),
      teams: [],
      players: [],
      depth_charts: [],
      schedule: [],
      completed_games: [],
      standings: [],
      injuries: [],
      transactions: [],
      season_stats: [],
      career_stats: [],
      records: [],
      capability_report: capability,
      warnings: capability.warnings,
    },
  };
}
